"""
Export and copy the complete TradeKart Hardware E-Commerce project to the Desktop.
Target: C:\\Users\\LENOVO\\Desktop\\TradeKart_Hardware_Shop
"""
import os
import shutil
from pathlib import Path

SOURCE_DIR = Path("C:/Users/LENOVO/.gemini/antigravity/scratch/hardware_craft_shop").resolve()
DESKTOP_DIR = Path("C:/Users/LENOVO/Desktop/TradeKart_Hardware_Shop").resolve()

EXCLUDE_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
    "env",
    ".git",
    ".idea",
    ".vscode"
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".db-wal",
    ".db-shm"
}

def export_to_desktop():
    print("=" * 70)
    print("Exporting Complete TradeKart Project to Desktop...")
    print(f"Source : {SOURCE_DIR}")
    print(f"Target : {DESKTOP_DIR}")
    print("=" * 70)

    DESKTOP_DIR.mkdir(parents=True, exist_ok=True)

    copied_files = 0
    copied_bytes = 0

    for root, dirs, files in os.walk(SOURCE_DIR):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        rel_root = Path(root).relative_to(SOURCE_DIR)
        target_root = DESKTOP_DIR / rel_root
        target_root.mkdir(parents=True, exist_ok=True)

        for f in files:
            file_path = Path(root) / f
            if file_path.suffix in EXCLUDE_EXTENSIONS or f == "copy_to_desktop.py":
                continue

            target_file = target_root / f
            shutil.copy2(file_path, target_file)
            copied_files += 1
            copied_bytes += file_path.stat().st_size

    size_mb = copied_bytes / (1024 * 1024)
    print(f"\n[SUCCESS] Successfully exported {copied_files} files ({size_mb:.2f} MB)")
    print(f"[LOCATION] Folder Location on Desktop:")
    print(f"           {DESKTOP_DIR}")
    print("=" * 70)

if __name__ == "__main__":
    export_to_desktop()
