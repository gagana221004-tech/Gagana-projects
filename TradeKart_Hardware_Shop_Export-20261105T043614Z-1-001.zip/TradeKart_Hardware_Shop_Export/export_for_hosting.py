"""
TradeKart Production Export Script.
Packages the entire verified application, templates, static assets, databases,
Dockerfile, and hosting configurations into a clean distribution ZIP archive.
"""
import os
import sys
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_ZIP = BASE_DIR / "tradekart_production_export.zip"

# Patterns and folders to exclude from the production export
EXCLUDE_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
    "env",
    ".git",
    ".idea",
    ".vscode",
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".db-wal",
    ".db-shm",
}

EXCLUDE_FILES = {
    "tradekart_production_export.zip",
}

def create_export_archive():
    print("=" * 65)
    print("Exporting TradeKart Codebase for Production Hosting...")
    print("=" * 65)

    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()

    included_count = 0
    total_uncompressed_bytes = 0

    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(BASE_DIR):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]

            for file in files:
                file_path = Path(root) / file
                rel_path = file_path.relative_to(BASE_DIR)

                # Skip excluded extensions or files
                if file_path.suffix in EXCLUDE_EXTENSIONS or file in EXCLUDE_FILES:
                    continue

                zipf.write(file_path, arcname=str(rel_path))
                included_count += 1
                total_uncompressed_bytes += file_path.stat().st_size

    zip_size_mb = OUTPUT_ZIP.stat().st_size / (1024 * 1024)
    raw_size_mb = total_uncompressed_bytes / (1024 * 1024)

    print(f"\n Export Archive Created Successfully!")
    print(f" Archive File   : {OUTPUT_ZIP.name}")
    print(f" Full Path      : {OUTPUT_ZIP.resolve()}")
    print(f" Total Files    : {included_count} files packaged")
    print(f" Archive Size   : {zip_size_mb:.2f} MB (Compressed from {raw_size_mb:.2f} MB)")
    print("=" * 65)
    print("\nIncluded Key Hosting Files:")
    print("  • Dockerfile             (Production container with multi-worker Gunicorn)")
    print("  • docker-compose.yml     (Ready for 1-command VPS/Cloud deployment)")
    print("  • Procfile               (Ready for Render, Railway, Heroku)")
    print("  • render.yaml            (Render Cloud Blueprint)")
    print("  • requirements.txt       (Clean production dependencies)")
    print("  • .env.example           (Production environment variable template)")
    print("  • app/                   (Full FastAPI application, AI Scanner, Templates)")
    print("  • hardware_shop.db       (Pre-configured SQLite database)")
    print("=" * 65)

if __name__ == "__main__":
    create_export_archive()
