import unittest
from fastapi.testclient import TestClient
from app.main import app
from app.database import get_db, init_db
from app.auth import create_session_token, COOKIE_NAME, verify_password
from app.services.inventory_service import (
    get_items_needing_restock,
    get_critical_low_stock_items,
    restock_product,
    process_order_checkout_atomic,
    InsufficientStockException
)
from app.services.delivery_service import get_delivery_adapter
from app.services.payment_service import get_payment_adapter

client = TestClient(app)

class TestHardwareShop(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        init_db()

    def test_01_storefront_home(self):
        """Test storefront loads and displays hardware inventory with INR pricing."""
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("TRADEKART", response.text)
        self.assertIn("Hardware & Supply", response.text)
        self.assertIn("Victorian Antique Brass Mortise Door Knob", response.text)
        self.assertIn("₹", response.text)
        self.assertIn("Bangalore", response.text)

    def test_02_search_and_category_filtering(self):
        """Test filtering by category and search keyword."""
        # Category filter
        res_cat = client.get("/?category=plumbing-supplies")
        self.assertEqual(res_cat.status_code, 200)
        self.assertIn("Brass Ball Valve", res_cat.text)
        self.assertNotIn("Antique Brass Mortise Door Knob", res_cat.text)

        # Keyword search
        res_search = client.get("/?q=cement")
        self.assertEqual(res_search.status_code, 200)
        self.assertIn("Portland Cement", res_search.text)

    def test_03_product_detail_page(self):
        """Test product detail route with specifications and stock count."""
        response = client.get("/product/antique-brass-door-knob")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Solid Forged Brass", response.text)
        self.assertIn("HW-KNB-001", response.text)
        self.assertIn("Add to Shopping Cart", response.text)
        self.assertIn("₹", response.text)

    def test_04_cart_and_invoice_views(self):
        """Test cart view and printable invoice generation with Bangalore address & INR."""
        res_cart = client.get("/cart")
        self.assertEqual(res_cart.status_code, 200)
        self.assertIn("Shopping Cart", res_cart.text)

        # Invoice check for seeded order
        res_inv = client.get("/invoice/ORD-20261025-A109")
        self.assertEqual(res_inv.status_code, 200)
        self.assertIn("INVOICE", res_inv.text)
        self.assertIn("ORD-20261025-A109", res_inv.text)
        self.assertIn("Pooja Sharma", res_inv.text)
        self.assertIn("Bengaluru", res_inv.text)
        self.assertIn("GSTIN", res_inv.text)
        self.assertIn("₹", res_inv.text)

    def test_05_customer_auth_flow(self):
        """Test customer registration, login failure, and login success."""
        # Bad login
        res_bad = client.post("/login", data={"email": "customer@example.com", "password": "WrongPassword!"})
        self.assertEqual(res_bad.status_code, 400)
        self.assertIn("Invalid email or password", res_bad.text)

        # Good login
        res_good = client.post("/login", data={"email": "customer@example.com", "password": "Customer@123"}, follow_redirects=False)
        self.assertEqual(res_good.status_code, 303)
        self.assertIn(COOKIE_NAME, res_good.cookies)

    def test_06_admin_auth_and_dashboard_protection(self):
        """Test admin portal requires admin privileges."""
        # Unauthenticated request redirects
        res_unauth = client.get("/admin/dashboard", follow_redirects=False)
        self.assertIn(res_unauth.status_code, (303, 307))
        self.assertIn("/admin/login", res_unauth.headers["location"])

        # Authenticated admin access
        admin_token = create_session_token(1, "admin", "admin@hardwareshop.com")
        client.cookies.set(COOKIE_NAME, admin_token)
        res_admin = client.get("/admin/dashboard")
        self.assertEqual(res_admin.status_code, 200)
        self.assertIn("Shopkeeper Dashboard", res_admin.text)
        self.assertIn("Gross Sales", res_admin.text)
        client.cookies.clear()

    def test_07_restocking_intelligence_queries(self):
        """Test automatic identification of low stock and critical stock items."""
        low_stock = get_items_needing_restock()
        critical_stock = get_critical_low_stock_items(threshold=3)

        self.assertIsInstance(low_stock, list)
        self.assertIsInstance(critical_stock, list)
        self.assertTrue(len(low_stock) > 0, "Expected at least 1 low stock item in seed")
        self.assertTrue(len(critical_stock) > 0, "Expected at least 1 critical stock item in seed")

        # Test replenishing stock
        first_item = low_stock[0]
        initial_stock = first_item["stock_quantity"]
        replenish_res = restock_product(first_item["id"], 20, "Test unit restock", "TEST-RESTOCK-01")
        self.assertEqual(replenish_res["new_stock"], initial_stock + 20)

    def test_08_atomic_checkout_and_oversell_prevention(self):
        """
        Verify that stock is checked and decremented atomically in a single transaction,
        and that overselling is strictly prevented.
        """
        with get_db() as conn:
            prod = conn.execute("SELECT id, name, price, stock_quantity FROM products WHERE slug = 'galvanized-wood-screws-200'").fetchone()
            available = prod["stock_quantity"]
            prod_id = prod["id"]

        # Case A: Attempting to order MORE than available stock must raise InsufficientStockException
        excessive_cart = [{"product_id": prod_id, "quantity": available + 50}]
        customer_info = {"customer_name": "Test Builder", "customer_email": "builder@test.com", "customer_phone": "555-1234"}
        delivery_info = {"delivery_method": "pickup"}
        payment_info = {"payment_status": "paid", "provider": "mock", "transaction_id": "test_tx_001"}

        with self.assertRaises(InsufficientStockException):
            process_order_checkout_atomic(customer_info, excessive_cart, delivery_info, payment_info)

        # Confirm stock was NOT decremented (transaction rolled back)
        with get_db() as conn:
            prod_after = conn.execute("SELECT stock_quantity FROM products WHERE id = ?", (prod_id,)).fetchone()
            self.assertEqual(prod_after["stock_quantity"], available)

        # Case B: Ordering valid amount succeeds and decrements stock atomically
        valid_cart = [{"product_id": prod_id, "quantity": 2}]
        checkout_res = process_order_checkout_atomic(customer_info, valid_cart, delivery_info, payment_info)
        self.assertIn("order_number", checkout_res)

        with get_db() as conn:
            prod_decremented = conn.execute("SELECT stock_quantity FROM products WHERE id = ?", (prod_id,)).fetchone()
            self.assertEqual(prod_decremented["stock_quantity"], available - 2)

    def test_09_api_checkout_endpoint(self):
        """Test API checkout endpoint with card simulation and delivery options."""
        with get_db() as conn:
            prod = conn.execute("SELECT id, price FROM products WHERE stock_quantity >= 2 LIMIT 1").fetchone()
            pid = prod["id"]

        payload = {
            "customer_name": "Rohan Mehta",
            "customer_email": "rohan.mehta@example.in",
            "customer_phone": "+91 98860 54321",
            "delivery_method": "delivery",
            "delivery_address": "88/2 Indiranagar 100ft Road",
            "delivery_city": "Bengaluru",
            "delivery_state": "Karnataka",
            "delivery_postal": "560038",
            "delivery_notes": "Leave at security reception",
            "payment_method": "mock_card",
            "card_number": "4242 4242 4242 4242",
            "card_expiry": "12/28",
            "card_cvc": "123",
            "cart_items": [{"product_id": pid, "quantity": 1}]
        }

        res = client.post("/api/checkout", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["success"])
        self.assertIn("ORD-", data["order_number"])

    def test_10_icon_navigation_generation(self):
        """Test that clicking each category and department icon generates the corresponding page."""
        # Check that homepage contains clickable icon links for departments
        res_home = client.get("/")
        self.assertEqual(res_home.status_code, 200)
        self.assertIn('href="/?category=door-hardware"', res_home.text)
        self.assertIn('href="/?category=plumbing-supplies"', res_home.text)
        self.assertIn('href="/?category=building-materials"', res_home.text)
        self.assertIn('href="/?category=paints-finishes"', res_home.text)
        self.assertIn('Shop by Department', res_home.text)

        # Test clicking each department icon generates the filtered catalog page
        categories = [
            "chrome-hardware-accessories", "door-hardware", "fasteners-fixings",
            "plumbing-supplies", "adhesives-tapes", "building-materials",
            "paints-finishes", "paint-brushes-rollers", "hand-power-tools"
        ]
        for cat in categories:
            res_cat = client.get(f"/?category={cat}")
            self.assertEqual(res_cat.status_code, 200)
            self.assertIn(f"category={cat}", res_cat.text)

    def test_11_chrome_hardware_accessories_catalog(self):
        """Test Chrome Hardware & Accessories category, product listing, and SVG photos."""
        # 1. Category view
        res = client.get("/?category=chrome-hardware-accessories")
        self.assertEqual(res.status_code, 200)
        self.assertIn("Chrome Hardware &amp; Accessories", res.text)
        self.assertIn("HW-CHM-001", res.text)
        self.assertIn("designer_mortise_handle", res.text)
        self.assertIn("chrome_heavy_tower_bolt", res.text)
        self.assertIn("chrome_telescopic_drawer_slides", res.text)

        # 2. Product detail view with photo
        res_prod = client.get("/product/chrome-mortise-door-handle-set")
        self.assertEqual(res_prod.status_code, 200)
        self.assertIn("Designer Mirror Chrome Mortise Door Handle Set with Lock", res_prod.text)
        self.assertIn("HW-CHM-001", res_prod.text)
        self.assertIn("Triple-Layer Mirror Polish Chrome", res_prod.text)
        self.assertIn("designer_mortise_handle", res_prod.text)
        self.assertIn("Add to Shopping Cart", res_prod.text)

        # 3. Product search keyword
        res_search = client.get("/?q=aldrop")
        self.assertEqual(res_search.status_code, 200)
        self.assertIn("HW-CHM-006", res_search.text)

    def test_12_ai_assistant_page_and_identification_api(self):
        """Test AI Shopping Assistant page, camera scanner UI, and multimodal identification API."""
        # 1. Test UI Page
        res_page = client.get("/ai-assistant")
        self.assertEqual(res_page.status_code, 200)
        self.assertIn("AI Part Scanner", res_page.text)
        self.assertIn("Align Part in Center", res_page.text)
        self.assertIn("Camera &amp; Photo Scanner", res_page.text)

        # 2. Test Multimodal API with text query for safety-critical plumbing valve
        res_valve = client.post("/api/ai-assistant/identify", data={"text_query": "leaking 1-inch brass ball valve on bathroom water pipe"})
        self.assertEqual(res_valve.status_code, 200)
        data_valve = res_valve.json()
        self.assertEqual(data_valve["status"], "success")
        self.assertIn("Ball Valve", data_valve["identified_part"]["name"])
        self.assertEqual(data_valve["confidence"]["level"], "HIGH")
        self.assertTrue(data_valve["safety_advisory"]["is_safety_critical"])
        self.assertIn("Pressurized Water Component", data_valve["safety_advisory"]["warning_message"])
        self.assertIsNotNone(data_valve["recommended_product"])
        self.assertEqual(data_valve["recommended_product"]["sku"], "HW-PLM-001")
        self.assertGreater(data_valve["recommended_product"]["stock_quantity"], 0)

        # 3. Test Multimodal API for automotive safety-critical brake pads
        res_brake = client.post("/api/ai-assistant/identify", data={"text_query": "front ceramic disc brake pads set for toyota"})
        self.assertEqual(res_brake.status_code, 200)
        data_brake = res_brake.json()
        self.assertEqual(data_brake["status"], "success")
        self.assertIn("Brake Pad", data_brake["identified_part"]["name"])
        self.assertTrue(data_brake["safety_advisory"]["is_safety_critical"])
        self.assertIsNotNone(data_brake["recommended_product"])
        self.assertEqual(data_brake["recommended_product"]["sku"], "SP-BRK-TOY-03")

if __name__ == "__main__":
    unittest.main()
