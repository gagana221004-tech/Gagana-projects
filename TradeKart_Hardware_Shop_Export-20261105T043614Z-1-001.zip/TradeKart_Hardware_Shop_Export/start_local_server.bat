@echo off
title TradeKart Hardware & Industrial E-Commerce
echo =====================================================================
echo  TradeKart Hardware & Industrial E-Commerce Platform
echo  Storefront + Spare Parts Dealer Portal + AI Camera Part Scanner
echo =====================================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not found in PATH!
    echo Please install Python 3.10+ from https://www.python.org/
    pause
    exit /b 1
)

echo [2/3] Checking dependencies...
python -m pip install -q -r requirements.txt

echo [3/3] Checking local database...
if not exist "hardware_shop.db" (
    echo Database not found. Initializing and seeding TradeKart database...
    python seed_data.py
    python setup_jpeg_images.py
)

echo.
echo =====================================================================
echo  Server is starting! 
echo  Access your local desktop website at:
echo    - Main Hardware Storefront : http://127.0.0.1:8000/
echo    - Spare Parts Portal       : http://127.0.0.1:8000/spare-parts
echo    - AI Camera Part Scanner   : http://127.0.0.1:8000/ai-assistant
echo    - Admin Control Panel      : http://127.0.0.1:8000/admin/login
echo.
echo  Press Ctrl+C to stop the server at any time.
echo =====================================================================
echo.

python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
pause
