"""
Comprehensive Automated Test Suite for Spare Parts Dealer Portal
Tests Retailer Marketplace, Authentication, Wholesale Checkout, MOQ Validation,
Atomic Stock Decrement, Reorder Alert Thresholds, Invoicing, Admin Controls, and Analytics.
"""
import unittest
from fastapi.testclient import TestClient
from app.main import app
from app.database import get_db, init_db
from app.auth import create_session_token, COOKIE_NAME
from seed_spare_parts import seed_spare_parts_data

client = TestClient(app)

class TestSparePartsPortal(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        seed_spare_parts_data()

    def test_01_spare_parts_marketplace_catalogue(self):
        """Test catalogue loads with 4W and 2W brands and categories."""
        res = client.get("/spare-parts")
        self.assertEqual(res.status_code, 200)
        self.assertIn("Spare Parts Dealer Portal", res.text)
        self.assertIn("Tata Motors", res.text)
        self.assertIn("Maruti Suzuki", res.text)
        self.assertIn("Royal Enfield", res.text)
        self.assertIn("Engine Parts", res.text)
        self.assertIn("Filters", res.text)
        self.assertIn("₹250.00", res.text) # Oil filter wholesale price
        self.assertIn("illustrative prototype figure", res.text.lower())

    def test_02_filtering_by_vehicle_type_brand_and_category(self):
        """Test filtering by 4-wheeler, 2-wheeler, brand, and category."""
        # 1. Four-Wheeler filter
        res_4w = client.get("/spare-parts?vehicle_type=four_wheeler")
        self.assertEqual(res_4w.status_code, 200)
        self.assertIn("Tata", res_4w.text)
        self.assertNotIn("SP-2W-RE-11", res_4w.text)

        # 2. Two-Wheeler filter
        res_2w = client.get("/spare-parts?vehicle_type=two_wheeler")
        self.assertEqual(res_2w.status_code, 200)
        self.assertIn("Royal Enfield", res_2w.text)
        self.assertNotIn("SP-FLT-TAT-01", res_2w.text)

        # 3. Brand filter: Royal Enfield
        res_re = client.get("/spare-parts?brand=Royal+Enfield")
        self.assertEqual(res_re.status_code, 200)
        self.assertIn("Royal Enfield", res_re.text)
        self.assertIn("SP-2W-RE-11", res_re.text)
        self.assertNotIn("SP-FLT-TAT-01", res_re.text)

        # 4. Category filter: Brake System
        res_brk = client.get("/spare-parts?category=Brake+System")
        self.assertEqual(res_brk.status_code, 200)
        self.assertIn("Brake", res_brk.text)
        self.assertNotIn("SP-FLT-TAT-01", res_brk.text)

    def test_03_retailer_auth_and_dashboard(self):
        """Test retailer login and dashboard metrics."""
        # Login with pre-seeded retailer
        res_login = client.post(
            "/spare-parts/login",
            data={"email": "retailer@apexmotors.in", "password": "Retailer@123"},
            follow_redirects=False
        )
        self.assertEqual(res_login.status_code, 303)
        self.assertIn(COOKIE_NAME, res_login.cookies)
        
        # Access retailer dashboard
        token = res_login.cookies[COOKIE_NAME]
        client.cookies.set(COOKIE_NAME, token)
        
        res_dash = client.get("/spare-parts/dashboard")
        self.assertEqual(res_dash.status_code, 200)
        self.assertIn("Apex Precision Motors", res_dash.text)
        self.assertIn("8.0% OFF", res_dash.text)
        self.assertIn("Products in Catalog", res_dash.text)
        self.assertIn("Recent Wholesale Consignments", res_dash.text)
        client.cookies.clear()

    def test_04_retailer_registration_flow(self):
        """Test registering a new garage workshop and triggering admin notification."""
        import time
        unique_email = f"newgarage_{int(time.time()*1000)}@koramangala.in"
        res_reg = client.post(
            "/spare-parts/register",
            data={
                "business_name": "Koramangala Turbo Spares",
                "contact_person": "Praveen Rao",
                "email": unique_email,
                "phone": "+91 98800 11223",
                "password": "DealerPassword@123",
                "gstin": "29AABCU9999K1Z4",
                "city": "Bangalore",
                "address": "15th Main, 5th Block, Koramangala"
            },
            follow_redirects=False
        )
        self.assertEqual(res_reg.status_code, 303)
        
        # Verify notification created for admin
        with get_db() as conn:
            notif = conn.execute("""
                SELECT * FROM portal_notifications 
                WHERE recipient_type = 'admin' AND event_type = 'new_retailer'
                ORDER BY id DESC LIMIT 1
            """).fetchone()
            self.assertIsNotNone(notif)
            self.assertIn("Koramangala Turbo Spares", notif["message"])

    def test_05_moq_enforcement_and_validation(self):
        """Test that ordering below MOQ is rejected with clear user warning."""
        with get_db() as conn:
            r = conn.execute("SELECT user_id FROM retailers WHERE email = 'retailer@apexmotors.in'").fetchone()
            u_token = create_session_token(r["user_id"], "retailer", "retailer@apexmotors.in")
            
            part = conn.execute("SELECT id, min_order_qty FROM spare_parts WHERE sku = 'SP-FLT-TAT-01'").fetchone()
            p_id = part["id"]
            moq = part["min_order_qty"] # 10
            
        client.cookies.set(COOKIE_NAME, u_token)
        
        # Attempt to order only 2 units (below MOQ of 10)
        res = client.post("/spare-parts/api/checkout", json={
            "items": [{"part_id": p_id, "quantity": 2}],
            "delivery_address": "Test Bay 1"
        })
        self.assertEqual(res.status_code, 400)
        data = res.json()
        self.assertFalse(data["success"])
        self.assertIn("Minimum Order Quantity", data["error"])
        client.cookies.clear()

    def test_06_reorder_point_surveillance_and_atomic_stock_decrement(self):
        """
        Verify user-prompt example:
        'Example: 250 oil filters with a reorder point of 50; after a retailer buys 200, stock is 50 and the alert fires.'
        """
        with get_db() as conn:
            # Set Oil Filter to exactly 250 in stock, reorder point 50
            conn.execute("""
                UPDATE spare_parts
                SET stock_quantity = 250, reorder_point = 50, min_order_qty = 10
                WHERE sku = 'SP-FLT-TAT-01'
            """)
            part = conn.execute("SELECT id, stock_quantity, reorder_point FROM spare_parts WHERE sku = 'SP-FLT-TAT-01'").fetchone()
            p_id = part["id"]
            self.assertEqual(part["stock_quantity"], 250)
            self.assertEqual(part["reorder_point"], 50)
            
            r = conn.execute("SELECT user_id, id FROM retailers WHERE email = 'retailer@apexmotors.in'").fetchone()
            u_token = create_session_token(r["user_id"], "retailer", "retailer@apexmotors.in")

        client.cookies.set(COOKIE_NAME, u_token)

        # Retailer buys 200 units (valid above MOQ of 10, leaving 50 units)
        res = client.post("/spare-parts/api/checkout", json={
            "items": [{"part_id": p_id, "quantity": 200}],
            "delivery_address": "Apex Precision Motors, Bellandur, Bangalore"
        })
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["success"])
        order_num = data["order_number"]

        # Verify stock decremented to exactly 50
        with get_db() as conn:
            part_after = conn.execute("SELECT stock_quantity FROM spare_parts WHERE id = ?", (p_id,)).fetchone()
            self.assertEqual(part_after["stock_quantity"], 50)

            # Verify automated surveillance alert was triggered for admin!
            alert = conn.execute("""
                SELECT * FROM portal_notifications 
                WHERE recipient_type = 'admin' AND event_type = 'reorder_alert'
                ORDER BY id DESC LIMIT 1
            """).fetchone()
            self.assertIsNotNone(alert)
            self.assertIn("SP-FLT-TAT-01", alert["message"])
            self.assertIn("50", alert["message"])

        client.cookies.clear()

    def test_07_tax_invoice_generation_with_gst(self):
        """Test generated wholesale tax invoice with TradeKart GSTIN and CGST/SGST split."""
        res = client.get("/spare-parts/invoice/INV-SP-20261026-001")
        self.assertEqual(res.status_code, 200)
        self.assertIn("TAX INVOICE", res.text)
        self.assertIn("TRADEKART AUTO DISTRIBUTION", res.text)
        self.assertIn("29AABCU9603R1ZM", res.text) # Karnataka GSTIN
        self.assertIn("CGST (9.0%)", res.text)
        self.assertIn("SGST (9.0%)", res.text)
        self.assertIn("Print / Save as PDF", res.text)

    def test_08_admin_control_panel_overview(self):
        """Test admin overview with 8 KPI metrics and low stock alerts."""
        admin_token = create_session_token(1, "admin", "admin@hardwareshop.com")
        client.cookies.set(COOKIE_NAME, admin_token)

        res = client.get("/spare-parts/admin")
        self.assertEqual(res.status_code, 200)
        self.assertIn("Admin Main Control Panel", res.text)
        self.assertIn("Retailer Partners", res.text)
        self.assertIn("Catalog SKUs", res.text)
        self.assertIn("Total Inventory Units", res.text)
        self.assertIn("Reorder Alerts", res.text)
        self.assertIn("Monthly Wholesale Volume", res.text)
        self.assertIn("Pending Orders", res.text)
        self.assertIn("Completed Orders", res.text)
        client.cookies.clear()

    def test_09_admin_inventory_price_editing(self):
        """Test that wholesale prices and stock are editable from admin side."""
        admin_token = create_session_token(1, "admin", "admin@hardwareshop.com")
        client.cookies.set(COOKIE_NAME, admin_token)

        with get_db() as conn:
            part = conn.execute("SELECT id, wholesale_price FROM spare_parts WHERE sku = 'SP-FLT-MS-02'").fetchone()
            pid = part["id"]

        # Update wholesale price to ₹375.00
        res_edit = client.post(f"/spare-parts/admin/inventory/edit/{pid}", data={
            "wholesale_price": 375.00,
            "suggested_retail_price": 600.00,
            "stock_quantity": 210,
            "reorder_point": 35,
            "min_order_qty": 10
        }, follow_redirects=False)
        self.assertEqual(res_edit.status_code, 303)

        # Verify updated price
        with get_db() as conn:
            p_updated = conn.execute("SELECT wholesale_price, stock_quantity FROM spare_parts WHERE id = ?", (pid,)).fetchone()
            self.assertEqual(p_updated["wholesale_price"], 375.00)
            self.assertEqual(p_updated["stock_quantity"], 210)

        client.cookies.clear()

    def test_10_admin_retailer_management_and_analytics(self):
        """Test retailer status approval, discount tier assignment, and analytics view."""
        admin_token = create_session_token(1, "admin", "admin@hardwareshop.com")
        client.cookies.set(COOKIE_NAME, admin_token)

        with get_db() as conn:
            ret = conn.execute("SELECT id FROM retailers WHERE status = 'pending' LIMIT 1").fetchone()
            if not ret:
                ret = conn.execute("SELECT id FROM retailers LIMIT 1").fetchone()
            rid = ret["id"]

        # 1. Update discount tier to 12.0%
        res_disc = client.post(f"/spare-parts/admin/retailers/{rid}/discount", data={"discount_percent": 12.0}, follow_redirects=False)
        self.assertEqual(res_disc.status_code, 303)

        # 2. Approve status
        res_app = client.post(f"/spare-parts/admin/retailers/{rid}/status", data={"status": "approved"}, follow_redirects=False)
        self.assertEqual(res_app.status_code, 303)

        # 3. View Analytics page
        res_an = client.get("/spare-parts/admin/analytics")
        self.assertEqual(res_an.status_code, 200)
        self.assertIn("Two-Wheeler vs. Four-Wheeler Distribution Split", res_an.text)
        self.assertIn("Most-Purchased Spare Parts", res_an.text)
        self.assertIn("Highest-Purchasing Retailers", res_an.text)
        self.assertIn("Monthly Gross Profit", res_an.text)

        client.cookies.clear()

    def test_11_admin_add_new_part_and_edit_image(self):
        """Test adding a new spare part via form and editing its product image and name."""
        admin_token = create_session_token(1, "admin", "admin@hardwareshop.com")
        client.cookies.set(COOKIE_NAME, admin_token)

        # 1. Test GET /spare-parts/admin/inventory/new page renders
        res_form = client.get("/spare-parts/admin/inventory/new")
        self.assertEqual(res_form.status_code, 200)
        self.assertIn("Add New Automobile Spare Part", res_form.text)
        self.assertIn("Option 1: Upload Image File", res_form.text)
        self.assertIn("Option 2: Or Select From 18 Automotive Preset Graphics", res_form.text)

        # 2. Add new part via POST /spare-parts/admin/inventory/add
        import time
        unique_sku = f"SP-TEST-{int(time.time())}"
        res_add = client.post("/spare-parts/admin/inventory/add", data={
            "name": "Heavy Duty Ceramic Disc Brake Pad",
            "sku": unique_sku,
            "vehicle_type": "four_wheeler",
            "brand": "Toyota",
            "category": "Brake System",
            "compatible_models": "Toyota Fortuner, Hilux, Innova Crysta",
            "wholesale_price": 950.00,
            "suggested_retail_price": 1600.00,
            "stock_quantity": 80,
            "reorder_point": 15,
            "min_order_qty": 4,
            "image_url": "/static/images/spare_parts/brake_pad_set.jpg"
        }, follow_redirects=False)
        self.assertEqual(res_add.status_code, 303)

        # Verify added part in DB
        with get_db() as conn:
            new_part = conn.execute("SELECT * FROM spare_parts WHERE sku = ?", (unique_sku,)).fetchone()
            self.assertIsNotNone(new_part)
            self.assertEqual(new_part["name"], "Heavy Duty Ceramic Disc Brake Pad")
            self.assertEqual(new_part["image_url"], "/static/images/spare_parts/brake_pad_set.jpg")
            new_id = new_part["id"]

        # 3. Edit Part Image and Details via POST /spare-parts/admin/inventory/edit/{id}
        res_edit = client.post(f"/spare-parts/admin/inventory/edit/{new_id}", data={
            "name": "Premium Gold Ceramic Disc Brake Pad",
            "brand": "Toyota Genuine",
            "category": "Brake System",
            "compatible_models": "Toyota Fortuner, Hilux (2020-2025)",
            "vehicle_type": "four_wheeler",
            "wholesale_price": 1050.00,
            "suggested_retail_price": 1850.00,
            "stock_quantity": 120,
            "reorder_point": 25,
            "min_order_qty": 5,
            "image_url": "/static/images/spare_parts/shock_absorber.jpg"
        }, follow_redirects=False)
        self.assertEqual(res_edit.status_code, 303)

        # Verify updated image and metadata in DB
        with get_db() as conn:
            updated_part = conn.execute("SELECT * FROM spare_parts WHERE id = ?", (new_id,)).fetchone()
            self.assertEqual(updated_part["name"], "Premium Gold Ceramic Disc Brake Pad")
            self.assertEqual(updated_part["brand"], "Toyota Genuine")
            self.assertEqual(updated_part["image_url"], "/static/images/spare_parts/shock_absorber.jpg")
            self.assertEqual(updated_part["wholesale_price"], 1050.00)
            self.assertEqual(updated_part["stock_quantity"], 120)

        client.cookies.clear()

if __name__ == "__main__":
    unittest.main()
