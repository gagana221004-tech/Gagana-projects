"""
Insert Chrome Hardware & Accessories category and 12 products directly into the database.
"""
from app.database import get_db, init_db

def add_chrome_hardware():
    init_db()
    with get_db() as conn:
        cursor = conn.cursor()
        
        # 1. Insert Category if not exists
        cursor.execute("SELECT id FROM categories WHERE slug = 'chrome-hardware-accessories'")
        cat = cursor.fetchone()
        if not cat:
            cursor.execute("""
                INSERT INTO categories (name, slug, description, icon)
                VALUES (?, ?, ?, ?)
            """, (
                "Chrome Hardware & Accessories",
                "chrome-hardware-accessories",
                "Mirror-finish chrome door handles, pulls, tower bolts, hinges, and builder fittings.",
                "sparkles"
            ))
            cat_id = cursor.lastrowid
            print(f"Created category 'Chrome Hardware & Accessories' with ID: {cat_id}")
        else:
            cat_id = cat["id"]
            print(f"Found existing category with ID: {cat_id}")

        # 2. Insert Products
        products = [
            (
                "Designer Mirror Chrome Mortise Door Handle Set with Lock",
                "chrome-mortise-door-handle-set",
                cat_id,
                "HW-CHM-001",
                "Premium mirror-finish chrome plated mortise door handle pair featuring reversible brass latch mechanism and Euro profile computer key cylinder. Multi-layer anti-tarnish electroplating for luxury main entrance and bedroom doors.",
                "Material: Solid Virgin Zinc Alloy & Brass Internals\nFinish: Triple-Layer Mirror Polish Chrome\nBackset: 60 mm / Plate Size: 200 mm x 45 mm\nKeys: 3 Computer Dimple Security Keys\nSalt Spray Rating: 96-hr Neutral Salt Spray (NSS) Tested",
                1250.00,
                35,
                10,
                "/static/images/products/designer_mortise_handle.png"
            ),
            (
                "Heavy-Duty Stainless Steel Chrome D-Pull Main Door Handle (12\")",
                "chrome-main-door-d-pull-handle-12in",
                cat_id,
                "HW-CHM-002",
                "Contemporary tubular D-shaped entrance pull handle manufactured from premium grade stainless steel with high-buff mirror chrome electroplating. Suitable for wooden, metal, and glass main entrance doors.",
                "Material: Grade 304 Stainless Steel with Mirror Chrome Finish\nLength: 300 mm (12 Inches)\nTube Diameter: 25 mm\nHole-to-Hole Distance: 200 mm\nMounting: Back-to-Back Bolt-Through & Concealed Screws Included",
                780.00,
                42,
                12,
                "/static/images/products/chrome_pull_handle_main_door.svg"
            ),
            (
                "Sleek Chrome Slim Bar Cabinet & Wardrobe Pull Handles (Pack of 6)",
                "chrome-cabinet-wardrobe-pull-pack-6",
                cat_id,
                "HW-CHM-003",
                "Ergonomic architectural bow-bar cabinet handles finished in radiant mirror chrome. Engineered for kitchen modular cabinets, bedroom wardrobes, and bathroom vanity drawers. Includes M4 mounting machine screws.",
                "Material: Solid Die-Cast Zinc Alloy\nOverall Length: 160 mm\nCenter-to-Center Hole Distance: 128 mm (Standard Modular Size)\nProjection: 28 mm\nPack: 6 Handles with 12 M4 Screws",
                540.00,
                50,
                15,
                "/static/images/products/chrome_cabinet_wardrobe_pull.svg"
            ),
            (
                "Heavy-Duty Solid Brass Chrome Plated Barrel Tower Bolt (8\")",
                "chrome-heavy-duty-tower-bolt-8in",
                cat_id,
                "HW-CHM-004",
                "Precision-extruded solid brass tower bolt (chitkani) with mirror-finish chrome coating. Features a 10mm thick hardened brass shoot bolt, anti-rattle friction spring, and heavy strike plate for primary room and balcony door locking.",
                "Material: Solid Forged Brass with Thick Chrome Electroplating\nLength: 200 mm (8 Inches)\nShoot Bolt Diameter: 10 mm Solid Rod\nIncludes: 6 Matching SS Screws & Receiver Keeper Plate\nOperation: Friction Tension Ball Catch",
                340.00,
                60,
                15,
                "/static/images/products/chrome_heavy_tower_bolt.svg"
            ),
            (
                "Chrome Plated Ball Bearing Butt Door Hinges (4\"x3\"x3mm - Pair)",
                "chrome-ball-bearing-butt-hinges-pair",
                cat_id,
                "HW-CHM-005",
                "Architectural grade stainless steel butt hinges featuring four self-lubricating ball bearings and high-lustre chrome polish. Engineered for silent, friction-free swinging of heavy solid teak and flush doors up to 80kg load.",
                "Material: High-Grade Stainless Steel with Chrome Finish\nDimensions: 102 mm x 76 mm x 3.0 mm (4\" x 3\")\nBearings: 4 Precision Anti-Friction Ball Bearings\nWeight Capacity: Up to 80 kg per pair\nIncludes: 16 Countersunk Hardened Screws",
                420.00,
                80,
                20,
                "/static/images/products/chrome_bearing_door_hinges.svg"
            ),
            (
                "Traditional Heavy Security Chrome Plated Aldrop Door Latch (10\")",
                "chrome-aldrop-door-latch-10in",
                cat_id,
                "HW-CHM-006",
                "Classic Indian style security aldrop kit with heavy 14mm central sliding bolt, ornate floral brackets, and padlock hasp. Mirror chrome plated for weather resistance on front and double-shutter doors.",
                "Material: Heavy Forged Carbon Steel & Brass Core with Mirror Chrome Coating\nRod Length: 250 mm (10 Inches)\nRod Diameter: 14 mm Solid Bar\nKit: 1 Main Aldrop Rod, 2 Supporting Guide Brackets, 1 Padlock Hasp, 1 Strike Plate & Carriage Bolts",
                680.00,
                28,
                8,
                "/static/images/products/chrome_aldrop_latch_set.svg"
            ),
            (
                "Dual-Mount Chrome Magnetic Door Stopper & Wall Catch",
                "chrome-magnetic-door-stopper-catch",
                cat_id,
                "HW-CHM-007",
                "Smart concealed magnetic door holder with strong neodymium core that firmly catches doors to prevent wall damage from wind gusts. Dual floor or skirting board mounting capability.",
                "Material: Solid Die-Cast Zinc Alloy / Mirror Chrome\nBase Diameter: 50 mm / Catch Height: 75 mm\nHolding Power: 6 kg Neodymium Magnetic Pull Force\nInstallation: Floor or Wall Installation with expansion anchor bolts included",
                240.00,
                65,
                15,
                "/static/images/products/chrome_magnetic_door_stopper.svg"
            ),
            (
                "Chrome Soft-Close Hydraulic Concealed Cabinet Hinges (4 Pairs)",
                "chrome-hydraulic-soft-close-cabinet-hinges-4pairs",
                cat_id,
                "HW-CHM-008",
                "Full overlay (0 crank) hydraulic soft-closing furniture hinges with clip-on mounting plates and built-in copper hydraulic pistons. Prevents slamming of modular kitchen and wardrobe shutters.",
                "Type: Full Overlay (0 Crank), 105-Degree Opening Angle\nCup Diameter: 35 mm (Standard European Cup Drilling)\nMaterial: Cold-Rolled Steel with Double Chrome & Nickel Plating\nCycle Test: 50,000 Open/Close Cycles Certified\nPack: 4 Pairs (8 Hinges) with Mounting Plates & Screws",
                590.00,
                45,
                10,
                "/static/images/products/chrome_hydraulic_softclose_hinge.svg"
            ),
            (
                "Heavy-Duty Telescopic Ball Bearing Drawer Slides (18\" - Pair)",
                "chrome-telescopic-drawer-slides-18in-pair",
                cat_id,
                "HW-CHM-009",
                "Three-fold full extension drawer channels with double row solid steel ball bearings for smooth, whisper-quiet glide. Supports heavy kitchen pot drawers and office file cabinets up to 45kg.",
                "Length: 450 mm (18 Inches) Closed / 900 mm Fully Extended\nLoad Capacity: 45 kg per pair\nProfile Width: 45 mm Standard Industry Dimension\nMaterial: Hardened Q235 Steel with Anti-Corrosion Chrome Finish\nDisassembly: Quick-release plastic lever mechanism",
                460.00,
                55,
                12,
                "/static/images/products/chrome_telescopic_drawer_slides.svg"
            ),
            (
                "Mirror Chrome Toughened Glass Door Top & Bottom Patch Fitting Set",
                "chrome-glass-door-patch-fitting-set",
                cat_id,
                "HW-CHM-010",
                "Commercial architectural patch fittings for 10mm to 12mm frameless toughened glass entrance doors. High-grade alloy body enclosed in brilliant mirror-finish stainless steel chrome covers.",
                "Glass Compatibility: 10 mm - 12 mm Frameless Toughened Safety Glass\nMaterial: High Strength Aluminium Alloy Body with SS 304 Chrome Cover Plates\nGaskets: High Elasticity Anti-Slip Neoprene Rubber Gaskets\nFits: Standard Floor Spring Spindle and Top Pivot Plugs",
                1450.00,
                20,
                5,
                "/static/images/products/chrome_glass_door_patch_fitting.svg"
            ),
            (
                "Heavy-Duty Ornamental Chrome Shelf L-Brackets (10\"x12\" - Pair)",
                "chrome-shelf-l-brackets-10x12in-pair",
                cat_id,
                "HW-CHM-011",
                "Heavy gauge steel wall brackets featuring an integrated diagonal brace and mirror chrome plating. Holds glass, granite, or wood shelving in retail showrooms, kitchens, and modern living spaces.",
                "Dimensions: 250 mm x 300 mm (10\" x 12\")\nWeight Capacity: 70 kg per pair\nMaterial: 4mm Heavy Gauge Carbon Steel / Bright Chrome Electroplating\nIncludes: 6 Heavy Duty Wall Plugs & Matching Chrome Finish Screws",
                380.00,
                40,
                10,
                "/static/images/products/chrome_shelf_bracket_l_type.svg"
            ),
            (
                "Luxury Chrome Plated Bathroom Towel Rack & Robe Hook Set (24\")",
                "chrome-bathroom-towel-rack-robe-hook-set",
                cat_id,
                "HW-CHM-012",
                "Complete hotel-grade 24-inch dual-tier towel organizer with top shelf, lower hanging bar, and 4 multi-purpose robe hooks. 100% moisture-proof and rust-proof mirror chrome electroplating.",
                "Length: 600 mm (24 Inches) / Depth: 220 mm\nMaterial: Virgin Brass Base with High-Micron Mirror Chrome Polish\nInstallation: Wall Mounted with Concealed SS Screws & Wall Plugs\nWarranty: 5 Years Anti-Rust Surface Warranty",
                1150.00,
                30,
                8,
                "/static/images/products/chrome_towel_rod_bath_fitting.svg"
            )
        ]

        inserted = 0
        updated = 0
        for p in products:
            sku = p[3]
            cursor.execute("SELECT id FROM products WHERE sku = ?", (sku,))
            existing = cursor.fetchone()
            if existing:
                cursor.execute("""
                    UPDATE products SET 
                        name = ?, slug = ?, category_id = ?, description = ?,
                        specifications = ?, price = ?, stock_quantity = ?, reorder_point = ?,
                        image_url = ?, is_active = 1
                    WHERE id = ?
                """, (p[0], p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[9], existing["id"]))
                updated += 1
            else:
                cursor.execute("""
                    INSERT INTO products (
                        name, slug, category_id, sku, description, specifications,
                        price, stock_quantity, reorder_point, image_url, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """, p)
                prod_id = cursor.lastrowid
                cursor.execute("""
                    INSERT INTO stock_logs (product_id, change_amount, previous_stock, new_stock, reason, reference_id)
                    VALUES (?, ?, 0, ?, 'initial_seed', 'SEED-CHROME')
                """, (prod_id, p[7], p[7]))
                inserted += 1

        print(f"Products synchronized successfully! Inserted: {inserted}, Updated: {updated}")

if __name__ == "__main__":
    add_chrome_hardware()
