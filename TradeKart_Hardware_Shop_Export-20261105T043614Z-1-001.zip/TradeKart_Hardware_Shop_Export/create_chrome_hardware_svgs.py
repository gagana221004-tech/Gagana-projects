"""
Generate realistic vector product photographs for Chrome Hardware & Accessories.
Based on IndiaMART's Chrome Hardware & Accessories catalog.
"""
from pathlib import Path

SVG_DIR = Path(__file__).resolve().parent / "app" / "static" / "images" / "products"
SVG_DIR.mkdir(parents=True, exist_ok=True)

CHROME_SVGS = {
    "chrome_mortise_door_handle.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="chromePlate" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="20%" stop-color="#e2e8f0"/>
      <stop offset="45%" stop-color="#94a3b8"/>
      <stop offset="70%" stop-color="#f8fafc"/>
      <stop offset="90%" stop-color="#64748b"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <linearGradient id="chromeLever" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="35%" stop-color="#cbd5e1"/>
      <stop offset="65%" stop-color="#64748b"/>
      <stop offset="100%" stop-color="#1e293b"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="4" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#shadow)">
    <!-- Backplate Escutcheon -->
    <rect x="75" y="40" width="55" height="190" rx="10" fill="url(#chromePlate)" stroke="#94a3b8" stroke-width="2"/>
    <rect x="78" y="43" width="49" height="184" rx="8" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
    <!-- Screw Holes on Plate -->
    <circle cx="102" cy="55" r="4" fill="#475569" stroke="#94a3b8" stroke-width="1"/>
    <circle cx="102" cy="215" r="4" fill="#475569" stroke="#94a3b8" stroke-width="1"/>
    <!-- Keyhole Euro Profile Slot -->
    <circle cx="102" cy="165" r="8" fill="#1e293b"/>
    <polygon points="98,168 106,168 104,185 100,185" fill="#1e293b"/>
    <!-- Handle Rose Collar -->
    <circle cx="102" cy="100" r="20" fill="url(#chromePlate)" stroke="#cbd5e1" stroke-width="2"/>
    <circle cx="102" cy="100" r="14" fill="#64748b"/>
    <!-- Ergonomic Lever Handle -->
    <path d="M 102 93 L 205 90 C 220 90 230 100 228 112 C 226 122 215 125 200 125 L 102 107 Z" fill="url(#chromeLever)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Lever Specular Highlight Strip -->
    <path d="M 105 95 L 200 93 C 215 93 222 98 220 105" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.9"/>
  </g>
  <!-- Category Badge -->
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">CHROME MORTISE DOOR HANDLE</text>
</svg>""",

    "chrome_pull_handle_main_door.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="tubeGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#475569"/>
      <stop offset="25%" stop-color="#cbd5e1"/>
      <stop offset="50%" stop-color="#ffffff"/>
      <stop offset="75%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <linearGradient id="studGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="50%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#1e293b"/>
    </linearGradient>
    <filter id="shadowPull" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="6" dy="10" stdDeviation="7" flood-color="#0f172a" flood-opacity="0.3"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#shadowPull)">
    <!-- Mounting Stud 1 (Top) -->
    <rect x="75" y="70" width="45" height="20" rx="4" fill="url(#studGrad)" stroke="#64748b"/>
    <ellipse cx="75" cy="80" rx="6" ry="10" fill="#334155"/>
    <ellipse cx="120" cy="80" rx="5" ry="10" fill="url(#studGrad)"/>
    <!-- Mounting Stud 2 (Bottom) -->
    <rect x="75" y="190" width="45" height="20" rx="4" fill="url(#studGrad)" stroke="#64748b"/>
    <ellipse cx="75" cy="200" rx="6" ry="10" fill="#334155"/>
    <ellipse cx="120" cy="200" rx="5" ry="10" fill="url(#studGrad)"/>
    <!-- Main D-Pull Pipe Bar -->
    <path d="M 120 70 L 175 70 C 195 70 205 85 205 105 L 205 175 C 205 195 195 210 175 210 L 120 210 L 120 190 L 170 190 C 182 190 185 180 185 170 L 185 110 C 185 100 182 90 170 90 L 120 90 Z" 
          fill="url(#tubeGrad)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Specular Highlight Curve -->
    <path d="M 130 75 L 172 75 C 190 75 197 88 197 105 L 197 175 C 197 192 190 205 172 205 L 130 205" 
          fill="none" stroke="#ffffff" stroke-width="3" opacity="0.9" stroke-linecap="round"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">MAIN DOOR D-PULL HANDLE</text>
</svg>""",

    "chrome_cabinet_wardrobe_pull.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="30%" stop-color="#e2e8f0"/>
      <stop offset="60%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </linearGradient>
    <filter id="barShadow" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="3" dy="7" stdDeviation="5" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <!-- Two Handles in Pack Graphic -->
  <g filter="url(#barShadow)">
    <!-- Top Handle -->
    <g transform="translate(0, -25)">
      <!-- Left leg -->
      <path d="M 65 140 L 85 105 L 98 105 L 82 140 Z" fill="#64748b"/>
      <!-- Right leg -->
      <path d="M 235 140 L 215 105 L 202 105 L 218 140 Z" fill="#475569"/>
      <!-- Horizontal Bow Bar -->
      <rect x="55" y="95" width="190" height="18" rx="8" fill="url(#barGrad)" stroke="#94a3b8" stroke-width="1.5"/>
      <line x1="60" y1="99" x2="240" y2="99" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
    </g>
    <!-- Bottom Handle -->
    <g transform="translate(0, 50)">
      <!-- Left leg -->
      <path d="M 65 140 L 85 105 L 98 105 L 82 140 Z" fill="#64748b"/>
      <!-- Right leg -->
      <path d="M 235 140 L 215 105 L 202 105 L 218 140 Z" fill="#475569"/>
      <!-- Horizontal Bow Bar -->
      <rect x="55" y="95" width="190" height="18" rx="8" fill="url(#barGrad)" stroke="#94a3b8" stroke-width="1.5"/>
      <line x1="60" y1="99" x2="240" y2="99" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
    </g>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">CHROME CABINET PULLS (6-PACK)</text>
</svg>""",

    "chrome_heavy_tower_bolt.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="boltGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="25%" stop-color="#e2e8f0"/>
      <stop offset="50%" stop-color="#94a3b8"/>
      <stop offset="75%" stop-color="#cbd5e1"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <filter id="boltSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="3" dy="6" stdDeviation="5" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#boltSh)">
    <!-- Base Plate -->
    <rect x="40" y="115" width="165" height="70" rx="6" fill="url(#boltGrad)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Keeper Plate -->
    <rect x="220" y="115" width="45" height="70" rx="6" fill="url(#boltGrad)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Screw Holes -->
    <circle cx="55" cy="130" r="3.5" fill="#334155"/>
    <circle cx="55" cy="170" r="3.5" fill="#334155"/>
    <circle cx="190" cy="130" r="3.5" fill="#334155"/>
    <circle cx="190" cy="170" r="3.5" fill="#334155"/>
    <circle cx="242" cy="130" r="3.5" fill="#334155"/>
    <circle cx="242" cy="170" r="3.5" fill="#334155"/>
    <!-- Retaining Collars -->
    <rect x="65" y="135" width="22" height="30" rx="3" fill="#cbd5e1" stroke="#475569"/>
    <rect x="110" y="135" width="22" height="30" rx="3" fill="#cbd5e1" stroke="#475569"/>
    <rect x="170" y="135" width="22" height="30" rx="3" fill="#cbd5e1" stroke="#475569"/>
    <rect x="230" y="135" width="22" height="30" rx="3" fill="#cbd5e1" stroke="#475569"/>
    <!-- Sliding Solid Shoot Bolt -->
    <rect x="45" y="142" width="210" height="16" rx="8" fill="url(#boltGrad)" stroke="#475569" stroke-width="1.5"/>
    <line x1="50" y1="146" x2="250" y2="146" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/>
    <!-- Thumb Knob on Bolt -->
    <ellipse cx="140" cy="150" rx="10" ry="18" fill="url(#boltGrad)" stroke="#1e293b" stroke-width="2"/>
    <circle cx="140" cy="150" r="5" fill="#ffffff" opacity="0.8"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">CHROME TOWER BOLT (8 INCH)</text>
</svg>""",

    "chrome_bearing_door_hinges.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="hingePlate" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="25%" stop-color="#e2e8f0"/>
      <stop offset="50%" stop-color="#94a3b8"/>
      <stop offset="75%" stop-color="#f1f5f9"/>
      <stop offset="100%" stop-color="#475569"/>
    </linearGradient>
    <linearGradient id="pinGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#64748b"/>
      <stop offset="50%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#1e293b"/>
    </linearGradient>
    <filter id="hShadow" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="4" dy="7" stdDeviation="5" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#hShadow)">
    <!-- Left Leaf -->
    <rect x="60" y="55" width="80" height="170" rx="6" fill="url(#hingePlate)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Right Leaf -->
    <rect x="160" y="55" width="80" height="170" rx="6" fill="url(#hingePlate)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Countersunk Screw Holes (Left) -->
    <circle cx="85" cy="80" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <circle cx="115" cy="115" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <circle cx="85" cy="165" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <circle cx="115" cy="200" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <!-- Countersunk Screw Holes (Right) -->
    <circle cx="215" cy="80" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <circle cx="185" cy="115" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <circle cx="215" cy="165" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <circle cx="185" cy="200" r="5" fill="#475569" stroke="#cbd5e1" stroke-width="1"/>
    <!-- Central Knuckle Pin & 4 Ball Bearings -->
    <rect x="140" y="45" width="20" height="190" rx="4" fill="url(#pinGrad)" stroke="#334155" stroke-width="1.5"/>
    <!-- Bearing Washers -->
    <rect x="139" y="80" width="22" height="6" fill="#1e293b"/>
    <rect x="139" y="115" width="22" height="6" fill="#1e293b"/>
    <rect x="139" y="155" width="22" height="6" fill="#1e293b"/>
    <rect x="139" y="195" width="22" height="6" fill="#1e293b"/>
    <!-- Finial Decorative Top & Bottom Tips -->
    <ellipse cx="150" cy="45" rx="10" ry="6" fill="url(#pinGrad)"/>
    <ellipse cx="150" cy="235" rx="10" ry="6" fill="url(#pinGrad)"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">BALL BEARING HINGES (4"x3")</text>
</svg>""",

    "chrome_aldrop_latch_set.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="aldropMetal" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="30%" stop-color="#cbd5e1"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <filter id="alDropSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="4" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.3"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#alDropSh)">
    <!-- Ornate Back Mount Plates -->
    <rect x="50" y="110" width="30" height="80" rx="8" fill="url(#aldropMetal)" stroke="#64748b"/>
    <rect x="150" y="110" width="30" height="80" rx="8" fill="url(#aldropMetal)" stroke="#64748b"/>
    <rect x="225" y="110" width="30" height="80" rx="8" fill="url(#aldropMetal)" stroke="#64748b"/>
    <!-- Heavy 14mm Main Aldrop Rod -->
    <rect x="35" y="140" width="230" height="20" rx="10" fill="url(#aldropMetal)" stroke="#475569" stroke-width="1.5"/>
    <line x1="40" y1="145" x2="260" y2="145" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
    <!-- Padlock Hasp Swivel Tongue -->
    <path d="M 125 150 L 125 195 C 125 205 145 205 145 195 L 145 150 Z" fill="url(#aldropMetal)" stroke="#334155" stroke-width="1.5"/>
    <!-- Padlock Eyelet Hole -->
    <circle cx="135" cy="188" r="6" fill="#1e293b"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">CHROME ALDROP DOOR LATCH (10")</text>
</svg>""",

    "chrome_magnetic_door_stopper.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <radialGradient id="stopperCap" cx="35%" cy="35%" r="65%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="40%" stop-color="#e2e8f0"/>
      <stop offset="80%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#334155"/>
    </radialGradient>
    <linearGradient id="bodyGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#cbd5e1"/>
      <stop offset="40%" stop-color="#ffffff"/>
      <stop offset="80%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </linearGradient>
    <filter id="mStopSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="5" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#mStopSh)">
    <!-- Floor Base Flange -->
    <ellipse cx="120" cy="200" rx="45" ry="18" fill="url(#stopperCap)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Post Cylinder Column -->
    <path d="M 95 195 L 105 100 L 135 100 L 145 195 Z" fill="url(#bodyGrad)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Top Magnetic Catch Head -->
    <ellipse cx="120" cy="100" rx="22" ry="12" fill="url(#stopperCap)" stroke="#475569" stroke-width="1.5"/>
    <circle cx="120" cy="98" r="8" fill="#1e293b"/>
    <!-- Door Mounted Disc Catch (Counterpart) -->
    <ellipse cx="205" cy="100" rx="15" ry="25" fill="url(#stopperCap)" stroke="#475569" stroke-width="1.5"/>
    <ellipse cx="200" cy="100" rx="4" ry="12" fill="#334155"/>
    <!-- Magnetic Flux Indicator Lines -->
    <path d="M 148 92 C 165 90 175 92 188 95" fill="none" stroke="#10b981" stroke-width="2" stroke-dasharray="3 3"/>
    <path d="M 148 100 C 165 100 175 100 188 100" fill="none" stroke="#10b981" stroke-width="2" stroke-dasharray="3 3"/>
    <path d="M 148 108 C 165 110 175 108 188 105" fill="none" stroke="#10b981" stroke-width="2" stroke-dasharray="3 3"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">MAGNETIC DOOR STOPPER</text>
</svg>""",

    "chrome_hydraulic_softclose_hinge.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="hydMetal" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="35%" stop-color="#cbd5e1"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <filter id="hydSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="4" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#hydSh)">
    <!-- 35mm Circular Hinge Cup -->
    <ellipse cx="80" cy="150" rx="35" ry="38" fill="url(#hydMetal)" stroke="#64748b" stroke-width="1.5"/>
    <ellipse cx="80" cy="150" rx="24" ry="26" fill="#475569"/>
    <!-- Cup Flange Ear Screwholes -->
    <circle cx="80" cy="105" r="4" fill="#334155"/>
    <circle cx="80" cy="195" r="4" fill="#334155"/>
    <!-- Cantilevered Arm -->
    <path d="M 105 135 L 210 120 L 235 125 L 235 175 L 210 180 L 105 165 Z" fill="url(#hydMetal)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Internal Copper / Brass Hydraulic Piston Cylinder -->
    <rect x="125" y="142" width="45" height="16" rx="4" fill="#f59e0b" stroke="#b45309" stroke-width="1"/>
    <!-- Base Clip-on Mounting Plate -->
    <rect x="195" y="105" width="50" height="90" rx="8" fill="url(#hydMetal)" stroke="#475569" stroke-width="1.5"/>
    <circle cx="220" cy="120" r="4" fill="#1e293b"/>
    <circle cx="220" cy="180" r="4" fill="#1e293b"/>
    <!-- Adjustment Cam Screws -->
    <circle cx="180" cy="150" r="6" fill="#cbd5e1" stroke="#334155"/>
    <line x1="176" y1="150" x2="184" y2="150" stroke="#1e293b" stroke-width="1.5"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">HYDRAULIC SOFT-CLOSE HINGES</text>
</svg>""",

    "chrome_telescopic_drawer_slides.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="slideChrome" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="30%" stop-color="#e2e8f0"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </linearGradient>
    <filter id="slideSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="3" dy="6" stdDeviation="5" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#slideSh)">
    <!-- Outer Fixed Rail -->
    <rect x="40" y="95" width="160" height="40" rx="4" fill="url(#slideChrome)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Middle Intermediate Rail (Extended) -->
    <rect x="80" y="102" width="140" height="26" rx="3" fill="#cbd5e1" stroke="#475569"/>
    <!-- Inner Moving Runner Rail (Extended Out) -->
    <rect x="130" y="108" width="130" height="14" rx="2" fill="url(#slideChrome)" stroke="#334155"/>
    <!-- Ball Bearings in Ball Cage -->
    <circle cx="95" cy="115" r="3.5" fill="#1e293b"/>
    <circle cx="110" cy="115" r="3.5" fill="#1e293b"/>
    <circle cx="125" cy="115" r="3.5" fill="#1e293b"/>
    <circle cx="140" cy="115" r="3.5" fill="#1e293b"/>
    <circle cx="155" cy="115" r="3.5" fill="#1e293b"/>
    <!-- Mounting Holes on Outer Rail -->
    <ellipse cx="55" cy="115" rx="5" ry="3" fill="#334155"/>
    <ellipse cx="180" cy="115" rx="5" ry="3" fill="#334155"/>
    <!-- Second Pair Rail Below -->
    <rect x="40" y="160" width="160" height="40" rx="4" fill="url(#slideChrome)" stroke="#64748b" stroke-width="1.5"/>
    <rect x="80" y="167" width="140" height="26" rx="3" fill="#cbd5e1" stroke="#475569"/>
    <rect x="130" y="173" width="130" height="14" rx="2" fill="url(#slideChrome)" stroke="#334155"/>
    <circle cx="95" cy="180" r="3.5" fill="#1e293b"/>
    <circle cx="110" cy="180" r="3.5" fill="#1e293b"/>
    <circle cx="125" cy="180" r="3.5" fill="#1e293b"/>
    <circle cx="140" cy="180" r="3.5" fill="#1e293b"/>
    <ellipse cx="55" cy="180" rx="5" ry="3" fill="#334155"/>
    <ellipse cx="180" cy="180" rx="5" ry="3" fill="#334155"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">TELESCOPIC DRAWER SLIDES (18")</text>
</svg>""",

    "chrome_glass_door_patch_fitting.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="patchGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="25%" stop-color="#e2e8f0"/>
      <stop offset="55%" stop-color="#94a3b8"/>
      <stop offset="85%" stop-color="#f8fafc"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <filter id="patchSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="4" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.3"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <!-- Translucent Glass Corner Behind -->
  <polygon points="120,40 260,40 260,180 120,180" fill="#38bdf8" opacity="0.15" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="4 4"/>
  <text x="210" y="70" font-family="system-ui, sans-serif" font-size="9" font-weight="bold" fill="#0284c7">12mm TOUGHENED GLASS</text>
  <g filter="url(#patchSh)">
    <!-- Patch Fitting Main Clamp Body -->
    <rect x="60" y="100" width="160" height="95" rx="10" fill="url(#patchGrad)" stroke="#64748b" stroke-width="2"/>
    <rect x="65" y="105" width="150" height="85" rx="8" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
    <!-- Floor Spring Pivot Insert Hole / Bush -->
    <rect x="80" y="170" width="30" height="25" rx="4" fill="#0f172a" stroke="#475569"/>
    <rect x="87" y="178" width="16" height="12" rx="2" fill="#f59e0b"/>
    <!-- Stainless Allen Clamp Bolts -->
    <circle cx="150" cy="130" r="7" fill="#cbd5e1" stroke="#334155"/>
    <circle cx="150" cy="130" r="4" fill="#1e293b"/>
    <circle cx="190" cy="130" r="7" fill="#cbd5e1" stroke="#334155"/>
    <circle cx="190" cy="130" r="4" fill="#1e293b"/>
    <circle cx="150" cy="165" r="7" fill="#cbd5e1" stroke="#334155"/>
    <circle cx="150" cy="165" r="4" fill="#1e293b"/>
    <circle cx="190" cy="165" r="7" fill="#cbd5e1" stroke="#334155"/>
    <circle cx="190" cy="165" r="4" fill="#1e293b"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">GLASS DOOR PATCH FITTING</text>
</svg>""",

    "chrome_shelf_bracket_l_type.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="brkGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="30%" stop-color="#cbd5e1"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <filter id="brkSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="5" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.3"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#brkSh)">
    <!-- Vertical Arm against wall -->
    <rect x="70" y="55" width="20" height="165" rx="4" fill="url(#brkGrad)" stroke="#475569" stroke-width="1.5"/>
    <!-- Horizontal Arm supporting shelf -->
    <rect x="70" y="200" width="165" height="20" rx="4" fill="url(#brkGrad)" stroke="#475569" stroke-width="1.5"/>
    <!-- Diagonal Heavy Support Gusset Brace -->
    <path d="M 85 95 L 205 205 L 180 205 L 85 120 Z" fill="url(#brkGrad)" stroke="#334155" stroke-width="1.5"/>
    <line x1="88" y1="100" x2="200" y2="202" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
    <!-- Mounting Holes on Vertical Leg -->
    <circle cx="80" cy="75" r="4" fill="#1e293b"/>
    <circle cx="80" cy="140" r="4" fill="#1e293b"/>
    <circle cx="80" cy="190" r="4" fill="#1e293b"/>
    <!-- Mounting Holes on Shelf Leg -->
    <circle cx="120" cy="210" r="4" fill="#1e293b"/>
    <circle cx="170" cy="210" r="4" fill="#1e293b"/>
    <circle cx="220" cy="210" r="4" fill="#1e293b"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">CHROME SHELF L-BRACKETS (PAIR)</text>
</svg>""",

    "chrome_towel_rod_bath_fitting.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="towelGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="25%" stop-color="#e2e8f0"/>
      <stop offset="60%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <radialGradient id="towelFlange" cx="35%" cy="35%" r="65%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="50%" stop-color="#cbd5e1"/>
      <stop offset="100%" stop-color="#475569"/>
    </radialGradient>
    <filter id="towSh" x="-20%" y="-20%" width="150%" height="150%">
      <feDropShadow dx="4" dy="8" stdDeviation="6" flood-color="#0f172a" flood-opacity="0.25"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="#f8fafc" rx="16"/>
  <g filter="url(#towSh)">
    <!-- Left Wall Rosette Flange -->
    <circle cx="65" cy="120" r="22" fill="url(#towelFlange)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Right Wall Rosette Flange -->
    <circle cx="235" cy="120" r="22" fill="url(#towelFlange)" stroke="#64748b" stroke-width="1.5"/>
    <!-- Left Projecting Arm -->
    <rect x="65" y="112" width="30" height="16" rx="4" fill="url(#towelGrad)"/>
    <!-- Right Projecting Arm -->
    <rect x="205" y="112" width="30" height="16" rx="4" fill="url(#towelGrad)"/>
    <!-- Upper Main Towel Shelf Bars -->
    <rect x="55" y="105" width="190" height="10" rx="5" fill="url(#towelGrad)" stroke="#475569"/>
    <rect x="55" y="125" width="190" height="10" rx="5" fill="url(#towelGrad)" stroke="#475569"/>
    <!-- Lower Hanging Rail -->
    <path d="M 80 130 L 80 170 L 220 170 L 220 130" fill="none" stroke="url(#towelGrad)" stroke-width="10" stroke-linecap="round"/>
    <line x1="85" y1="168" x2="215" y2="168" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/>
    <!-- Lower Multi-Purpose Robe Hooks -->
    <path d="M 105 170 C 105 195 120 195 120 185" fill="none" stroke="url(#towelGrad)" stroke-width="5" stroke-linecap="round"/>
    <path d="M 150 170 C 150 195 165 195 165 185" fill="none" stroke="url(#towelGrad)" stroke-width="5" stroke-linecap="round"/>
    <path d="M 195 170 C 195 195 210 195 210 185" fill="none" stroke="url(#towelGrad)" stroke-width="5" stroke-linecap="round"/>
  </g>
  <rect x="50" y="255" width="200" height="24" rx="12" fill="#ecfdf5" stroke="#a7f3d0" stroke-width="1"/>
  <text x="150" y="271" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#047857" text-anchor="middle" letter-spacing="1">CHROME BATH TOWEL RACK SET</text>
</svg>"""
}

def generate_svgs():
    count = 0
    for filename, content in CHROME_SVGS.items():
        filepath = SVG_DIR / filename
        filepath.write_text(content.strip(), encoding="utf-8")
        count += 1
    print(f"Generated {count} Chrome Hardware SVG product photographs in {SVG_DIR}")

if __name__ == "__main__":
    generate_svgs()
