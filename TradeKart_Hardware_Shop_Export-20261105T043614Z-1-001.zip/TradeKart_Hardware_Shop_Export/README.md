# TradeKart Hardware & Industrial E-Commerce Platform

A production-ready e-commerce platform built with FastAPI, Jinja2, Tailwind CSS, and SQLite. Features a Hardware Storefront, an Automotive Spare Parts Dealer Portal, and an AI Camera Part Replacement Scanner.

---

## 🚀 Quick Start for Local Desktop Hosting

### 1-Click Launch on Windows
Double-click `start_local_server.bat` in this folder. It will:
1. Verify Python 3.10+
2. Install required dependencies
3. Check and seed the database if missing
4. Start the server on `http://127.0.0.1:8000/`

---

## 💻 Manual Launch (Terminal / PowerShell / Linux / macOS)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional) Re-seed data & images if starting fresh
python seed_data.py
python setup_jpeg_images.py

# 3. Run automated tests (23 tests across Storefront & Spare Parts)
python test_app.py
python test_spare_parts.py

# 4. Start the server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

---

## 🐳 Docker / Container Hosting

```bash
# Build & run in Docker
docker build -t tradekart:latest .
docker run -p 8000:8000 tradekart:latest

# Or using Docker Compose
docker compose up -d
```

---

## 🌐 Local Website URLs & Default Credentials

| Portal | URL | Credentials / Notes |
| :--- | :--- | :--- |
| **Main Hardware Storefront** | [http://127.0.0.1:8000/](http://127.0.0.1:8000/) | Hardware items with Indian Rupee (₹) pricing and Bangalore logistics |
| **Spare Parts Dealer Portal** | [http://127.0.0.1:8000/spare-parts](http://127.0.0.1:8000/spare-parts) | 4W & 2W wholesale automotive parts catalogue |
| **AI Camera Part Scanner** | [http://127.0.0.1:8000/ai-assistant](http://127.0.0.1:8000/ai-assistant) | Live camera scanner & catalog-grounded identification |
| **Retailer Portal Login** | [http://127.0.0.1:8000/spare-parts/login](http://127.0.0.1:8000/spare-parts/login) | **Email:** `retailer@apexmotors.in`<br>**Password:** `Retailer@123` |
| **Shopkeeper Admin Portal** | [http://127.0.0.1:8000/admin/login](http://127.0.0.1:8000/admin/login) | **Email:** `admin@hardwareshop.com`<br>**Password:** `Admin@12345` |
| **Spare Parts Admin Inventory** | [http://127.0.0.1:8000/spare-parts/admin/inventory](http://127.0.0.1:8000/spare-parts/admin/inventory) | Stock tracking, reorder alert thresholds, and image uploader |

---

## 📁 Project Architecture

```
├── app/
│   ├── routes/              # FastAPI routers (storefront, auth, checkout, spare_parts, ai_assistant)
│   ├── services/            # Business logic (inventory, delivery, payments, spare parts, AI scanner)
│   ├── static/              # CSS, JavaScript, and product JPEG photos
│   ├── templates/           # Jinja2 templates (storefront, spare parts portal, admin, AI scanner)
│   ├── auth.py              # PBKDF2 password hashing & token authentication
│   ├── config.py            # Environment settings
│   └── database.py          # SQLite connection manager with WAL mode
├── hardware_shop.db         # SQLite database with pre-populated catalog & users
├── requirements.txt         # Production Python dependencies
├── package.json             # NPM metadata & run scripts
├── Dockerfile               # Container configuration with multi-worker Gunicorn
├── docker-compose.yml       # Docker compose with persistent volumes
├── Procfile                 # Cloud PaaS deployment configuration
├── .env                     # Local environment settings
├── .env.example             # Template for production environment
├── seed_data.py             # Database seed script for hardware items
├── seed_spare_parts.py      # Database seed script for automotive parts
├── setup_jpeg_images.py     # High-resolution JPEG generator & DB migration script
├── test_app.py              # Automated test suite for storefront & AI assistant (12 tests)
├── test_spare_parts.py      # Automated test suite for automotive dealer portal (11 tests)
├── start_local_server.bat   # Windows 1-click launcher
└── start_local_server.ps1   # PowerShell launcher
```
