import sqlite3
from app.database import init_db, get_db
from app.auth import hash_password

def seed_database():
    print("Initializing schema...")
    init_db()

    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Clear existing seed data if needed
        cursor.execute("DELETE FROM portal_notifications")
        cursor.execute("DELETE FROM spare_part_invoices")
        cursor.execute("DELETE FROM spare_part_order_items")
        cursor.execute("DELETE FROM spare_part_orders")
        cursor.execute("DELETE FROM retailers")
        cursor.execute("DELETE FROM spare_parts")
        cursor.execute("DELETE FROM order_items")
        cursor.execute("DELETE FROM orders")
        cursor.execute("DELETE FROM stock_logs")
        cursor.execute("DELETE FROM products")
        cursor.execute("DELETE FROM categories")
        cursor.execute("DELETE FROM users")
        try:
            cursor.execute("DELETE FROM sqlite_sequence")
        except sqlite3.OperationalError:
            pass

        print("Seeding Users (Bangalore, India)...")
        # Admin User
        admin_pwd, admin_salt = hash_password("Admin@12345")
        cursor.execute("""
            INSERT INTO users (email, password_hash, salt, full_name, phone, address, city, postal_code, role)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'admin')
        """, (
            "admin@hardwareshop.com", admin_pwd, admin_salt,
            "Girish Gowda (Shopkeeper)", "+91 80 2839 4567",
            "Shop #42, 8th Main Road, Industrial Suburb, Peenya 2nd Stage", "Bengaluru", "560058"
        ))
        admin_id = cursor.lastrowid

        # Customer User
        cust_pwd, cust_salt = hash_password("Customer@123")
        cursor.execute("""
            INSERT INTO users (email, password_hash, salt, full_name, phone, address, city, postal_code, role)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'customer')
        """, (
            "customer@example.com", cust_pwd, cust_salt,
            "Pooja Sharma", "+91 98450 12345",
            "Flat 402, Green Glen Layout, Bellandur", "Bengaluru", "560103"
        ))
        cust_id = cursor.lastrowid

        print("Seeding Categories...")
        categories_data = [
            ("Chrome Hardware & Accessories", "chrome-hardware-accessories", "Mirror-finish chrome door handles, pulls, tower bolts, hinges, and builder fittings.", "sparkles"),
            ("Door Hardware", "door-hardware", "Architectural brass door knobs, antique levers, and mortise locks.", "key"),
            ("Fasteners & Fixings", "fasteners-fixings", "Hardened screws, hex bolts, anchors, and masonry nails.", "wrench"),
            ("Plumbing Supplies", "plumbing-supplies", "Brass valves, PVC fittings, hoses, and sealant tapes.", "droplet"),
            ("Adhesives & Tapes", "adhesives-tapes", "Industrial duct tapes, electrical insulation, and epoxies.", "paperclip"),
            ("Building Materials", "building-materials", "Portland cement, premixed mortar, and concrete patch.", "package"),
            ("Paints & Finishes", "paints-finishes", "Interior satin latex, exterior weather guard, and primers.", "palette"),
            ("Paint Brushes & Rollers", "paint-brushes-rollers", "Contractor sash brushes, micro-fiber rollers, and trays.", "brush"),
            ("Hand & Power Tools", "hand-power-tools", "Claw hammers, cordless drills, and measuring tapes.", "tool")
        ]

        cat_ids = {}
        for name, slug, desc, icon in categories_data:
            cursor.execute("""
                INSERT INTO categories (name, slug, description, icon)
                VALUES (?, ?, ?, ?)
            """, (name, slug, desc, icon))
            cat_ids[slug] = cursor.lastrowid

        print("Seeding Hardware Products with Indian INR Pricing...")
        products = [
            # 1. Door Hardware (including antique-style knob)
            (
                "Victorian Antique Brass Mortise Door Knob",
                "antique-brass-door-knob",
                cat_ids["door-hardware"],
                "HW-KNB-001",
                "Authentic hand-forged solid brass door knob with aged antique patina and ornate beaded rosette. Suitable for interior and exterior teak/hardwood doors.",
                "Material: Solid Forged Brass\nProjection: 65 mm\nRosette Diameter: 70 mm\nSpindle: 8mm square\nFinish: Antique Aged Brass Patina",
                1450.00,
                14, # stock
                5,  # reorder point
                "/static/images/products/antique_brass_knob.jpg"
            ),
            (
                "Modern Satin Nickel Round Privacy Knob",
                "modern-satin-nickel-knob",
                cat_ids["door-hardware"],
                "HW-KNB-002",
                "Contemporary satin nickel interior door knob with reversible latch and integrated thumb-turn privacy lock for bathrooms and bedrooms.",
                "Material: Zinc Alloy with Satin Nickel Plating\nBackset: Adjustable 60mm to 70mm\nDoor Thickness: 35mm to 45mm",
                890.00,
                4, # Low stock (under reorder threshold!)
                6,
                "/static/images/products/modern_satin_knob.jpg"
            ),
            (
                "Brushed Nickel Heavy-Duty Lever Handle",
                "brushed-nickel-lever-handle",
                cat_ids["door-hardware"],
                "HW-HDL-001",
                "Commercial-grade ergonomic architectural lever handle. Smooth high-durability internal spring mechanism tested to 400,000 cycles.",
                "Finish: Brushed Nickel\nRating: Heavy Duty Residential & Commercial\nHanding: Universal Reversible",
                1150.00,
                22,
                5,
                "/static/images/products/brushed_nickel_handle.jpg"
            ),
            (
                "Matte Black Solid Straight Pull Handle",
                "matte-black-straight-pull-handle",
                cat_ids["door-hardware"],
                "HW-HDL-002",
                "Minimalist architectural matte black pull handle for main entrance doors, sliding wooden partitions, and cabinet joinery.",
                "Material: Forged Carbon Steel\nFinish: Electrostatic Matte Black Powder Coat\nLength: 250 mm (10 inches)",
                650.00,
                2, # Critical low stock! (<= 3)
                5,
                "/static/images/products/matte_black_lever.jpg"
            ),

            # 2. Fasteners & Fixings
            (
                "Galvanized Multi-Purpose Wood Screws (Box of 200)",
                "galvanized-wood-screws-200",
                cat_ids["fasteners-fixings"],
                "HW-SCR-001",
                "Self-drilling Torx drive countersunk wood screws with corrosion-resistant yellow zinc galvanization. Cuts cleanly into hardwood and timber framing without splitting.",
                "Size: #8 x 65 mm (2.5 Inch)\nDrive: T-20 Torx Star Drive\nQuantity: 200 Pieces per tub\nCoating: Yellow Zinc Dichromate Anti-Rust",
                320.00,
                45,
                10,
                "/static/images/products/wood_screws_pack.jpg"
            ),
            (
                "High-Tensile Grade 8 Hex Head Bolt & Nut Set",
                "hex-bolts-nuts-set",
                cat_ids["fasteners-fixings"],
                "HW-BLT-001",
                "High-strength alloy steel hex bolts, washers, and locking nylon-insert nuts for heavy automotive, structural framing, and machinery mounting.",
                "Grade: High-Tensile 8.8 Structural Alloy Steel\nSize: M10 x 75 mm\nIncluded: 25 Bolts, 25 Lock Nuts, 50 Washers",
                480.00,
                30,
                8,
                "/static/images/products/hex_bolts_set.jpg"
            ),

            # 3. Plumbing Supplies
            (
                "1-Inch Heavy Forged Brass Ball Valve (Full Port)",
                "brass-ball-valve-1-inch",
                cat_ids["plumbing-supplies"],
                "HW-PLM-001",
                "Contractor-grade heavy forged brass ball valve with blowout-proof stem, PTFE Teflon seals, and vinyl-coated steel lever handle for quick 1/4-turn shutoff.",
                "Connection: 25 mm (1-Inch) Female BSP Thread\nPressure Rating: PN25 Heavy Duty\nMaterial: Heavy Forged CW617N Lead-Free Brass",
                620.00,
                18,
                5,
                "/static/images/products/brass_ball_valve.jpg"
            ),
            (
                "Schedule 40 PVC 90-Degree Socket Elbow (1-1/4\")",
                "pvc-elbow-socket-pipe",
                cat_ids["plumbing-supplies"],
                "HW-PLM-002",
                "Rigid PVC pressure elbow fitting for potable water supply, irrigation piping, and drainage networks. High impact resistance.",
                "Material: Heavy-Duty PVC Class 40\nSize: 32 mm (1-1/4 Inch) Socket x Socket\nStandards: IS 4985 Indian Standards Compliant",
                65.00,
                80,
                20,
                "/static/images/products/pvc_elbow_pipe.jpg"
            ),
            (
                "High-Density PTFE Plumbing Thread Seal Tape (5-Pack)",
                "ptfe-plumbing-teflon-tape",
                cat_ids["plumbing-supplies"],
                "HW-TAP-002",
                "Professional-grade teflon thread sealant tape for water lines, gas connections, and threaded pipe joints. Provides watertight, pressure-tight sealing.",
                "Thickness: 0.1 mm High-Density\nWidth: 12 mm (1/2 Inch)\nLength: 12 Meters per roll\nQuantity: 5 Spools",
                180.00,
                50,
                15,
                "/static/images/products/teflon_plumbing_tape.jpg"
            ),

            # 4. Adhesives & Tapes
            (
                "Heavy-Duty All-Weather Waterproof Duct Tape",
                "heavy-duty-duct-tape-all-weather",
                cat_ids["adhesives-tapes"],
                "HW-TAP-001",
                "Extreme-strength adhesive tape with double-thick rubber adhesive and triple-layer reinforced mesh backing. Bonds to wood, stone, metal, and rough masonry.",
                "Width: 48 mm (2 Inches)\nLength: 30 Meters\nThickness: 17 mil\nOperating Temp: -20°C to 80°C",
                340.00,
                3, # Critical low stock! (<= 3)
                8,
                "/static/images/products/heavy_duty_duct_tape.jpg"
            ),
            (
                "Flame-Retardant Vinyl Electrical Tape (3-Pack)",
                "electrical-insulation-tape-3pack",
                cat_ids["adhesives-tapes"],
                "HW-TAP-003",
                "ISI-certified professional PVC electrical insulating tape rated for wire splices up to 650V and temperatures up to 105°C.",
                "Width: 18 mm (3/4 Inch)\nLength: 10 Meters per roll\nVoltage Rating: 650V\nStandards: IS 7809 Certified",
                120.00,
                40,
                10,
                "/static/images/products/electrical_insulation_tape.jpg"
            ),

            # 5. Building Materials
            (
                "Portland Cement Type I/II - 50 kg Heavy Sack",
                "portland-cement-50kg-sack",
                cat_ids["building-materials"],
                "HW-CEM-001",
                "Commercial-grade 53-grade high-strength Portland cement. Ideal for RCC structural concrete, foundations, columns, slabs, and exterior plastering.",
                "Weight: 50 Kilograms (1 Bag)\nGrade: OPC 53 Grade / PPC High Durability\nStandards: IS 12269 Indian Standards\nHandling: Direct warehouse dispatch in Bangalore",
                420.00,
                35,
                15,
                "/static/images/products/portland_cement_sack.jpg"
            ),
            (
                "Fast-Setting Concrete Repair Mortar Patch (20 kg)",
                "fast-setting-concrete-mortar-patch",
                cat_ids["building-materials"],
                "HW-CEM-002",
                "Premixed hydraulic polymer-modified cement mortar for repairing cracks, spalled concrete walkways, steps, and foundation walls. Sets rock-hard in 20 minutes.",
                "Weight: 20 Kilograms Tub\nSet Time: 15 to 20 Minutes\nCompressive Strength: 40 MPa at 28 days",
                550.00,
                12,
                6,
                "/static/images/products/concrete_repair_mortar.jpg"
            ),

            # 6. Paints & Finishes
            (
                "Interior Satin Acrylic Latex Wall Paint (4 Litres)",
                "interior-satin-acrylic-latex-paint",
                cat_ids["paints-finishes"],
                "HW-PNT-001",
                "Ultra-durable, low-VOC paint and primer in one. Washable satin sheen engineered for living rooms, kitchens, hallways, and high-traffic family areas.",
                "Volume: 4 Litres Can\nSheen: Smooth Washable Satin\nCoverage: 120-140 sq ft per litre (2 coats)\nDry Time: 1 Hour to touch, recoat in 4 hours",
                1650.00,
                19,
                5,
                "/static/images/products/interior_eggshell_paint.jpg"
            ),
            (
                "Weather-Guard Exterior 100% Acrylic House Paint (4 Litres)",
                "weather-guard-exterior-acrylic-paint",
                cat_ids["paints-finishes"],
                "HW-PNT-002",
                "Maximum tropical monsoon UV and rain-resistant exterior coating for plaster, concrete, and brick walls. Resists peeling, algae, and fungal growth.",
                "Volume: 4 Litres Can\nTechnology: 100% Acrylic Cross-Linking Resin with PU Protection\nWarranty: 7-Year Weatherproof Guarantee",
                2100.00,
                8,
                4,
                "/static/images/products/exterior_weather_paint.jpg"
            ),

            # 7. Paint Brushes & Rollers
            (
                "Professional 2.5-Inch Angled Sash Paint Brush",
                "professional-angled-sash-paint-brush",
                cat_ids["paint-brushes-rollers"],
                "HW-BRS-001",
                "Handcrafted precision brush with flagged tipped synthetic filament blend and stainless steel ferrule for crisp cutting-in and trim lines.",
                "Brush Width: 65 mm (2.5 Inches)\nCut: Precision Angled Sash\nBristle: High-Density Synthetic SRT Filament\nHandle: Ergonomic Varnished Teak Wood Handle",
                280.00,
                1, # Critical stock: only 1 left!
                6,
                "/static/images/products/angled_paint_brush.jpg"
            ),
            (
                "9-Inch Microfiber Wall Paint Roller Kit with Tray",
                "paint-roller-kit-9-inch",
                cat_ids["paint-brushes-rollers"],
                "HW-BRS-002",
                "Complete painting set including 9\" heavy-duty cage frame, 2 high-density microfiber lint-free roller sleeves (10mm nap), and deep-well paint tray.",
                "Sleeve Width: 225 mm (9 Inches)\nNap Height: 10 mm (Smooth to Semi-Smooth Plaster Walls)\nIncludes: 1 Sturdy Roller Frame, 2 Microfiber Covers, 1 Heavy Duty Tray",
                450.00,
                24,
                8,
                "/static/images/products/wall_paint_roller_kit.jpg"
            ),

            # 8. Hand & Power Tools
            (
                "16-Ounce Drop-Forged Steel Claw Hammer",
                "steel-claw-hammer-16oz",
                cat_ids["hand-power-tools"],
                "HW-TOL-001",
                "Single-piece drop-forged alloy steel hammer with magnetic nail starter, polished face, and anti-vibration shock-reduction rubber handle grip.",
                "Head Weight: 450 Grams (16 Ounces)\nConstruction: Monobloc Solid Forged High-Carbon Steel\nHandle: Ergonomic Anti-Slip TPR Rubber Grip\nClaw: Curved High-Leverage Nail Puller",
                499.00,
                16,
                5,
                "/static/images/products/claw_hammer_steel.jpg"
            ),
            (
                "20V Max Lithium-Ion Cordless Drill Driver Kit",
                "cordless-drill-driver-kit-20v",
                cat_ids["hand-power-tools"],
                "HW-TOL-002",
                "High-performance 2-speed cordless drill delivering 45 Nm of torque. Includes 2.0Ah battery, 45-minute rapid charger, and 10-piece titanium drill bit set.",
                "Motor: High-Torque 2-Speed (0-450 / 0-1,500 RPM)\nChuck: 13 mm (1/2-Inch) Keyless All-Metal Ratcheting\nBattery: 20V Max 2.0Ah Lithium-Ion\nLED: Integrated Workspace Illuminator",
                3850.00,
                7,
                3,
                "/static/images/products/cordless_power_drill.jpg"
            ),
            (
                "25-Foot Heavy-Duty Contractor Locking Tape Measure (7.5m)",
                "locking-tape-measure-25ft",
                cat_ids["hand-power-tools"],
                "HW-TOL-003",
                "Impact-resistant rubberized casing with 28mm wide nylon-coated blade offering up to 3.5m of standout. Features metric & inch dual markings.",
                "Blade Length: 7.5 Meters (25 Feet)\nBlade Width: 28 mm\nStandout: Up to 3.5 Meters\nScale: Dual Metric (cm/mm) & Imperial (Inches) Markings",
                390.00,
                32,
                6,
                "/static/images/products/heavy_measuring_tape.jpg"
            ),

            # 9. Chrome Hardware & Accessories (IndiaMART Catalog Integration)
            (
                "Designer Mirror Chrome Mortise Door Handle Set with Lock",
                "chrome-mortise-door-handle-set",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-001",
                "Premium mirror-finish chrome plated mortise door handle pair featuring reversible brass latch mechanism and Euro profile computer key cylinder. Multi-layer anti-tarnish electroplating for luxury main entrance and bedroom doors.",
                "Material: Solid Virgin Zinc Alloy & Brass Internals\nFinish: Triple-Layer Mirror Polish Chrome\nBackset: 60 mm / Plate Size: 200 mm x 45 mm\nKeys: 3 Computer Dimple Security Keys\nSalt Spray Rating: 96-hr Neutral Salt Spray (NSS) Tested",
                1250.00,
                35,
                10,
                "/static/images/products/designer_mortise_handle.jpg"
            ),
            (
                "Heavy-Duty Stainless Steel Chrome D-Pull Main Door Handle (12\")",
                "chrome-main-door-d-pull-handle-12in",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-002",
                "Contemporary tubular D-shaped entrance pull handle manufactured from premium grade stainless steel with high-buff mirror chrome electroplating. Suitable for wooden, metal, and glass main entrance doors.",
                "Material: Grade 304 Stainless Steel with Mirror Chrome Finish\nLength: 300 mm (12 Inches)\nTube Diameter: 25 mm\nHole-to-Hole Distance: 200 mm\nMounting: Back-to-Back Bolt-Through & Concealed Screws Included",
                780.00,
                42,
                12,
                "/static/images/products/chrome_pull_handle_main_door.jpg"
            ),
            (
                "Sleek Chrome Slim Bar Cabinet & Wardrobe Pull Handles (Pack of 6)",
                "chrome-cabinet-wardrobe-pull-pack-6",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-003",
                "Ergonomic architectural bow-bar cabinet handles finished in radiant mirror chrome. Engineered for kitchen modular cabinets, bedroom wardrobes, and bathroom vanity drawers. Includes M4 mounting machine screws.",
                "Material: Solid Die-Cast Zinc Alloy\nOverall Length: 160 mm\nCenter-to-Center Hole Distance: 128 mm (Standard Modular Size)\nProjection: 28 mm\nPack: 6 Handles with 12 M4 Screws",
                540.00,
                50,
                15,
                "/static/images/products/chrome_cabinet_wardrobe_pull.jpg"
            ),
            (
                "Heavy-Duty Solid Brass Chrome Plated Barrel Tower Bolt (8\")",
                "chrome-heavy-duty-tower-bolt-8in",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-004",
                "Precision-extruded solid brass tower bolt (chitkani) with mirror-finish chrome coating. Features a 10mm thick hardened brass shoot bolt, anti-rattle friction spring, and heavy strike plate for primary room and balcony door locking.",
                "Material: Solid Forged Brass with Thick Chrome Electroplating\nLength: 200 mm (8 Inches)\nShoot Bolt Diameter: 10 mm Solid Rod\nIncludes: 6 Matching SS Screws & Receiver Keeper Plate\nOperation: Friction Tension Ball Catch",
                340.00,
                60,
                15,
                "/static/images/products/chrome_heavy_tower_bolt.jpg"
            ),
            (
                "Chrome Plated Ball Bearing Butt Door Hinges (4\"x3\"x3mm - Pair)",
                "chrome-ball-bearing-butt-hinges-pair",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-005",
                "Architectural grade stainless steel butt hinges featuring four self-lubricating ball bearings and high-lustre chrome polish. Engineered for silent, friction-free swinging of heavy solid teak and flush doors up to 80kg load.",
                "Material: High-Grade Stainless Steel with Chrome Finish\nDimensions: 102 mm x 76 mm x 3.0 mm (4\" x 3\")\nBearings: 4 Precision Anti-Friction Ball Bearings\nWeight Capacity: Up to 80 kg per pair\nIncludes: 16 Countersunk Hardened Screws",
                420.00,
                80,
                20,
                "/static/images/products/chrome_bearing_door_hinges.jpg"
            ),
            (
                "Traditional Heavy Security Chrome Plated Aldrop Door Latch (10\")",
                "chrome-aldrop-door-latch-10in",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-006",
                "Classic Indian style security aldrop kit with heavy 14mm central sliding bolt, ornate floral brackets, and padlock hasp. Mirror chrome plated for weather resistance on front and double-shutter doors.",
                "Material: Heavy Forged Carbon Steel & Brass Core with Mirror Chrome Coating\nRod Length: 250 mm (10 Inches)\nRod Diameter: 14 mm Solid Bar\nKit: 1 Main Aldrop Rod, 2 Supporting Guide Brackets, 1 Padlock Hasp, 1 Strike Plate & Carriage Bolts",
                680.00,
                28,
                8,
                "/static/images/products/chrome_aldrop_latch_set.jpg"
            ),
            (
                "Dual-Mount Chrome Magnetic Door Stopper & Wall Catch",
                "chrome-magnetic-door-stopper-catch",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-007",
                "Smart concealed magnetic door holder with strong neodymium core that firmly catches doors to prevent wall damage from wind gusts. Dual floor or skirting board mounting capability.",
                "Material: Solid Die-Cast Zinc Alloy / Mirror Chrome\nBase Diameter: 50 mm / Catch Height: 75 mm\nHolding Power: 6 kg Neodymium Magnetic Pull Force\nInstallation: Floor or Wall Installation with expansion anchor bolts included",
                240.00,
                65,
                15,
                "/static/images/products/chrome_magnetic_door_stopper.jpg"
            ),
            (
                "Chrome Soft-Close Hydraulic Concealed Cabinet Hinges (4 Pairs)",
                "chrome-hydraulic-soft-close-cabinet-hinges-4pairs",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-008",
                "Full overlay (0 crank) hydraulic soft-closing furniture hinges with clip-on mounting plates and built-in copper hydraulic pistons. Prevents slamming of modular kitchen and wardrobe shutters.",
                "Type: Full Overlay (0 Crank), 105-Degree Opening Angle\nCup Diameter: 35 mm (Standard European Cup Drilling)\nMaterial: Cold-Rolled Steel with Double Chrome & Nickel Plating\nCycle Test: 50,000 Open/Close Cycles Certified\nPack: 4 Pairs (8 Hinges) with Mounting Plates & Screws",
                590.00,
                45,
                10,
                "/static/images/products/chrome_hydraulic_softclose_hinge.jpg"
            ),
            (
                "Heavy-Duty Telescopic Ball Bearing Drawer Slides (18\" - Pair)",
                "chrome-telescopic-drawer-slides-18in-pair",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-009",
                "Three-fold full extension drawer channels with double row solid steel ball bearings for smooth, whisper-quiet glide. Supports heavy kitchen pot drawers and office file cabinets up to 45kg.",
                "Length: 450 mm (18 Inches) Closed / 900 mm Fully Extended\nLoad Capacity: 45 kg per pair\nProfile Width: 45 mm Standard Industry Dimension\nMaterial: Hardened Q235 Steel with Anti-Corrosion Chrome Finish\nDisassembly: Quick-release plastic lever mechanism",
                460.00,
                55,
                12,
                "/static/images/products/chrome_telescopic_drawer_slides.jpg"
            ),
            (
                "Mirror Chrome Toughened Glass Door Top & Bottom Patch Fitting Set",
                "chrome-glass-door-patch-fitting-set",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-010",
                "Commercial architectural patch fittings for 10mm to 12mm frameless toughened glass entrance doors. High-grade alloy body enclosed in brilliant mirror-finish stainless steel chrome covers.",
                "Glass Compatibility: 10 mm - 12 mm Frameless Toughened Safety Glass\nMaterial: High Strength Aluminium Alloy Body with SS 304 Chrome Cover Plates\nGaskets: High Elasticity Anti-Slip Neoprene Rubber Gaskets\nFits: Standard Floor Spring Spindle and Top Pivot Plugs",
                1450.00,
                20,
                5,
                "/static/images/products/chrome_glass_door_patch_fitting.jpg"
            ),
            (
                "Heavy-Duty Ornamental Chrome Shelf L-Brackets (10\"x12\" - Pair)",
                "chrome-shelf-l-brackets-10x12in-pair",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-011",
                "Heavy gauge steel wall brackets featuring an integrated diagonal brace and mirror chrome plating. Holds glass, granite, or wood shelving in retail showrooms, kitchens, and modern living spaces.",
                "Dimensions: 250 mm x 300 mm (10\" x 12\")\nWeight Capacity: 70 kg per pair\nMaterial: 4mm Heavy Gauge Carbon Steel / Bright Chrome Electroplating\nIncludes: 6 Heavy Duty Wall Plugs & Matching Chrome Finish Screws",
                380.00,
                40,
                10,
                "/static/images/products/chrome_shelf_bracket_l_type.jpg"
            ),
            (
                "Luxury Chrome Plated Bathroom Towel Rack & Robe Hook Set (24\")",
                "chrome-bathroom-towel-rack-robe-hook-set",
                cat_ids["chrome-hardware-accessories"],
                "HW-CHM-012",
                "Complete hotel-grade 24-inch dual-tier towel organizer with top shelf, lower hanging bar, and 4 multi-purpose robe hooks. 100% moisture-proof and rust-proof mirror chrome electroplating.",
                "Length: 600 mm (24 Inches) / Depth: 220 mm\nMaterial: Virgin Brass Base with High-Micron Mirror Chrome Polish\nInstallation: Wall Mounted with Concealed SS Screws & Wall Plugs\nWarranty: 5 Years Anti-Rust Surface Warranty",
                1150.00,
                30,
                8,
                "/static/images/products/chrome_towel_rod_bath_fitting.jpg"
            )
        ]

        prod_by_sku = {}
        for p in products:
            cursor.execute("""
                INSERT INTO products (
                    name, slug, category_id, sku, description, specifications,
                    price, stock_quantity, reorder_point, image_url, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            """, p)
            prod_id = cursor.lastrowid
            prod_by_sku[p[3]] = prod_id
            
            # Record initial inventory stock log
            cursor.execute("""
                INSERT INTO stock_logs (product_id, change_amount, previous_stock, new_stock, reason, reference_id)
                VALUES (?, ?, 0, ?, 'initial_seed', 'SEED-2026')
            """, (prod_id, p[7], p[7]))

        print("Seeding Sample Orders with Invoices & Logistics (Bangalore)...")
        # Order 1: Delivered Home Delivery Order for customer Pooja Sharma in Bellandur, Bengaluru
        # Subtotal: 2 * 1450 (Knob) + 1 * 1650 (Paint) + 1 * 120 (Tape) = 4670.00
        # Free delivery over 1500 -> 0.00
        # GST (18%) = 4670 * 0.18 = 840.60
        # Total = 5510.60
        cursor.execute("""
            INSERT INTO orders (
                order_number, user_id, customer_name, customer_email, customer_phone,
                delivery_method, delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
                subtotal, delivery_fee, tax_amount, total_amount,
                payment_status, payment_provider, payment_transaction_id,
                order_status, tracking_number, carrier_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "ORD-20261025-A109", cust_id, "Pooja Sharma", "customer@example.com", "+91 98450 12345",
            "delivery", "Flat 402, Green Glen Layout, Bellandur", "Bengaluru", "Karnataka", "560103", "Near Central Mall, call on arrival",
            4670.00, 0.00, 840.60, 5510.60,
            "paid", "mock_payment_sandbox", "mock_tx_90184A91",
            "delivered", "BLR-109-77BA", "Bangalore Express Cargo Van (Tata Ace)",
            "2026-10-25 14:22:10"
        ))
        ord1_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, 'Victorian Antique Brass Mortise Door Knob', 'HW-KNB-001', 1450.00, 2, 2900.00)
        """, (ord1_id, prod_by_sku["HW-KNB-001"]))
        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, 'Interior Satin Acrylic Latex Wall Paint (4 Litres)', 'HW-PNT-001', 1650.00, 1, 1650.00)
        """, (ord1_id, prod_by_sku["HW-PNT-001"]))
        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, 'Flame-Retardant Vinyl Electrical Tape (3-Pack)', 'HW-TAP-003', 120.00, 1, 120.00)
        """, (ord1_id, prod_by_sku["HW-TAP-003"]))

        # Order 2: In-Store Pickup Order for contractor Ramesh Kumar in Peenya
        # 10 bags cement = 10 * 420 = 4200.00
        # Pickup fee = 0
        # GST 18% = 756.00
        # Total = 4956.00
        cursor.execute("""
            INSERT INTO orders (
                order_number, user_id, customer_name, customer_email, customer_phone,
                delivery_method, delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
                subtotal, delivery_fee, tax_amount, total_amount,
                payment_status, payment_provider, payment_transaction_id,
                order_status, tracking_number, carrier_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "ORD-20261027-C882", None, "Ramesh Kumar (Civil Contractor)", "ramesh@karnatakabuilders.in", "+91 94480 55678",
            "pickup", "", "Bengaluru", "Karnataka", "560058", "Picking up with Mahindra Bolero pickup truck at 10 AM",
            4200.00, 0.00, 756.00, 4956.00,
            "paid", "stripe", "ch_stripe_test_88291047",
            "ready_for_pickup", "PICKUP-PEENYA-088", "Peenya Trade Counter",
            "2026-10-27 10:15:00"
        ))
        ord2_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, 'Portland Cement Type I/II - 50 kg Heavy Sack', 'HW-CEM-001', 420.00, 10, 4200.00)
        """, (ord2_id, prod_by_sku["HW-CEM-001"]))

        # Order 3: Active Dispatched Delivery in Indiranagar
        # 2x Brass valve (620*2 = 1240) + 1x PTFE tape (180) + 1x Claw hammer (499) = 1919.00
        # Free delivery over 1500 -> 0.00
        # GST 18% = 345.42
        # Total = 2264.42
        cursor.execute("""
            INSERT INTO orders (
                order_number, user_id, customer_name, customer_email, customer_phone,
                delivery_method, delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
                subtotal, delivery_fee, tax_amount, total_amount,
                payment_status, payment_provider, payment_transaction_id,
                order_status, tracking_number, carrier_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "ORD-20261028-D339", cust_id, "Pooja Sharma", "customer@example.com", "+91 98450 12345",
            "delivery", "Flat 402, Green Glen Layout, Bellandur", "Bengaluru", "Karnataka", "560103", "Handle with care, plumbing fittings and tools",
            1919.00, 0.00, 345.42, 2264.42,
            "paid", "mock_payment_sandbox", "mock_tx_883391AF",
            "dispatched", "BLR-339-99FF", "Bangalore Express Cargo Van (Tata Ace)",
            "2026-10-28 09:30:15"
        ))
        ord3_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, '1-Inch Heavy Forged Brass Ball Valve (Full Port)', 'HW-PLM-001', 620.00, 2, 1240.00)
        """, (ord3_id, prod_by_sku["HW-PLM-001"]))
        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, 'High-Density PTFE Plumbing Thread Seal Tape (5-Pack)', 'HW-TAP-002', 180.00, 1, 180.00)
        """, (ord3_id, prod_by_sku["HW-TAP-002"]))
        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal)
            VALUES (?, ?, '16-Ounce Drop-Forged Steel Claw Hammer', 'HW-TOL-001', 499.00, 1, 499.00)
        """, (ord3_id, prod_by_sku["HW-TOL-001"]))

    print("Database seeding completed successfully with Indian pricing and Bangalore address!")

    # Also seed spare parts portal data
    try:
        from seed_spare_parts import seed_spare_parts_data
        seed_spare_parts_data()
    except Exception as e:
        print(f"Notice: spare parts seed failed: {e}")

if __name__ == "__main__":
    seed_database()
