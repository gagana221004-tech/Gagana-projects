"""
Seed script for Spare Parts Dealer Portal (Automobile Wholesale & Retail).
Populates 4-wheeler and 2-wheeler brands, categories, illustrative wholesale parts,
retailer garage accounts, sample orders, tax invoices, and notifications.
"""
from app.database import get_db, init_db
from app.auth import hash_password

def seed_spare_parts_data():
    init_db()
    
    with get_db() as conn:
        cursor = conn.cursor()
        
        # 1. Clear existing spare parts tables
        cursor.execute("DELETE FROM portal_notifications")
        cursor.execute("DELETE FROM spare_part_invoices")
        cursor.execute("DELETE FROM spare_part_order_items")
        cursor.execute("DELETE FROM spare_part_orders")
        cursor.execute("DELETE FROM retailers")
        cursor.execute("DELETE FROM users WHERE role = 'retailer'")
        cursor.execute("DELETE FROM spare_parts")
        
        print("Seeding Automobile Spare Parts Catalog (4W & 2W)...")
        
        # 2. Insert Spare Parts
        # Categories:
        # Engine Parts, Brake System, Electrical, Filters, Suspension, Transmission, Exterior, Two-wheeler Parts, Accessories
        #
        # Specific user-requested illustrative wholesale prices:
        # - Oil Filter (Tata/Hyundai) ₹250 (Stock: 250, Reorder: 50 as in user prompt)
        # - Air Filter (Maruti Suzuki) ₹350
        # - Brake Pad Set (Toyota/Tata) ₹850
        # - Spark Plug (Honda/Hyundai) ₹180
        # - Clutch Plate (Mahindra) ₹1,450
        # - Shock Absorber (Maruti Suzuki) ₹1,800
        # - Headlight Assembly (Tata) ₹2,500
        # - Car Battery (universal fitment varies) ₹3,500
        # - Bike Chain Kit (Bajaj/Hero) ₹650
        # - Bike Brake Shoe (Honda/TVS) ₹280
        # - Bike Clutch Plate (Royal Enfield) ₹950
        # - Bike Air Filter (Yamaha) ₹220
        
        parts_data = [
            # 1. Oil Filter (Tata/Hyundai) - Prompt specified 250 in stock, reorder 50
            (
                "Spin-On Engine Oil Filter (Tata & Hyundai)",
                "spin-on-engine-oil-filter-tata-hyundai",
                "SP-FLT-TAT-01",
                "four_wheeler",
                "Tata Motors",
                "Tata Nexon, Harrier, Safari / Hyundai Creta, Venue, i20 (1.4L/1.5L Diesel & Petrol)",
                "Filters",
                250.00,  # Wholesale Price (illustrative)
                420.00,  # Suggested Retail Price
                180.00,  # Cost Price
                250,     # Stock Quantity (as specified in user prompt)
                50,      # Reorder Point (as specified in user prompt)
                10,      # MOQ
                "/static/images/spare_parts/oil_filter.jpg",
                "OEM specification spin-on oil filter with high-capacity synthetic blend media, anti-drainback silicone valve, and heavy-gauge steel housing.",
                "Media: Synthetic Blend\nBurst Strength: 280 PSI\nThread Size: M20 x 1.5\nEfficiency: 99% at 20 Microns"
            ),
            # 2. Air Filter (Maruti Suzuki)
            (
                "High-Flow Engine Air Filter (Maruti Suzuki)",
                "high-flow-engine-air-filter-maruti-suzuki",
                "SP-FLT-MS-02",
                "four_wheeler",
                "Maruti Suzuki",
                "Swift, Dzire, Baleno, Brezza, Ertiga (K12N / K15B Petrol)",
                "Filters",
                350.00,
                550.00,
                240.00,
                180,
                30,
                10,
                "/static/images/spare_parts/air_filter.jpg",
                "Precision-fit polyurethane framed engine air filter with multi-fiber pleated filtration to shield injection systems from fine dust and road grit.",
                "Frame Material: Molded Polyurethane\nFiltration Grade: ISO 5011 Certified\nReplacement Interval: 15,000 km"
            ),
            # 3. Brake Pad Set (Toyota/Tata)
            (
                "Ceramic Front Brake Pad Set (Toyota & Tata)",
                "ceramic-front-brake-pad-set-toyota-tata",
                "SP-BRK-TOY-03",
                "four_wheeler",
                "Toyota",
                "Toyota Innova Crysta, Fortuner / Tata Harrier, Safari",
                "Brake System",
                850.00,
                1450.00,
                580.00,
                95,
                20,
                5,
                "/static/images/spare_parts/brake_pad_set.jpg",
                "Low-dust premium ceramic formulation brake pads engineered with multi-layer noise-dampening shims and scorched friction surface for immediate bed-in.",
                "Friction Material: Copper-Free Ceramic\nOperating Temp: 0°C to 650°C\nIncludes: 4-piece Axle Set with Caliper Shims"
            ),
            # 4. Spark Plug (Honda/Hyundai)
            (
                "Iridium Power Spark Plug (Honda & Hyundai)",
                "iridium-power-spark-plug-honda-hyundai",
                "SP-ELE-HND-04",
                "four_wheeler",
                "Honda",
                "Honda City, Civic, Amaze / Hyundai Verna, Creta (1.5L i-VTEC / MPi)",
                "Electrical",
                180.00,
                320.00,
                120.00,
                320,
                40,
                20,
                "/static/images/spare_parts/spark_plug.jpg",
                "0.6mm ultra-fine laser welded iridium center electrode offering enhanced ignitability, smoother idling, and extended service life up to 100,000 km.",
                "Thread Diameter: 14 mm\nReach: 19 mm\nHex Size: 16 mm\nHeat Range: 6"
            ),
            # 5. Clutch Plate (Mahindra)
            (
                "Heavy-Duty Clutch Friction Plate (Mahindra)",
                "heavy-duty-clutch-friction-plate-mahindra",
                "SP-TRN-MAH-05",
                "four_wheeler",
                "Mahindra",
                "Mahindra Thar, Scorpio-N, XUV700, Bolero Neo (2.2L mHawk Diesel)",
                "Transmission",
                1450.00,
                2400.00,
                1050.00,
                45,
                12,
                4,
                "/static/images/spare_parts/clutch_plate.jpg",
                "Reinforced organic friction material bonded to heat-treated high-tensile steel hub with heavy torsional damping springs to minimize drivetrain shudder.",
                "Disc Diameter: 240 mm\nSpline Count: 23 Teeth\nMajor Hub Diameter: 26 mm\nRating: High-Torque Commercial & 4x4"
            ),
            # 6. Shock Absorber (Maruti Suzuki)
            (
                "Gas-Charged Front Shock Absorber Strut (Maruti Suzuki)",
                "gas-charged-front-shock-absorber-maruti-suzuki",
                "SP-SUS-MS-06",
                "four_wheeler",
                "Maruti Suzuki",
                "Maruti Swift, Baleno, Dzire (2018 - 2024 Models)",
                "Suspension",
                1800.00,
                2950.00,
                1350.00,
                60,
                15,
                2,
                "/static/images/spare_parts/shock_absorber.jpg",
                "Twin-tube nitrogen gas-charged suspension strut featuring multi-lip Teflon seals and hard-chromed micro-crack piston rod for stable damping over rough roads.",
                "Type: Twin-Tube Gas Charged\nPosition: Front Axle (Universal L/R)\nStroke Length: 155 mm"
            ),
            # 7. Headlight Assembly (Tata)
            (
                "Bi-LED Projector Headlight Assembly (Tata Motors)",
                "bi-led-projector-headlight-assembly-tata",
                "SP-ELE-TAT-07",
                "four_wheeler",
                "Tata Motors",
                "Tata Nexon EV, Nexon Facelift (2020 - 2024)",
                "Electrical",
                2500.00,
                4200.00,
                1850.00,
                38,
                10,
                2,
                "/static/images/spare_parts/headlight_assembly.jpg",
                "High-output integrated bi-LED projector headlamp unit with daylight running light (DRL) light guide and optical polycarbonate UV-coated lens.",
                "Voltage: 12V DC\nWattage: 45W Low / 60W High\nCertification: ARAI / E-Mark Compliant\nSide: Right Hand (Driver Side)"
            ),
            # 8. Car Battery (Universal Fitment)
            (
                "Maintenance-Free 12V 65Ah Automotive Battery (Universal)",
                "maintenance-free-12v-65ah-automotive-battery",
                "SP-ELE-BAT-08",
                "four_wheeler",
                "Mahindra",
                "Universal Fitment: Tata, Mahindra, Hyundai, Toyota, Kia, Skoda, Volkswagen",
                "Electrical",
                3500.00,
                5400.00,
                2600.00,
                75,
                15,
                2,
                "/static/images/spare_parts/car_battery.jpg",
                "Silver-calcium alloy grid sealed maintenance-free lead acid battery engineered with built-in magic eye hydrometer and patented flame arrestor vents.",
                "Capacity: 65 Ah\nCold Cranking Amps (CCA): 580 A\nWarranty: 36 Months Commercial Warranty\nLayout: Left Terminal (+)"
            ),
            # 9. Bike Chain Kit (Bajaj / Hero)
            (
                "O-Ring Drive Chain & Sprocket Kit (Bajaj & Hero)",
                "o-ring-drive-chain-sprocket-kit-bajaj-hero",
                "SP-2W-BAJ-09",
                "two_wheeler",
                "Bajaj",
                "Bajaj Pulsar 150/180/220, Hero Xtreme 160R, Hunk",
                "Two-wheeler Parts",
                650.00,
                1100.00,
                450.00,
                140,
                25,
                5,
                "/static/images/spare_parts/bike_chain_kit.jpg",
                "Pre-lubricated high-tensile gold brass-plated O-ring roller chain paired with induction-hardened carbon steel front and rear sprockets for long wear.",
                "Chain Pitch: 428H - 122 Links\nFront Sprocket: 14T\nRear Sprocket: 42T Carbon Steel\nType: Sealed O-Ring"
            ),
            # 10. Bike Brake Shoe (Honda / TVS)
            (
                "Rear Drum Brake Shoe Assembly (Honda & TVS)",
                "rear-drum-brake-shoe-assembly-honda-tvs",
                "SP-2W-HND-10",
                "two_wheeler",
                "Honda",
                "Honda Activa 5G/6G, Dio, Shine / TVS Jupiter, Apache 160 Drum",
                "Brake System",
                280.00,
                480.00,
                190.00,
                210,
                35,
                10,
                "/static/images/spare_parts/bike_brake_shoe.jpg",
                "Die-cast aluminium brake shoes lined with high-friction asbestos-free friction compound for dependable stopping and fade resistance in city stop-and-go.",
                "Lining Material: Non-Asbestos Organic\nDiameter: 130 mm\nIncludes: Twin Heavy-Duty Steel Return Springs"
            ),
            # 11. Bike Clutch Plate (Royal Enfield)
            (
                "Multi-Plate Wet Clutch Disc Set (Royal Enfield)",
                "multi-plate-wet-clutch-disc-set-royal-enfield",
                "SP-2W-RE-11",
                "two_wheeler",
                "Royal Enfield",
                "Royal Enfield Classic 350, Bullet 350, Meteor 350, Hunter 350 (J-Series)",
                "Two-wheeler Parts",
                950.00,
                1550.00,
                680.00,
                85,
                18,
                4,
                "/static/images/spare_parts/bike_clutch_plate.jpg",
                "Cellulose and aramid fiber reinforced friction clutch discs paired with stamped steel drive plates designed to prevent slippage under heavy thump load.",
                "Friction Plates: 6 Pieces\nSteel Plates: 5 Pieces\nApplication: J-Series 349cc Air-Oil Cooled Engine"
            ),
            # 12. Bike Air Filter (Yamaha)
            (
                "High-Flow Cartridge Air Filter (Yamaha)",
                "high-flow-cartridge-air-filter-yamaha",
                "SP-2W-YAM-12",
                "two_wheeler",
                "Yamaha",
                "Yamaha R15 V3/V4, MT-15, FZ-S V3, Aerox 155",
                "Filters",
                220.00,
                380.00,
                150.00,
                175,
                25,
                10,
                "/static/images/spare_parts/bike_air_filter.jpg",
                "Viscous paper pleated air filter saturated with specialized oil to trap microscopic dirt particles while maximizing intake manifold velocity.",
                "Media Type: Viscous Pleated Element\nEfficiency: 99.2%\nFitment: Direct OEM Replacement Airbox"
            ),
            # 13. Frameless Wiper Blade Pair (Universal 4W)
            (
                "Aerodynamic Frameless Silicon Wiper Blade Pair (24\" + 16\")",
                "aerodynamic-frameless-silicon-wiper-blade-pair",
                "SP-EXT-UNI-13",
                "four_wheeler",
                "Kia",
                "Kia Seltos, Sonet / Hyundai Creta, Venue / Maruti Baleno, Swift",
                "Exterior",
                450.00,
                850.00,
                310.00,
                130,
                20,
                5,
                "/static/images/spare_parts/wiper_blade.jpg",
                "Graphite-coated Japanese silicone wiper blade providing silent, streak-free wipes across 500,000 cycles with aerodynamic wind-spoiler profile.",
                "Length: 24 Inch Driver / 16 Inch Passenger\nAdapter: Universal U-Hook (9x3 & 9x4)\nAll-Weather Temperature: -30°C to +80°C"
            ),
            # 14. Front Bumper Replacement (Volkswagen / Skoda)
            (
                "OEM Primer Front Bumper Cover (Volkswagen & Skoda)",
                "oem-primer-front-bumper-cover-vw-skoda",
                "SP-EXT-VW-14",
                "four_wheeler",
                "Volkswagen",
                "Volkswagen Taigun, Virtus / Skoda Kushaq, Slavia (MQB-A0-IN Platform)",
                "Exterior",
                3800.00,
                6200.00,
                2800.00,
                18,
                5,
                1,
                "/static/images/spare_parts/car_bumper.jpg",
                "Impact-resistant polypropylene bumper shell manufactured to OEM CAD tolerances. Pre-primed and ready for automotive paint finish.",
                "Material: Impact Polypropylene (PP+EPDM)\nFinish: Factory Gray Primer Coated\nCutouts: Fog Lamp & Parking Sensor Ports"
            ),
            # 15. Dual-Tone Electric Horn Kit (Universal 12V)
            (
                "Dual-Tone Disc Electric Horn Set (12V 115dB)",
                "dual-tone-disc-electric-horn-set-12v",
                "SP-ACC-UNI-15",
                "four_wheeler",
                "Mahindra",
                "Universal Fitment: 4-Wheelers & 2-Wheelers (Tata, Mahindra, Maruti, Royal Enfield)",
                "Accessories",
                480.00,
                850.00,
                320.00,
                160,
                25,
                6,
                "/static/images/spare_parts/electric_horn.jpg",
                "Teflon-coated diaphragm electric trumpet horn delivering a piercing, authoritative harmonic tone that cuts through city highway traffic noise.",
                "Decibel Level: 115 dB(A) at 2m\nFrequencies: 400 Hz (Low) & 500 Hz (High)\nIncludes: Universal Steel Mounting Straps & Relay"
            ),
            # 16. DOT Full-Face Helmet (KTM & Royal Enfield)
            (
                "Aerodynamic Full-Face Riding Helmet (ISI & DOT Certified)",
                "aerodynamic-full-face-riding-helmet",
                "SP-2W-KTM-16",
                "two_wheeler",
                "KTM",
                "KTM Duke 200/390, RC 390 / Royal Enfield Continental GT 650",
                "Two-wheeler Parts",
                1650.00,
                2800.00,
                1150.00,
                42,
                10,
                2,
                "/static/images/spare_parts/bike_helmet.jpg",
                "Thermoplastic composite aerodynamic shell with high-density EPS multi-channel ventilation, anti-scratch clear visor, and micrometric quick-release buckle.",
                "Certification: ISI (IS 4151) & DOT FMVSS 218\nSizes: Medium (58cm) & Large (60cm)\nInterior: Removable Washable Hypoallergenic Padding"
            ),
            # 17. Forged Engine Piston & Connecting Rod (Hyundai / Kia)
            (
                "Forged Engine Piston & Rings Set (Hyundai & Kia 1.5L CRDi)",
                "forged-engine-piston-rings-set-hyundai-kia",
                "SP-ENG-HYU-17",
                "four_wheeler",
                "Hyundai",
                "Hyundai Creta, Verna, Alcazar / Kia Seltos, Carens (1.5L CRDi Diesel)",
                "Engine Parts",
                2950.00,
                4800.00,
                2100.00,
                28,
                8,
                2,
                "/static/images/spare_parts/piston_assembly.jpg",
                "Precision forged high-silicon aluminum alloy piston crown with graphite skirt coating, phosphate-treated wrist pin, and chrome-nitrided steel ring pack.",
                "Bore Diameter: 75.0 mm (Standard Grade A)\nPiston Height: 68.2 mm\nPin Diameter: 26 mm Case Hardened"
            ),
            # 18. Heavy-Duty Alternator Unit (Renault & Nissan)
            (
                "12V 90A High-Output Alternator (Renault & Nissan)",
                "12v-90a-high-output-alternator-renault-nissan",
                "SP-ELE-REN-18",
                "four_wheeler",
                "Renault",
                "Renault Duster, Kiger, Triber / Nissan Magnite (1.0L Turbo / 1.5L dCi)",
                "Electrical",
                4200.00,
                6800.00,
                3100.00,
                22,
                6,
                1,
                "/static/images/spare_parts/alternator.jpg",
                "Computer-tested brushless automotive alternator equipped with internal solid-state voltage regulator, premium Japanese bearings, and dynamic balancing.",
                "Output: 12V 90 Amps\nPulley: 6-Groove Decoupler Overrunning Pulley\nRotation: Clockwise (CW)"
            ),
            # 19. Electric Scooter Motor Drive Belt (Ather & Ola Electric)
            (
                "Carbon-Reinforced Final Drive Belt (Ather & Ola Electric)",
                "carbon-reinforced-final-drive-belt-ather-ola",
                "SP-2W-EV-19",
                "two_wheeler",
                "Ather",
                "Ather 450X, 450S / Ola S1 Pro, S1 Air (High-Torque EV Powertrain)",
                "Transmission",
                780.00,
                1350.00,
                540.00,
                65,
                15,
                4,
                "/static/images/spare_parts/drive_belt.jpg",
                "Carbon tensile cord reinforced synchronous polyurethane timing belt engineered for zero maintenance, quiet operation, and instantaneous electric motor torque transfer.",
                "Material: HNBR Rubber with Carbon Tensile Cords\nPitch: 8M Synchronous\nWidth: 20 mm\nTemperature Rating: -40°C to 120°C"
            ),
            # 20. Luxury Suspension Strut (BMW & Mercedes-Benz & Audi)
            (
                "Adaptive Electronic Dampening Shock Absorber (BMW & Audi)",
                "adaptive-electronic-dampening-shock-bmw-audi",
                "SP-SUS-LUX-20",
                "four_wheeler",
                "BMW",
                "BMW 3-Series (G20), 5-Series (G30) / Audi A4, A6 (B9 Platform)",
                "Suspension",
                8500.00,
                14200.00,
                6400.00,
                14,
                4,
                1,
                "/static/images/spare_parts/luxury_strut.jpg",
                "OEM electronic variable damping strut engineered with solenoid magnetic valve to instantaneously adjust rebound according to driving road modes.",
                "System: Electronic Dynamic Damper Control (EDC)\nPosition: Front Axle\nWorking Pressure: 25 Bar Monotube"
            )
        ]
        
        for part in parts_data:
            cursor.execute("""
            INSERT INTO spare_parts (
                name, slug, sku, vehicle_type, brand, compatible_models, category,
                wholesale_price, suggested_retail_price, cost_price,
                stock_quantity, reorder_point, min_order_qty,
                image_url, description, specifications, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            """, part)
            
        print(f"Seeded {len(parts_data)} automotive spare parts.")
        
        # 3. Insert Retailer Accounts & Garages (Bangalore, India)
        print("Seeding Retailer Accounts & Garages...")
        
        # First ensure user records exist in `users` table for authentication
        retailer_users = [
            ("retailer@apexmotors.in", "Retailer@123", "Vikram Malhotra", "9845012301", "Apex Precision Motors & Garage", "Flat 12, Outer Ring Road, Bellandur", "Bangalore", "560103", "29AABCA1234F1Z5", "approved", 8.0, 15400.0),
            ("garage@manjunatha.in", "Retailer@123", "Suresh Gowda", "9845098765", "Sri Manjunatha Auto Spares & Garage", "Shop 4, 1st Cross, Industrial Area, Rajajinagar", "Bangalore", "560010", "29BBMPS9876P1ZX", "approved", 10.0, 0.0),
            ("service@koramangala.in", "Retailer@123", "Farhan Ahmed", "9845055512", "Koramangala Two-Wheeler Workshop", "80 Feet Road, 4th Block, Koramangala", "Bangalore", "560034", "29AAACF5512M1Z2", "approved", 5.0, 4200.0),
            ("contact@whitefieldhub.in", "Retailer@123", "Arun Kumar", "9845077799", "Whitefield Performance Hub", "ITPL Main Road, Whitefield", "Bangalore", "560066", "29AAACW7799K1Z8", "pending", 0.0, 0.0),
        ]
        
        retailer_ids = []
        for email, pwd, contact_name, phone, biz_name, addr, city, pin, gstin, status, disc, balance in retailer_users:
            pwd_hash, salt = hash_password(pwd)
            # Insert or update in users
            cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
            row = cursor.fetchone()
            if row:
                u_id = row[0]
            else:
                cursor.execute("""
                INSERT INTO users (email, password_hash, salt, full_name, phone, address, city, postal_code, role)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'retailer')
                """, (email, pwd_hash, salt, contact_name, phone, addr, city, pin))
                u_id = cursor.lastrowid
                
            cursor.execute("""
            INSERT INTO retailers (
                user_id, business_name, contact_person, email, phone, gstin,
                address, city, state, postal_code, status, discount_percent, outstanding_balance
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Karnataka', ?, ?, ?, ?)
            """, (u_id, biz_name, contact_name, email, phone, gstin, addr, city, pin, status, disc, balance))
            retailer_ids.append(cursor.lastrowid)
            
        print(f"Seeded {len(retailer_users)} retailer garages.")
        
        # 4. Insert Sample Wholesale Orders & Invoices
        print("Seeding Sample Wholesale Orders and Tax Invoices...")
        
        # Order 1: Completed order for Apex Precision Motors (Bellandur)
        r1_id = retailer_ids[0]
        cursor.execute("""
        INSERT INTO spare_part_orders (
            order_number, retailer_id, order_status, payment_status,
            subtotal, discount_amount, gst_amount, grand_total,
            delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
            tracking_number, carrier_name, created_at
        ) VALUES (
            'SPO-20261026-901', ?, 'delivered', 'paid',
            18500.00, 1480.00, 3063.60, 20083.60,
            'Flat 12, Outer Ring Road, Bellandur', 'Bangalore', 'Karnataka', '560103', 'Deliver to garage bay 3',
            'VRL-BLR-8921', 'VRL Logistics Express Cargo', '2026-10-26 11:30:00'
        )
        """, (r1_id,))
        order1_id = cursor.lastrowid
        
        # Items for Order 1
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-FLT-TAT-01'")
        sp1 = cursor.fetchone()
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-BRK-TOY-03'")
        sp2 = cursor.fetchone()
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-TRN-MAH-05'")
        sp3 = cursor.fetchone()
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Tata Motors', 'four_wheeler', 'Filters', 250.00, 20, 5000.00)
        """, (order1_id, sp1["id"], sp1["name"], sp1["sku"]))
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Toyota', 'four_wheeler', 'Brake System', 850.00, 10, 8500.00)
        """, (order1_id, sp2["id"], sp2["name"], sp2["sku"]))
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Mahindra', 'four_wheeler', 'Transmission', 1450.00, 4, 5800.00)
        """, (order1_id, sp3["id"], sp3["name"], sp3["sku"]))
        
        # Invoice 1
        cursor.execute("""
        INSERT INTO spare_part_invoices (
            invoice_number, order_id, retailer_id, invoice_date,
            subtotal, discount_amount, gst_amount, grand_total, status, created_at
        ) VALUES (
            'INV-SP-20261026-001', ?, ?, '2026-10-26',
            18500.00, 1480.00, 3063.60, 20083.60, 'paid', '2026-10-26 12:00:00'
        )
        """, (order1_id, r1_id))
        
        # Order 2: Dispatched / Out for Delivery order for Sri Manjunatha Auto Spares (Rajajinagar)
        r2_id = retailer_ids[1]
        cursor.execute("""
        INSERT INTO spare_part_orders (
            order_number, retailer_id, order_status, payment_status,
            subtotal, discount_amount, gst_amount, grand_total,
            delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
            tracking_number, carrier_name, created_at
        ) VALUES (
            'SPO-20261101-904', ?, 'dispatched', 'paid',
            12600.00, 1260.00, 2041.20, 13381.20,
            'Shop 4, 1st Cross, Industrial Area, Rajajinagar', 'Bangalore', 'Karnataka', '560010', 'Morning unloading before 11 AM',
            'TCI-EXP-4402', 'TCI Freight Logistics', '2026-11-01 09:15:00'
        )
        """, (r2_id,))
        order2_id = cursor.lastrowid
        
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-FLT-MS-02'")
        sp4 = cursor.fetchone()
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-SUS-MS-06'")
        sp5 = cursor.fetchone()
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Maruti Suzuki', 'four_wheeler', 'Filters', 350.00, 16, 5600.00)
        """, (order2_id, sp4["id"], sp4["name"], sp4["sku"]))
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Maruti Suzuki', 'four_wheeler', 'Suspension', 1800.00, 4, 7200.00)
        """, (order2_id, sp5["id"], sp5["name"], sp5["sku"]))
        
        # Invoice 2
        cursor.execute("""
        INSERT INTO spare_part_invoices (
            invoice_number, order_id, retailer_id, invoice_date,
            subtotal, discount_amount, gst_amount, grand_total, status, created_at
        ) VALUES (
            'INV-SP-20261101-002', ?, ?, '2026-11-01',
            12600.00, 1260.00, 2041.20, 13381.20, 'paid', '2026-11-01 09:30:00'
        )
        """, (order2_id, r2_id))
        
        # Order 3: Pending order for Koramangala Two-Wheeler Workshop
        r3_id = retailer_ids[2]
        cursor.execute("""
        INSERT INTO spare_part_orders (
            order_number, retailer_id, order_status, payment_status,
            subtotal, discount_amount, gst_amount, grand_total,
            delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
            tracking_number, carrier_name, created_at
        ) VALUES (
            'SPO-20261102-908', ?, 'pending', 'pending',
            9700.00, 485.00, 1658.70, 10873.70,
            '80 Feet Road, 4th Block, Koramangala', 'Bangalore', 'Karnataka', '560034', 'Leave at parts reception counter',
            '', 'TradeKart Local Courier Van', '2026-11-02 16:45:00'
        )
        """, (r3_id,))
        order3_id = cursor.lastrowid
        
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-2W-BAJ-09'")
        sp6 = cursor.fetchone()
        cursor.execute("SELECT id, name, sku, wholesale_price FROM spare_parts WHERE sku = 'SP-2W-RE-11'")
        sp7 = cursor.fetchone()
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Bajaj', 'two_wheeler', 'Two-wheeler Parts', 650.00, 8, 5200.00)
        """, (order3_id, sp6["id"], sp6["name"], sp6["sku"]))
        
        cursor.execute("""
        INSERT INTO spare_part_order_items (order_id, spare_part_id, part_name, part_sku, brand, vehicle_type, category, wholesale_price, quantity, subtotal)
        VALUES (?, ?, ?, ?, 'Royal Enfield', 'two_wheeler', 'Two-wheeler Parts', 950.00, 5, 4750.00)
        """, (order3_id, sp7["id"], sp7["name"], sp7["sku"]))

        # 5. Insert Sample Portal Notifications (Admin & Retailer)
        print("Seeding In-App Notifications...")
        
        notifications_data = [
            ("admin", None, "new_retailer", "New Retailer Registration", "Whitefield Performance Hub submitted registration for dealer approval.", "/spare-parts/admin/retailers", 0),
            ("admin", None, "new_order", "New Wholesale Order Received", "Order #SPO-20261102-908 placed by Koramangala Two-Wheeler Workshop for ₹10,873.70.", "/spare-parts/admin/orders", 0),
            ("admin", None, "reorder_alert", "Automated Stock Surveillance Alert", "Adaptive Electronic Dampening Shock Absorber (SP-SUS-LUX-20) has reached reorder point of 4 units!", "/spare-parts/admin/inventory", 0),
            ("retailer", r1_id, "order_dispatched", "Order Dispatched", "Your wholesale order #SPO-20261026-901 has been delivered via VRL Logistics.", "/spare-parts/orders", 1),
            ("retailer", r1_id, "invoice_generated", "Tax Invoice Generated", "Invoice #INV-SP-20261026-001 is now ready for download.", "/spare-parts/invoice/INV-SP-20261026-001", 1),
            ("retailer", r2_id, "order_confirmed", "Order Confirmed & Processing", "Your order #SPO-20261101-904 is confirmed and scheduled for dispatch.", "/spare-parts/orders", 0),
        ]
        
        for notif in notifications_data:
            cursor.execute("""
            INSERT INTO portal_notifications (recipient_type, retailer_id, event_type, title, message, link_url, is_read)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, notif)
            
        print("Spare Parts Dealer Portal seeding completed successfully!")

if __name__ == "__main__":
    seed_spare_parts_data()
