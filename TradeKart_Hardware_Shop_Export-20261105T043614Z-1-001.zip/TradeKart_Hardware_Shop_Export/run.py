import sys
import os
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

import uvicorn
from app.config import settings
from app.database import init_db, get_db

def ensure_initialized():
    """Initializes tables and seeds data if database is empty."""
    init_db()
    with get_db() as conn:
        prod_count = conn.execute("SELECT COUNT(id) as cnt FROM products").fetchone()["cnt"]
        if prod_count == 0:
            print("Detected empty database. Running automatic seed...")
            from seed_data import seed_database
            seed_database()
        sp_count = conn.execute("SELECT COUNT(id) as cnt FROM spare_parts").fetchone()["cnt"]
        if sp_count == 0:
            print("Detected empty spare parts catalog. Running automatic spare parts seed...")
            from seed_spare_parts import seed_spare_parts_data
            seed_spare_parts_data()

if __name__ == "__main__":
    # Ensure UTF-8 output on Windows consoles
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')

    ensure_initialized()
    print("=" * 75)
    print(f"[*] {settings.SHOP_NAME} is launching in Light Green Theme!")
    print(f"    Hardware Storefront : http://{settings.HOST}:{settings.PORT}/")
    print(f"    Auto Spares Portal  : http://{settings.HOST}:{settings.PORT}/spare-parts")
    print(f"    Retailer Sign In    : http://{settings.HOST}:{settings.PORT}/spare-parts/login")
    print(f"    Shopkeeper Admin    : http://{settings.HOST}:{settings.PORT}/admin/login")
    print(f"    Spares Analytics    : http://{settings.HOST}:{settings.PORT}/spare-parts/admin/analytics")
    print("-" * 75)
    print(f"    Admin Credentials   : admin@hardwareshop.com / Admin@12345")
    print(f"    Customer Credentials: customer@example.com / Customer@123")
    print(f"    Retailer Credentials: retailer@apexmotors.in / Retailer@123")
    print("=" * 75)
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT, reload=settings.DEBUG)
