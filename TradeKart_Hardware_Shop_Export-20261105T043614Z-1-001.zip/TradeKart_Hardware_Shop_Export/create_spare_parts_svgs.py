"""
Generate high-fidelity vector SVG illustrations for automobile spare parts.
"""
from pathlib import Path

SVG_DIR = Path(__file__).resolve().parent / "app" / "static" / "images" / "spare_parts"
SVG_DIR.mkdir(parents=True, exist_ok=True)

SVGS = {
    "oil_filter.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="canisterGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#1e293b"/>
      <stop offset="35%" stop-color="#0284c7"/>
      <stop offset="70%" stop-color="#0369a1"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
    <linearGradient id="metalRim" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#e2e8f0"/>
      <stop offset="50%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Canister Body -->
  <rect x="85" y="70" width="130" height="150" rx="20" fill="url(#canisterGrad)" stroke="#0f172a" stroke-width="3"/>
  <!-- Ridges on top for grip -->
  <line x1="100" y1="80" x2="100" y2="120" stroke="#38bdf8" stroke-width="3" stroke-linecap="round"/>
  <line x1="125" y1="80" x2="125" y2="120" stroke="#38bdf8" stroke-width="3" stroke-linecap="round"/>
  <line x1="150" y1="80" x2="150" y2="120" stroke="#38bdf8" stroke-width="3" stroke-linecap="round"/>
  <line x1="175" y1="80" x2="175" y2="120" stroke="#38bdf8" stroke-width="3" stroke-linecap="round"/>
  <line x1="200" y1="80" x2="200" y2="120" stroke="#38bdf8" stroke-width="3" stroke-linecap="round"/>
  <!-- Threaded base rim -->
  <ellipse cx="150" cy="220" rx="65" ry="14" fill="url(#metalRim)" stroke="#334155" stroke-width="2"/>
  <ellipse cx="150" cy="220" rx="35" ry="8" fill="#0f172a"/>
  <!-- Rubber O-ring gasket -->
  <ellipse cx="150" cy="220" rx="55" ry="11" fill="none" stroke="#dc2626" stroke-width="4"/>
  <!-- Label Badge -->
  <rect x="100" y="145" width="100" height="36" rx="6" fill="#ffffff" opacity="0.9"/>
  <text x="150" y="162" font-family="system-ui, sans-serif" font-size="10" font-weight="900" fill="#0f172a" text-anchor="middle">PREMIUM FLOW</text>
  <text x="150" y="174" font-family="system-ui, sans-serif" font-size="8" font-weight="bold" fill="#0284c7" text-anchor="middle">OIL FILTER CANISTER</text>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">SPIN-ON ENGINE OIL FILTER</text>
</svg>""",

    "air_filter.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="rubberBorder" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ea580c"/>
      <stop offset="100%" stop-color="#c2410c"/>
    </linearGradient>
    <linearGradient id="pleatGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#fef08a"/>
      <stop offset="50%" stop-color="#fde047"/>
      <stop offset="100%" stop-color="#eab308"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Outer orange polyurethane sealing frame -->
  <rect x="45" y="70" width="210" height="150" rx="14" fill="url(#rubberBorder)" stroke="#9a3412" stroke-width="4"/>
  <!-- Inner filter cavity -->
  <rect x="60" y="85" width="180" height="120" rx="8" fill="url(#pleatGrad)" stroke="#ca8a04" stroke-width="2"/>
  <!-- Micro-fiber accordion pleats -->
  <path d="M 65,90 L 75,195 L 85,90 L 95,195 L 105,90 L 115,195 L 125,90 L 135,195 L 145,90 L 155,195 L 165,90 L 175,195 L 185,90 L 195,195 L 205,90 L 215,195 L 225,90 L 235,195" fill="none" stroke="#a16207" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
  <!-- Protective metal mesh grid lines -->
  <line x1="60" y1="125" x2="240" y2="125" stroke="#ffffff" stroke-width="1.5" stroke-dasharray="4,4" opacity="0.8"/>
  <line x1="60" y1="165" x2="240" y2="165" stroke="#ffffff" stroke-width="1.5" stroke-dasharray="4,4" opacity="0.8"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">HIGH-AIRFLOW ENGINE FILTER</text>
</svg>""",

    "brake_pad_set.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="metalPlate" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#334155"/>
      <stop offset="50%" stop-color="#475569"/>
      <stop offset="100%" stop-color="#1e293b"/>
    </linearGradient>
    <linearGradient id="frictionMaterial" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1e293b"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Back Pad (offset shadow) -->
  <path d="M 60,110 Q 150,85 240,110 L 230,170 Q 150,195 70,170 Z" fill="#94a3b8" stroke="#475569" stroke-width="3"/>
  <!-- Front Steel Backing Plate -->
  <path d="M 50,130 Q 150,105 250,130 L 240,190 Q 150,215 60,190 Z" fill="url(#metalPlate)" stroke="#0f172a" stroke-width="3"/>
  <!-- Friction Lining Block -->
  <path d="M 70,140 Q 150,120 230,140 L 222,180 Q 150,200 78,180 Z" fill="url(#frictionMaterial)" stroke="#0284c7" stroke-width="1.5"/>
  <!-- Anti-noise chamfer slot -->
  <line x1="150" y1="125" x2="150" y2="195" stroke="#f8fafc" stroke-width="3"/>
  <!-- Mounting ears -->
  <circle cx="52" cy="140" r="5" fill="#f8fafc"/>
  <circle cx="248" cy="140" r="5" fill="#f8fafc"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">CERAMIC DISC BRAKE PAD SET</text>
</svg>""",

    "spark_plug.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="ceramic" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#f8fafc"/>
      <stop offset="50%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#cbd5e1"/>
    </linearGradient>
    <linearGradient id="threads" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#64748b"/>
      <stop offset="50%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Terminal nut -->
  <rect x="143" y="45" width="14" height="20" rx="3" fill="#94a3b8" stroke="#475569" stroke-width="2"/>
  <!-- Ceramic insulator with ribbed ribs -->
  <rect x="138" y="65" width="24" height="65" rx="5" fill="url(#ceramic)" stroke="#94a3b8" stroke-width="2"/>
  <line x1="135" y1="75" x2="165" y2="75" stroke="#0284c7" stroke-width="2"/>
  <line x1="135" y1="85" x2="165" y2="85" stroke="#0284c7" stroke-width="2"/>
  <line x1="135" y1="95" x2="165" y2="95" stroke="#0284c7" stroke-width="2"/>
  <!-- Hexagonal nut portion -->
  <polygon points="132,130 168,130 172,150 168,160 132,160 128,150" fill="url(#threads)" stroke="#334155" stroke-width="2"/>
  <!-- Threaded steel shell -->
  <rect x="137" y="160" width="26" height="50" fill="url(#threads)" stroke="#334155" stroke-width="2"/>
  <line x1="137" y1="170" x2="163" y2="170" stroke="#334155" stroke-width="2"/>
  <line x1="137" y1="180" x2="163" y2="180" stroke="#334155" stroke-width="2"/>
  <line x1="137" y1="190" x2="163" y2="190" stroke="#334155" stroke-width="2"/>
  <line x1="137" y1="200" x2="163" y2="200" stroke="#334155" stroke-width="2"/>
  <!-- Ground electrode and spark tip -->
  <rect x="147" y="210" width="6" height="15" fill="#f59e0b"/>
  <path d="M 142,225 L 158,225 L 158,218" fill="none" stroke="#475569" stroke-width="3" stroke-linecap="round"/>
  <!-- Spark glow -->
  <circle cx="150" cy="220" r="4" fill="#38bdf8"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">IRIDIUM POWER SPARK PLUG</text>
</svg>""",

    "clutch_plate.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="frictionRing" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#475569"/>
      <stop offset="50%" stop-color="#334155"/>
      <stop offset="100%" stop-color="#1e293b"/>
    </linearGradient>
    <radialGradient id="hubCenter" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#e2e8f0"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </radialGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Outer Friction Disc -->
  <circle cx="150" cy="140" r="85" fill="url(#frictionRing)" stroke="#0f172a" stroke-width="4"/>
  <!-- Radial friction segments -->
  <circle cx="150" cy="140" r="80" fill="none" stroke="#64748b" stroke-width="3" stroke-dasharray="8,6"/>
  <!-- Inner Steel Plate -->
  <circle cx="150" cy="140" r="55" fill="#cbd5e1" stroke="#334155" stroke-width="3"/>
  <!-- Damper Springs (4 windows) -->
  <rect x="135" y="90" width="30" height="14" rx="4" fill="#f59e0b" stroke="#78350f" stroke-width="2"/>
  <rect x="135" y="176" width="30" height="14" rx="4" fill="#f59e0b" stroke="#78350f" stroke-width="2"/>
  <rect x="95" y="125" width="14" height="30" rx="4" fill="#f59e0b" stroke="#78350f" stroke-width="2"/>
  <rect x="191" y="125" width="14" height="30" rx="4" fill="#f59e0b" stroke="#78350f" stroke-width="2"/>
  <!-- Center Splined Hub -->
  <circle cx="150" cy="140" r="22" fill="url(#hubCenter)" stroke="#1e293b" stroke-width="3"/>
  <circle cx="150" cy="140" r="10" fill="#0f172a"/>
  <!-- Spline teeth -->
  <circle cx="150" cy="140" r="11" fill="none" stroke="#ffffff" stroke-width="2" stroke-dasharray="2,2"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">HEAVY-DUTY CLUTCH PLATE</text>
</svg>""",

    "shock_absorber.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="strutBody" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#0284c7"/>
      <stop offset="50%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#0369a1"/>
    </linearGradient>
    <linearGradient id="chromePiston" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#cbd5e1"/>
      <stop offset="50%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#94a3b8"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Top Mounting Eyelet -->
  <circle cx="150" cy="45" r="14" fill="#334155" stroke="#0f172a" stroke-width="3"/>
  <circle cx="150" cy="45" r="7" fill="#f1f5f9"/>
  <!-- Chrome shaft / piston rod -->
  <rect x="144" y="58" width="12" height="60" fill="url(#chromePiston)" stroke="#475569" stroke-width="1.5"/>
  <!-- Rubber bump stop -->
  <rect x="140" y="110" width="20" height="15" rx="3" fill="#dc2626"/>
  <!-- Shock absorber main body tube -->
  <rect x="135" y="125" width="30" height="95" rx="6" fill="url(#strutBody)" stroke="#0f172a" stroke-width="2.5"/>
  <!-- Heavy helical coil spring surrounding strut -->
  <path d="M 125,75 Q 150,65 175,75 Q 150,90 125,100 Q 150,90 175,100 Q 150,115 125,125 Q 150,115 175,125 Q 150,140 125,150 Q 150,140 175,150 Q 150,165 125,175 Q 150,165 175,175" fill="none" stroke="#dc2626" stroke-width="6" stroke-linecap="round"/>
  <!-- Bottom Mounting Eyelet -->
  <rect x="140" y="215" width="20" height="12" fill="#334155"/>
  <circle cx="150" cy="235" r="14" fill="#334155" stroke="#0f172a" stroke-width="3"/>
  <circle cx="150" cy="235" r="7" fill="#f1f5f9"/>
  <text x="150" y="275" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">GAS-CHARGED SUSPENSION STRUT</text>
</svg>""",

    "headlight_assembly.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="lensReflect" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#e0f2fe" stop-opacity="0.9"/>
      <stop offset="40%" stop-color="#bae6fd" stop-opacity="0.6"/>
      <stop offset="100%" stop-color="#0284c7" stop-opacity="0.3"/>
    </linearGradient>
    <radialGradient id="projectorGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="60%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#0284c7"/>
    </radialGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Aerodynamic Headlamp Housing -->
  <path d="M 40,150 Q 100,80 250,90 Q 260,170 190,195 Q 100,205 40,150 Z" fill="#0f172a" stroke="#334155" stroke-width="4"/>
  <!-- Chrome Reflector Interior -->
  <path d="M 55,148 Q 105,95 240,102 Q 248,162 185,185 Q 108,192 55,148 Z" fill="#334155" stroke="#64748b" stroke-width="2"/>
  <!-- LED DRL Light Guide (Daytime Running Light Strip) -->
  <path d="M 65,130 Q 120,95 235,110" fill="none" stroke="#38bdf8" stroke-width="4" stroke-linecap="round"/>
  <!-- High-Beam Bi-LED Projector Lens -->
  <circle cx="115" cy="148" r="28" fill="url(#projectorGlow)" stroke="#f8fafc" stroke-width="3"/>
  <circle cx="115" cy="148" r="14" fill="#ffffff" opacity="0.8"/>
  <!-- Turn Signal Reflector Indicator -->
  <ellipse cx="205" cy="140" rx="18" ry="12" fill="#f59e0b" stroke="#b45309" stroke-width="2"/>
  <!-- Outer Polycarbonate Clear Lens with Reflection -->
  <path d="M 40,150 Q 100,80 250,90 Q 260,170 190,195 Q 100,205 40,150 Z" fill="url(#lensReflect)"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">BI-LED PROJECTOR HEADLIGHT</text>
</svg>""",

    "car_battery.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="batteryCasing" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1e293b"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Main Polypropylene Battery Case -->
  <rect x="55" y="90" width="190" height="130" rx="10" fill="url(#batteryCasing)" stroke="#0284c7" stroke-width="3"/>
  <!-- Top Lid / Cover -->
  <rect x="50" y="80" width="200" height="25" rx="6" fill="#0284c7" stroke="#0369a1" stroke-width="2"/>
  <!-- Carrying Handle -->
  <path d="M 80,80 L 80,60 Q 150,55 220,60 L 220,80" fill="none" stroke="#f59e0b" stroke-width="6" stroke-linecap="round"/>
  <!-- Positive Terminal (+) -->
  <rect x="75" y="65" width="20" height="16" rx="4" fill="#dc2626" stroke="#991b1b" stroke-width="2"/>
  <text x="85" y="78" font-family="system-ui, sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">+</text>
  <!-- Negative Terminal (-) -->
  <rect x="205" y="65" width="20" height="16" rx="4" fill="#334155" stroke="#1e293b" stroke-width="2"/>
  <text x="215" y="77" font-family="system-ui, sans-serif" font-size="18" font-weight="bold" fill="#ffffff" text-anchor="middle">-</text>
  <!-- Cell Caps (6 Maintenance-free vent plugs) -->
  <circle cx="115" cy="92" r="5" fill="#f8fafc"/>
  <circle cx="130" cy="92" r="5" fill="#f8fafc"/>
  <circle cx="145" cy="92" r="5" fill="#f8fafc"/>
  <circle cx="160" cy="92" r="5" fill="#f8fafc"/>
  <circle cx="175" cy="92" r="5" fill="#f8fafc"/>
  <!-- Front Brand Spec Badge -->
  <rect x="75" y="125" width="150" height="55" rx="6" fill="#0f172a" stroke="#334155" stroke-width="1.5"/>
  <text x="150" y="145" font-family="system-ui, sans-serif" font-size="12" font-weight="900" fill="#f59e0b" text-anchor="middle">TRADEKART POWER 12V</text>
  <text x="150" y="165" font-family="system-ui, sans-serif" font-size="14" font-weight="black" fill="#ffffff" text-anchor="middle">65Ah / 600 CCA</text>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">MAINTENANCE-FREE CAR BATTERY</text>
</svg>""",

    "bike_chain_kit.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <radialGradient id="sprocketGrad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#e2e8f0"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </radialGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Rear Large Sprocket Gear -->
  <circle cx="130" cy="135" r="75" fill="url(#sprocketGrad)" stroke="#1e293b" stroke-width="3"/>
  <!-- Lightening cutouts on rear sprocket -->
  <circle cx="130" cy="135" r="30" fill="#f1f5f9"/>
  <circle cx="130" cy="85" r="10" fill="#f1f5f9"/>
  <circle cx="130" cy="185" r="10" fill="#f1f5f9"/>
  <circle cx="80" cy="135" r="10" fill="#f1f5f9"/>
  <circle cx="180" cy="135" r="10" fill="#f1f5f9"/>
  <!-- Sprocket Outer Teeth -->
  <circle cx="130" cy="135" r="77" fill="none" stroke="#334155" stroke-width="6" stroke-dasharray="6,6"/>
  <!-- Front Engine Sprocket -->
  <circle cx="215" cy="155" r="28" fill="#64748b" stroke="#0f172a" stroke-width="2.5"/>
  <circle cx="215" cy="155" r="8" fill="#f1f5f9"/>
  <circle cx="215" cy="155" r="29" fill="none" stroke="#1e293b" stroke-width="4" stroke-dasharray="4,4"/>
  <!-- Heavy Gold-Plated O-Ring Drive Chain Loop -->
  <ellipse cx="160" cy="140" rx="95" ry="55" fill="none" stroke="#f59e0b" stroke-width="5" stroke-dasharray="8,4"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">HEAVY-DUTY BIKE DRIVE CHAIN KIT</text>
</svg>""",

    "bike_brake_shoe.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="shoeAlloy" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#cbd5e1"/>
      <stop offset="60%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#64748b"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Top Curved Brake Shoe -->
  <path d="M 70,120 Q 150,60 230,120 L 220,135 Q 150,85 80,135 Z" fill="url(#shoeAlloy)" stroke="#334155" stroke-width="3"/>
  <path d="M 75,115 Q 150,55 225,115 L 220,125 Q 150,70 80,125 Z" fill="#1e293b"/>
  <!-- Bottom Curved Brake Shoe -->
  <path d="M 70,170 Q 150,230 230,170 L 220,155 Q 150,205 80,155 Z" fill="url(#shoeAlloy)" stroke="#334155" stroke-width="3"/>
  <path d="M 75,175 Q 150,235 225,175 L 220,165 Q 150,220 80,165 Z" fill="#1e293b"/>
  <!-- Tension Return Springs -->
  <line x1="85" y1="130" x2="85" y2="160" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
  <line x1="215" y1="130" x2="215" y2="160" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
  <!-- Pivot and Cam Contact Points -->
  <circle cx="75" cy="145" r="7" fill="#475569" stroke="#1e293b" stroke-width="2"/>
  <circle cx="225" cy="145" r="7" fill="#475569" stroke="#1e293b" stroke-width="2"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">MOTORCYCLE DRUM BRAKE SHOE SET</text>
</svg>""",

    "bike_clutch_plate.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <radialGradient id="corkPlate" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#b45309"/>
      <stop offset="70%" stop-color="#78350f"/>
      <stop offset="100%" stop-color="#451a03"/>
    </radialGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- 2nd plate background stack -->
  <circle cx="160" cy="130" r="75" fill="#94a3b8" stroke="#475569" stroke-width="3"/>
  <!-- Front Cork Friction Clutch Disc -->
  <circle cx="140" cy="145" r="75" fill="url(#corkPlate)" stroke="#1e293b" stroke-width="3"/>
  <circle cx="140" cy="145" r="45" fill="#f1f5f9"/>
  <!-- Friction blocks / ears around perimeter -->
  <circle cx="140" cy="145" r="78" fill="none" stroke="#f59e0b" stroke-width="7" stroke-dasharray="10,12"/>
  <!-- Inner steel spline teeth -->
  <circle cx="140" cy="145" r="48" fill="none" stroke="#334155" stroke-width="4" stroke-dasharray="5,5"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">BIKE MULTI-PLATE CLUTCH SET</text>
</svg>""",

    "bike_air_filter.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="coneGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#dc2626"/>
      <stop offset="50%" stop-color="#ef4444"/>
      <stop offset="100%" stop-color="#991b1b"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Chrome Top Cap -->
  <ellipse cx="150" cy="75" rx="35" ry="10" fill="#e2e8f0" stroke="#475569" stroke-width="2"/>
  <!-- Conical Pleated Filter Body -->
  <polygon points="115,75 185,75 205,190 95,190" fill="url(#coneGrad)" stroke="#7f1d1d" stroke-width="2"/>
  <!-- Vertical Accordion Pleats -->
  <line x1="125" y1="75" x2="110" y2="190" stroke="#fecaca" stroke-width="2"/>
  <line x1="135" y1="75" x2="128" y2="190" stroke="#fecaca" stroke-width="2"/>
  <line x1="150" y1="75" x2="150" y2="190" stroke="#fecaca" stroke-width="2"/>
  <line x1="165" y1="75" x2="172" y2="190" stroke="#fecaca" stroke-width="2"/>
  <line x1="175" y1="75" x2="190" y2="190" stroke="#fecaca" stroke-width="2"/>
  <!-- Rubber Mounting Flange & Hose Clamp -->
  <ellipse cx="150" cy="190" rx="55" ry="14" fill="#0f172a" stroke="#334155" stroke-width="2"/>
  <ellipse cx="150" cy="205" rx="45" ry="12" fill="#1e293b" stroke="#334155" stroke-width="2"/>
  <ellipse cx="150" cy="205" rx="46" ry="13" fill="none" stroke="#e2e8f0" stroke-width="3"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">CONICAL HIGH-FLOW BIKE FILTER</text>
</svg>""",

    "wiper_blade.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Aerodynamic Curved Spine Beam -->
  <path d="M 40,110 Q 150,165 260,110" fill="none" stroke="#0f172a" stroke-width="8" stroke-linecap="round"/>
  <!-- Flexible Silicon Wiper Edge -->
  <path d="M 45,116 Q 150,171 255,116" fill="none" stroke="#0284c7" stroke-width="3" stroke-linecap="round"/>
  <!-- Center Hook Adapter Mounting Clip -->
  <rect x="135" y="125" width="30" height="20" rx="4" fill="#334155" stroke="#0f172a" stroke-width="2"/>
  <circle cx="150" cy="135" r="4" fill="#f8fafc"/>
  <!-- Rain droplet simulation -->
  <circle cx="90" cy="110" r="3" fill="#38bdf8"/>
  <circle cx="210" cy="110" r="3" fill="#38bdf8"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">FRAMELESS ALL-WEATHER WIPER BLADE</text>
</svg>""",

    "car_bumper.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="bumperGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#334155"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Aerodynamic Front Bumper Shell -->
  <path d="M 30,120 Q 150,90 270,120 L 265,180 Q 220,195 150,195 Q 80,195 35,180 Z" fill="url(#bumperGrad)" stroke="#0284c7" stroke-width="3"/>
  <!-- Lower Radiator Honeycomb Grille -->
  <rect x="75" y="145" width="150" height="35" rx="6" fill="#020617" stroke="#1e293b" stroke-width="2"/>
  <line x1="75" y1="162" x2="225" y2="162" stroke="#334155" stroke-dasharray="4,4"/>
  <!-- Fog Lamp Housings (Left & Right) -->
  <circle cx="55" cy="155" r="12" fill="#0f172a" stroke="#475569" stroke-width="2"/>
  <circle cx="55" cy="155" r="6" fill="#f59e0b"/>
  <circle cx="245" cy="155" r="12" fill="#0f172a" stroke="#475569" stroke-width="2"/>
  <circle cx="245" cy="155" r="6" fill="#f59e0b"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">FRONT OEM REPLACEMENT BUMPER</text>
</svg>""",

    "bike_helmet.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="helmetShell" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0f172a"/>
      <stop offset="40%" stop-color="#1e293b"/>
      <stop offset="100%" stop-color="#0284c7"/>
    </linearGradient>
    <linearGradient id="visorGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#d97706" stop-opacity="0.7"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Outer Shell -->
  <path d="M 70,170 Q 60,80 150,70 Q 240,80 230,170 Q 210,220 150,225 Q 90,220 70,170 Z" fill="url(#helmetShell)" stroke="#0f172a" stroke-width="3"/>
  <!-- Aerodynamic Tinted Visor -->
  <path d="M 85,120 Q 150,110 215,120 L 210,165 Q 150,180 90,165 Z" fill="url(#visorGrad)" stroke="#78350f" stroke-width="2"/>
  <!-- Chin Air Vent -->
  <rect x="135" y="195" width="30" height="10" rx="3" fill="#020617"/>
  <!-- Visor Pivot Ratchet -->
  <circle cx="85" cy="140" r="6" fill="#e2e8f0"/>
  <circle cx="215" cy="140" r="6" fill="#e2e8f0"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">DOT-CERTIFIED FULL FACE HELMET</text>
</svg>""",

    "electric_horn.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <radialGradient id="hornGrille" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#1e293b"/>
      <stop offset="85%" stop-color="#0f172a"/>
      <stop offset="100%" stop-color="#dc2626"/>
    </radialGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Mounting Bracket -->
  <rect x="142" y="45" width="16" height="40" rx="3" fill="#475569" stroke="#1e293b" stroke-width="2"/>
  <circle cx="150" cy="55" r="5" fill="#f1f5f9"/>
  <!-- Outer Red Trim Ring -->
  <circle cx="150" cy="145" r="75" fill="#dc2626" stroke="#991b1b" stroke-width="3"/>
  <!-- Inner Perforated Diaphragm Disc -->
  <circle cx="150" cy="145" r="65" fill="url(#hornGrille)" stroke="#0f172a" stroke-width="2"/>
  <!-- Chrome Center Dome -->
  <circle cx="150" cy="145" r="22" fill="#e2e8f0" stroke="#475569" stroke-width="2"/>
  <!-- Sound slots -->
  <circle cx="150" cy="145" r="45" fill="none" stroke="#f8fafc" stroke-width="3" stroke-dasharray="10,8" opacity="0.7"/>
  <circle cx="150" cy="145" r="35" fill="none" stroke="#f8fafc" stroke-width="3" stroke-dasharray="8,6" opacity="0.7"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">DUAL-TONE HIGH-DECIBEL HORN</text>
</svg>""",

    "piston_assembly.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <linearGradient id="pistonAlloy" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#cbd5e1"/>
      <stop offset="50%" stop-color="#f8fafc"/>
      <stop offset="100%" stop-color="#94a3b8"/>
    </linearGradient>
    <linearGradient id="rodSteel" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#475569"/>
      <stop offset="50%" stop-color="#64748b"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Piston Crown & Skirt -->
  <rect x="100" y="60" width="100" height="90" rx="8" fill="url(#pistonAlloy)" stroke="#475569" stroke-width="3"/>
  <!-- Compression and Oil Ring Grooves -->
  <line x1="98" y1="75" x2="202" y2="75" stroke="#334155" stroke-width="2.5"/>
  <line x1="98" y1="85" x2="202" y2="85" stroke="#334155" stroke-width="2.5"/>
  <line x1="98" y1="95" x2="202" y2="95" stroke="#334155" stroke-width="2.5"/>
  <!-- Gudgeon / Wrist Pin Hole -->
  <circle cx="150" cy="120" r="14" fill="#334155" stroke="#1e293b" stroke-width="2"/>
  <circle cx="150" cy="120" r="8" fill="#cbd5e1"/>
  <!-- Connecting Rod (I-Beam) -->
  <polygon points="144,130 156,130 162,205 138,205" fill="url(#rodSteel)" stroke="#1e293b" stroke-width="2"/>
  <!-- Connecting Rod Big-End Journal -->
  <circle cx="150" cy="215" r="22" fill="#475569" stroke="#1e293b" stroke-width="3"/>
  <circle cx="150" cy="215" r="12" fill="#f1f5f9"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">FORGED ENGINE PISTON & ROD</text>
</svg>""",

    "alternator.svg": """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <defs>
    <radialGradient id="rotorAlloy" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#cbd5e1"/>
      <stop offset="70%" stop-color="#94a3b8"/>
      <stop offset="100%" stop-color="#475569"/>
    </radialGradient>
  </defs>
  <rect width="100%" height="100%" fill="#f1f5f9" rx="16"/>
  <!-- Alternator Die-Cast Aluminum Body -->
  <circle cx="150" cy="140" r="70" fill="url(#rotorAlloy)" stroke="#334155" stroke-width="3"/>
  <!-- Copper Stator Windings visible through vent slots -->
  <circle cx="150" cy="140" r="50" fill="none" stroke="#b45309" stroke-width="8" stroke-dasharray="10,6"/>
  <!-- Internal Cooling Fan Fins -->
  <circle cx="150" cy="140" r="40" fill="#475569" stroke="#1e293b" stroke-width="2"/>
  <line x1="150" y1="105" x2="150" y2="175" stroke="#f8fafc" stroke-width="2"/>
  <line x1="115" y1="140" x2="185" y2="140" stroke="#f8fafc" stroke-width="2"/>
  <!-- Front Serpentine Belt Drive Pulley -->
  <circle cx="150" cy="140" r="22" fill="#0f172a" stroke="#334155" stroke-width="3"/>
  <circle cx="150" cy="140" r="8" fill="#e2e8f0"/>
  <!-- Mounting Bracket Ears -->
  <rect x="70" y="130" width="16" height="20" rx="4" fill="#64748b" stroke="#1e293b" stroke-width="2"/>
  <rect x="214" y="130" width="16" height="20" rx="4" fill="#64748b" stroke="#1e293b" stroke-width="2"/>
  <text x="150" y="270" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" fill="#475569" text-anchor="middle">12V HEAVY-DUTY ALTERNATOR</text>
</svg>"""
}

for filename, content in SVGS.items():
    dest = SVG_DIR / filename
    dest.write_text(content.strip(), encoding="utf-8")
    print(f"Created {filename}")

print(f"Successfully generated all {len(SVGS)} spare parts SVGs.")
