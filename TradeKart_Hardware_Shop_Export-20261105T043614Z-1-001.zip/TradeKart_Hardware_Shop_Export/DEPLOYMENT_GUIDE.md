# TradeKart Production Hosting & Deployment Guide

This guide covers deploying the **TradeKart Hardware & Industrial E-Commerce** platform (with the Spare Parts Dealer Portal and AI Camera Part Scanner) to production environments.

---

## 1. Quick Export Package

To package the entire codebase into a clean, ready-to-upload ZIP distribution file:

```powershell
# Run from PowerShell in project root:
cd C:\Users\LENOVO\.gemini\antigravity\scratch\hardware_craft_shop
python export_for_hosting.py
```

This generates **`tradekart_production_export.zip`** excluding temporary files, bytecode caches, and local lock files.

---

## 2. Cloud Hosting Options

### Option A: Render.com (Recommended Free/Low Cost PaaS)
Render natively supports Python applications and Docker.
1. Push your code to a GitHub/GitLab repository (or upload the project).
2. Go to [Render Dashboard](https://dashboard.render.com/) -> **New** -> **Web Service**.
3. Connect your repository.
4. Render will automatically detect `render.yaml` or you can manually enter:
   - **Environment**: Python
   - **Build Command**: `pip install -r requirements.txt && python setup_jpeg_images.py`
   - **Start Command**: `gunicorn -w 4 -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:$PORT`
5. Click **Create Web Service**. Your website is immediately live on an `onrender.com` URL with free automatic SSL.

---

### Option B: Railway.app (1-Click Deployment)
1. Install Railway CLI or go to [railway.app](https://railway.app).
2. Click **New Project** -> **Deploy from GitHub repo**.
3. Railway automatically detects the `Procfile` and `requirements.txt`:
   ```bash
   web: gunicorn -w 4 -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:$PORT
   ```
4. Add environment variables in the Railway dashboard if overriding defaults.

---

### Option C: Docker / VPS Hosting (DigitalOcean, AWS EC2, Linode, Ubuntu VPS)
For full control with custom domains and persistent storage:

1. **Copy code to server**:
   ```bash
   scp tradekart_production_export.zip user@your-server-ip:/var/www/
   ssh user@your-server-ip
   cd /var/www && unzip tradekart_production_export.zip -d tradekart && cd tradekart
   ```

2. **Launch via Docker Compose**:
   ```bash
   docker compose up -d --build
   ```
   This spins up the production Gunicorn/Uvicorn multi-worker container, configures internal health checks, and mounts the persistent data directory on port `8000`.

3. **Nginx Reverse Proxy & Free SSL with Certbot**:
   Create `/etc/nginx/sites-available/tradekart`:
   ```nginx
   server {
       server_name yourdomain.com www.yourdomain.com;

       location / {
           proxy_pass http://127.0.0.1:8000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```
   Enable and apply HTTPS:
   ```bash
   sudo ln -s /etc/nginx/sites-available/tradekart /etc/nginx/sites-enabled/
   sudo systemctl reload nginx
   sudo certbot --nginx -d yourdomain.com
   ```

---

## 3. Production Environment Variables Checklist

Ensure these are configured in your production environment (via `.env` or cloud dashboard):

| Variable | Recommended Production Value | Description |
| :--- | :--- | :--- |
| `HOST` | `0.0.0.0` | Bind to all network interfaces |
| `PORT` | `8000` or `$PORT` | Server listening port |
| `DEBUG` | `False` | Disable debug tracebacks |
| `SECRET_KEY` | *(64-character random string)* | Used for session cookie hashing |
| `SHOP_NAME` | `TradeKart Hardware & Supply` | Brand identity |
| `SHOP_ADDRESS` | *(Peenya 2nd Stage, Bangalore)* | Business warehouse address |
| `GSTIN` | `29AABCU9603R1ZM` | Tax registration on invoices |
