// TradeKart Hardware Checkout Script

let currentSubtotal = 0;
const TAX_RATE = 0.18; // 18% GST in India
const FLAT_DELIVERY_FEE = 99.00;
const FREE_DELIVERY_THRESHOLD = 1500.00;

document.addEventListener("DOMContentLoaded", () => {
  const cart = getCart();
  if (cart.length === 0) {
    window.location.href = "/cart";
    return;
  }

  renderCheckoutSummary(cart);
  setupDeliveryToggle();
  setupFormSubmission();
});

function renderCheckoutSummary(cart) {
  const container = document.getElementById("checkout-items-list");
  if (!container) return;

  container.innerHTML = "";
  currentSubtotal = 0;

  cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    currentSubtotal += itemTotal;

    const row = document.createElement("div");
    row.className = "flex items-center justify-between py-2 border-b border-slate-100 text-sm";
    row.innerHTML = `
      <div class="flex items-center gap-3">
        <img src="${item.image_url || '/static/images/products/antique_brass_knob.svg'}" class="w-10 h-10 object-contain rounded bg-slate-50 border border-slate-200">
        <div>
          <span class="font-medium text-slate-800 line-clamp-1">${item.name}</span>
          <span class="text-xs text-slate-500">Qty: ${item.quantity} × ₹${item.price.toFixed(2)}</span>
        </div>
      </div>
      <span class="font-semibold text-slate-800">₹${itemTotal.toFixed(2)}</span>
    `;
    container.appendChild(row);
  });

  updateCalculations();
}

function updateCalculations() {
  const deliveryRadio = document.querySelector('input[name="delivery_method"]:checked');
  const isDelivery = deliveryRadio ? deliveryRadio.value === "delivery" : true;

  let deliveryFee = 0.0;
  if (isDelivery) {
    deliveryFee = currentSubtotal >= FREE_DELIVERY_THRESHOLD ? 0.0 : FLAT_DELIVERY_FEE;
  }

  const tax = (currentSubtotal + deliveryFee) * TAX_RATE;
  const grandTotal = currentSubtotal + deliveryFee + tax;

  const subtotalEl = document.getElementById("summary-subtotal");
  const deliveryEl = document.getElementById("summary-delivery");
  const taxEl = document.getElementById("summary-tax");
  const totalEl = document.getElementById("summary-total");

  if (subtotalEl) subtotalEl.textContent = `₹${currentSubtotal.toFixed(2)}`;
  if (deliveryEl) deliveryEl.textContent = isDelivery ? (deliveryFee === 0 ? "FREE" : `₹${deliveryFee.toFixed(2)}`) : "₹0.00 (In-Store Pickup)";
  if (taxEl) taxEl.textContent = `₹${tax.toFixed(2)}`;
  if (totalEl) totalEl.textContent = `₹${grandTotal.toFixed(2)}`;
}

function setupDeliveryToggle() {
  const radios = document.querySelectorAll('input[name="delivery_method"]');
  const addressSection = document.getElementById("delivery-address-section");
  const pickupSection = document.getElementById("store-pickup-section");

  radios.forEach(radio => {
    radio.addEventListener("change", (e) => {
      if (e.target.value === "delivery") {
        if (addressSection) addressSection.classList.remove("hidden");
        if (pickupSection) pickupSection.classList.add("hidden");
      } else {
        if (addressSection) addressSection.classList.add("hidden");
        if (pickupSection) pickupSection.classList.remove("hidden");
      }
      updateCalculations();
    });
  });
}

function setupFormSubmission() {
  const form = document.getElementById("checkout-form");
  const submitBtn = document.getElementById("place-order-btn");
  const errorBox = document.getElementById("checkout-error-box");

  if (!form || !submitBtn) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (errorBox) errorBox.classList.add("hidden");

    const cart = getCart();
    if (cart.length === 0) {
      showToast("Your cart is empty.", "error");
      return;
    }

    const formData = new FormData(form);
    const deliveryMethod = formData.get("delivery_method");

    // Client-side address validation if delivery
    if (deliveryMethod === "delivery") {
      const address = formData.get("delivery_address")?.trim();
      const city = formData.get("delivery_city")?.trim();
      const postal = formData.get("delivery_postal")?.trim();

      if (!address || !city || !postal) {
        showErrorMessage("Please fill in your delivery street address, city, and postal code.");
        return;
      }
    }

    const payload = {
      customer_name: formData.get("customer_name")?.trim(),
      customer_email: formData.get("customer_email")?.trim(),
      customer_phone: formData.get("customer_phone")?.trim(),
      delivery_method: deliveryMethod,
      delivery_address: formData.get("delivery_address")?.trim() || "",
      delivery_city: formData.get("delivery_city")?.trim() || "",
      delivery_state: formData.get("delivery_state")?.trim() || "",
      delivery_postal: formData.get("delivery_postal")?.trim() || "",
      delivery_notes: formData.get("delivery_notes")?.trim() || "",
      
      payment_method: formData.get("payment_method") || "mock_card",
      card_number: formData.get("card_number")?.trim() || "",
      card_expiry: formData.get("card_expiry")?.trim() || "",
      card_cvc: formData.get("card_cvc")?.trim() || "",
      
      cart_items: cart.map(i => ({ product_id: i.product_id, quantity: i.quantity }))
    };

    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
      Processing Order...
    `;

    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.detail || result.message || "Failed to process order.");
      }

      // Success! Clear cart and redirect
      clearCart();
      window.location.href = `/order-success/${result.order_number}`;
    } catch (err) {
      showErrorMessage(err.message);
      submitBtn.disabled = false;
      submitBtn.innerHTML = `Place Order & Pay`;
    }
  });
}

function showErrorMessage(msg) {
  const errorBox = document.getElementById("checkout-error-box");
  if (errorBox) {
    errorBox.textContent = msg;
    errorBox.classList.remove("hidden");
    errorBox.scrollIntoView({ behavior: "smooth", block: "center" });
  } else {
    showToast(msg, "error");
  }
}
