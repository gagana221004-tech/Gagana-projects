// TradeKart Hardware Main Client-side JS

const CART_KEY = "tradekart_cart_v1";

function getCart() {
  try {
    let raw = localStorage.getItem(CART_KEY);
    if (!raw) {
      raw = localStorage.getItem("ironclad_cart_v1");
    }
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error("Failed to load cart from storage:", e);
    return [];
  }
}

function saveCart(cart) {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    updateCartBadge();
  } catch (e) {
    console.error("Failed to save cart:", e);
  }
}

function updateCartBadge() {
  const cart = getCart();
  const totalCount = cart.reduce((sum, item) => sum + (parseInt(item.quantity) || 0), 0);
  const badges = document.querySelectorAll(".cart-count-badge");
  badges.forEach(badge => {
    badge.textContent = totalCount;
    if (totalCount > 0) {
      badge.classList.remove("hidden");
    } else {
      badge.classList.add("hidden");
    }
  });
}

function addToCart(productId, name, price, maxStock, imageUrl, requestedQty = 1) {
  productId = parseInt(productId);
  requestedQty = parseInt(requestedQty) || 1;
  maxStock = parseInt(maxStock) || 0;

  if (maxStock <= 0) {
    showToast(`Sorry, "${name}" is currently out of stock.`, "error");
    return false;
  }

  let cart = getCart();
  const existingIndex = cart.findIndex(item => item.product_id === productId);

  if (existingIndex > -1) {
    const newQty = cart[existingIndex].quantity + requestedQty;
    if (newQty > maxStock) {
      showToast(`Cannot add more. Maximum available stock is ${maxStock}.`, "error");
      return false;
    }
    cart[existingIndex].quantity = newQty;
    cart[existingIndex].maxStock = maxStock;
  } else {
    if (requestedQty > maxStock) {
      showToast(`Cannot add ${requestedQty}. Only ${maxStock} in stock.`, "error");
      return false;
    }
    cart.push({
      product_id: productId,
      name: name,
      price: parseFloat(price),
      maxStock: maxStock,
      image_url: imageUrl,
      quantity: requestedQty
    });
  }

  saveCart(cart);
  showToast(`Added ${requestedQty}x "${name}" to your cart!`, "success");
  return true;
}

function updateCartQuantity(productId, newQty) {
  productId = parseInt(productId);
  newQty = parseInt(newQty);
  let cart = getCart();
  const item = cart.find(i => i.product_id === productId);

  if (!item) return;

  if (newQty <= 0) {
    removeFromCart(productId);
    return;
  }

  if (item.maxStock && newQty > item.maxStock) {
    showToast(`Only ${item.maxStock} items available in stock.`, "error");
    item.quantity = item.maxStock;
  } else {
    item.quantity = newQty;
  }

  saveCart(cart);
  renderCartPageIfPresent();
}

function removeFromCart(productId) {
  productId = parseInt(productId);
  let cart = getCart();
  cart = cart.filter(item => item.product_id !== productId);
  saveCart(cart);
  showToast("Item removed from cart.", "info");
  renderCartPageIfPresent();
}

function clearCart() {
  localStorage.removeItem(CART_KEY);
  updateCartBadge();
  renderCartPageIfPresent();
}

function showToast(message, type = "success") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast-item px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 text-sm font-medium ${
    type === "error" ? "bg-red-600 text-white" :
    type === "info" ? "bg-amber-600 text-white" :
    "bg-slate-900 text-white border border-slate-700"
  }`;

  const icon = type === "error" ? "⚠️" : type === "info" ? "ℹ️" : "✅";
  toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
  container.appendChild(toast);

  // Trigger animation
  setTimeout(() => toast.classList.add("show"), 10);
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function renderCartPageIfPresent() {
  const container = document.getElementById("cart-items-container");
  if (!container) return;

  const cart = getCart();
  const emptyState = document.getElementById("cart-empty-state");
  const tableWrapper = document.getElementById("cart-table-wrapper");
  const summaryBox = document.getElementById("cart-summary-box");

  if (cart.length === 0) {
    if (emptyState) emptyState.classList.remove("hidden");
    if (tableWrapper) tableWrapper.classList.add("hidden");
    if (summaryBox) summaryBox.classList.add("hidden");
    return;
  }

  if (emptyState) emptyState.classList.add("hidden");
  if (tableWrapper) tableWrapper.classList.remove("hidden");
  if (summaryBox) summaryBox.classList.remove("hidden");

  let subtotal = 0;
  container.innerHTML = "";

  cart.forEach(item => {
    const itemSubtotal = item.price * item.quantity;
    subtotal += itemSubtotal;

    const row = document.createElement("tr");
    row.className = "border-b border-slate-100 hover:bg-slate-50 transition-colors";
    row.innerHTML = `
      <td class="py-4 px-4">
        <div class="flex items-center gap-4">
          <img src="${item.image_url || '/static/images/products/antique_brass_knob.svg'}" 
               alt="${item.name}" 
               class="w-16 h-16 rounded-lg object-contain bg-slate-100 p-1 border border-slate-200">
          <div>
            <h4 class="font-semibold text-slate-800">${item.name}</h4>
            <span class="text-xs text-slate-500">Unit: ₹${item.price.toFixed(2)}</span>
          </div>
        </div>
      </td>
      <td class="py-4 px-4 text-center">
        <div class="inline-flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
          <button type="button" onclick="updateCartQuantity(${item.product_id}, ${item.quantity - 1})" 
                  class="px-2.5 py-1 text-slate-600 hover:bg-slate-100 font-bold">-</button>
          <span class="px-3 py-1 text-sm font-semibold text-slate-800">${item.quantity}</span>
          <button type="button" onclick="updateCartQuantity(${item.product_id}, ${item.quantity + 1})" 
                  class="px-2.5 py-1 text-slate-600 hover:bg-slate-100 font-bold">+</button>
        </div>
      </td>
      <td class="py-4 px-4 text-right font-bold text-slate-900">
        ₹${itemSubtotal.toFixed(2)}
      </td>
      <td class="py-4 px-4 text-center">
        <button type="button" onclick="removeFromCart(${item.product_id})" 
                class="text-red-500 hover:text-red-700 p-1 rounded-md hover:bg-red-50 transition" title="Remove item">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
          </svg>
        </button>
      </td>
    `;
    container.appendChild(row);
  });

  // Calculate fees
  const subtotalEl = document.getElementById("cart-subtotal");
  const deliveryEl = document.getElementById("cart-delivery");
  const taxEl = document.getElementById("cart-tax");
  const totalEl = document.getElementById("cart-total");

  if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toFixed(2)}`;

  // Delivery fee estimation: free over threshold
  const freeThreshold = 1500.0;
  const flatFee = 99.00;
  const estDelivery = subtotal >= freeThreshold ? 0.0 : flatFee;
  if (deliveryEl) deliveryEl.textContent = estDelivery === 0 ? "FREE" : `₹${estDelivery.toFixed(2)}`;

  const tax = (subtotal + estDelivery) * 0.18; // 18% GST
  if (taxEl) taxEl.textContent = `₹${tax.toFixed(2)}`;

  const grandTotal = subtotal + estDelivery + tax;
  if (totalEl) totalEl.textContent = `₹${grandTotal.toFixed(2)}`;
}

// Mobile navigation menu toggle
function toggleMobileMenu() {
  const menu = document.getElementById("mobile-menu");
  if (menu) {
    menu.classList.toggle("hidden");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  renderCartPageIfPresent();
});
