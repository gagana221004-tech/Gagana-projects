/**
 * TradeKart Auto Spare Parts Dealer Portal - Client-Side Wholesale Cart
 * Handles MOQ validation, quantity changes, live discount & GST calculations.
 */

const SP_CART_KEY = "tradekart_spareparts_cart_v1";

function getSparePartsCart() {
  try {
    const raw = localStorage.getItem(SP_CART_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error("Failed to load spare parts cart:", e);
    return [];
  }
}

function saveSparePartsCart(cart) {
  try {
    localStorage.setItem(SP_CART_KEY, JSON.stringify(cart));
    updateSparePartsCartBadge();
  } catch (e) {
    console.error("Failed to save spare parts cart:", e);
  }
}

function updateSparePartsCartBadge() {
  const cart = getSparePartsCart();
  const totalUnits = cart.reduce((sum, item) => sum + parseInt(item.quantity || 0), 0);
  const badges = document.querySelectorAll(".sp-cart-count-badge");
  badges.forEach((b) => {
    b.textContent = totalUnits;
    if (totalUnits > 0) {
      b.classList.remove("hidden");
    } else {
      b.classList.add("hidden");
    }
  });
}

function addToWholesaleCart(partId, name, sku, brand, wholesalePrice, srp, moq, stock, imgUrl, qty) {
  partId = parseInt(partId);
  moq = parseInt(moq) || 1;
  stock = parseInt(stock) || 0;
  qty = parseInt(qty) || moq;

  if (stock <= 0) {
    showSpToast("This part is currently Out of Stock.", "error");
    return;
  }

  if (qty < moq) {
    showSpToast(`Minimum Order Quantity (MOQ) for this part is ${moq} units.`, "warning");
    qty = moq;
  }

  const cart = getSparePartsCart();
  const existing = cart.find((i) => i.partId === partId);

  if (existing) {
    const newQty = existing.quantity + qty;
    if (newQty > stock) {
      showSpToast(`Cannot exceed total available warehouse stock (${stock} units).`, "warning");
      existing.quantity = stock;
    } else {
      existing.quantity = newQty;
      showSpToast(`Updated ${name} to ${existing.quantity} units in wholesale cart!`, "success");
    }
  } else {
    if (qty > stock) {
      showSpToast(`Only ${stock} units available in warehouse.`, "warning");
      qty = stock;
    }
    cart.push({
      partId,
      name,
      sku,
      brand,
      wholesalePrice: parseFloat(wholesalePrice),
      suggestedRetailPrice: parseFloat(srp),
      moq,
      stock,
      imageUrl: imgUrl,
      quantity: qty
    });
    showSpToast(`Added ${qty} units of ${name} to Wholesale Cart!`, "success");
  }

  saveSparePartsCart(cart);
}

function removeSparePartFromCart(partId) {
  let cart = getSparePartsCart();
  cart = cart.filter((i) => i.partId !== parseInt(partId));
  saveSparePartsCart(cart);
  renderWholesaleCartPage();
}

function updateSparePartCartQty(partId, newQty) {
  partId = parseInt(partId);
  newQty = parseInt(newQty);
  const cart = getSparePartsCart();
  const item = cart.find((i) => i.partId === partId);

  if (!item) return;

  if (newQty < item.moq) {
    showSpToast(`Minimum Order Quantity (MOQ) is ${item.moq} units.`, "warning");
    item.quantity = item.moq;
  } else if (newQty > item.stock) {
    showSpToast(`Max available warehouse inventory is ${item.stock} units.`, "warning");
    item.quantity = item.stock;
  } else {
    item.quantity = newQty;
  }

  saveSparePartsCart(cart);
  renderWholesaleCartPage();
}

function renderWholesaleCartPage() {
  const container = document.getElementById("sp-cart-items-container");
  if (!container) return;

  const cart = getSparePartsCart();
  const discountPercent = parseFloat(window.RETAILER_DISCOUNT_PERCENT || 0.0);

  if (cart.length === 0) {
    container.innerHTML = `
      <tr>
        <td colspan="6" class="py-12 text-center text-slate-500">
          <div class="text-4xl mb-3">📦</div>
          <p class="font-bold text-slate-700 text-base">Your wholesale cart is empty</p>
          <p class="text-xs text-slate-400 mt-1">Browse our automotive parts catalog and add bulk items meeting required MOQs.</p>
          <a href="/spare-parts" class="mt-4 inline-block px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm transition">
            Explore Spare Parts Catalog →
          </a>
        </td>
      </tr>
    `;
    updateWholesaleSummary(0, 0);
    const checkoutBtn = document.getElementById("sp-checkout-submit-btn");
    if (checkoutBtn) checkoutBtn.disabled = true;
    return;
  }

  let grossSubtotal = 0;
  let html = "";

  cart.forEach((it) => {
    const lineTotal = it.wholesalePrice * it.quantity;
    grossSubtotal += lineTotal;

    html += `
      <tr class="border-b border-slate-100 hover:bg-slate-50/60 transition">
        <td class="py-4 px-3">
          <div class="flex items-center gap-3">
            <img src="${it.imageUrl}" alt="${it.name}" class="w-12 h-12 object-contain rounded-lg bg-slate-100 p-1 border border-slate-200 shrink-0">
            <div>
              <p class="font-bold text-slate-900 text-sm leading-tight">${it.name}</p>
              <div class="flex items-center gap-2 mt-1 text-[11px] text-slate-500 font-mono">
                <span>SKU: ${it.sku}</span>
                <span>•</span>
                <span class="text-emerald-700 font-bold">${it.brand}</span>
              </div>
            </div>
          </div>
        </td>
        <td class="py-4 px-3 text-right">
          <span class="font-bold text-slate-900 text-sm">₹${it.wholesalePrice.toFixed(2)}</span>
          <span class="block text-[10px] text-slate-400">SRP: ₹${it.suggestedRetailPrice.toFixed(2)}</span>
        </td>
        <td class="py-4 px-3 text-center">
          <span class="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 text-xs font-bold">
            ${it.moq} units
          </span>
        </td>
        <td class="py-4 px-3 text-center">
          <div class="inline-flex items-center border border-slate-300 rounded-xl overflow-hidden bg-white shadow-sm">
            <button type="button" onclick="updateSparePartCartQty(${it.partId}, ${it.quantity - 1})" class="px-2.5 py-1 text-slate-600 hover:bg-slate-100 font-bold text-sm">-</button>
            <input type="number" min="${it.moq}" max="${it.stock}" value="${it.quantity}" 
                   onchange="updateSparePartCartQty(${it.partId}, this.value)" 
                   class="w-14 text-center py-1 text-xs font-bold border-x border-slate-200 focus:outline-none">
            <button type="button" onclick="updateSparePartCartQty(${it.partId}, ${it.quantity + 1})" class="px-2.5 py-1 text-slate-600 hover:bg-slate-100 font-bold text-sm">+</button>
          </div>
          <span class="block text-[10px] text-slate-400 mt-0.5">${it.stock} in stock</span>
        </td>
        <td class="py-4 px-3 text-right font-black text-slate-900 text-sm">
          ₹${lineTotal.toFixed(2)}
        </td>
        <td class="py-4 px-2 text-center">
          <button type="button" onclick="removeSparePartFromCart(${it.partId})" class="text-slate-400 hover:text-red-600 p-1 rounded-lg transition" title="Remove item">
            🗑️
          </button>
        </td>
      </tr>
    `;
  });

  container.innerHTML = html;
  updateWholesaleSummary(grossSubtotal, discountPercent);
  const checkoutBtn = document.getElementById("sp-checkout-submit-btn");
  if (checkoutBtn) checkoutBtn.disabled = false;
}

function updateWholesaleSummary(grossSubtotal, discountPercent) {
  const discountAmount = grossSubtotal * (discountPercent / 100.0);
  const taxableValue = grossSubtotal - discountAmount;
  const gstAmount = taxableValue * 0.18;
  const grandTotal = taxableValue + gstAmount;

  const setTxt = (id, txt) => {
    const el = document.getElementById(id);
    if (el) el.textContent = txt;
  };

  setTxt("sp-summary-subtotal", `₹${grossSubtotal.toFixed(2)}`);
  setTxt("sp-summary-discount", `- ₹${discountAmount.toFixed(2)} (${discountPercent}% Tier)`);
  setTxt("sp-summary-taxable", `₹${taxableValue.toFixed(2)}`);
  setTxt("sp-summary-gst", `₹${gstAmount.toFixed(2)}`);
  setTxt("sp-summary-grand-total", `₹${grandTotal.toFixed(2)}`);
}

function showSpToast(message, type = "info") {
  let box = document.getElementById("sp-toast-box");
  if (!box) {
    box = document.createElement("div");
    box.id = "sp-toast-box";
    box.className = "fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none";
    document.body.appendChild(box);
  }

  const toast = document.createElement("div");
  const bg = type === "error" ? "bg-red-900 text-red-100 border-red-700" :
             type === "warning" ? "bg-amber-800 text-amber-100 border-amber-600" :
             type === "success" ? "bg-emerald-800 text-emerald-100 border-emerald-600" :
             "bg-slate-900 text-slate-100 border-slate-700";

  toast.className = `p-4 rounded-2xl shadow-2xl border text-xs font-semibold flex items-center gap-3 transition-all transform duration-300 pointer-events-auto ${bg}`;
  toast.innerHTML = `
    <span>${type === 'error' ? '❌' : type === 'warning' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️'}</span>
    <div class="flex-1">${message}</div>
  `;

  box.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

document.addEventListener("DOMContentLoaded", () => {
  updateSparePartsCartBadge();
  renderWholesaleCartPage();
});
