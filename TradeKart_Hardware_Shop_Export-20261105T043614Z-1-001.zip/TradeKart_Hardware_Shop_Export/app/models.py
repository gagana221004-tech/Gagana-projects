from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr, field_validator

class UserRegisterModel(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=100)
    phone: Optional[str] = Field("", max_length=30)
    address: Optional[str] = Field("", max_length=255)
    city: Optional[str] = Field("", max_length=100)
    postal_code: Optional[str] = Field("", max_length=20)

class UserLoginModel(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=1)

class ProductFormModel(BaseModel):
    name: str = Field(..., min_length=2, max_length=150)
    category_id: int = Field(..., gt=0)
    sku: str = Field(..., min_length=2, max_length=50)
    description: Optional[str] = ""
    specifications: Optional[str] = ""
    price: float = Field(..., gt=0)
    stock_quantity: int = Field(..., ge=0)
    reorder_point: int = Field(5, ge=0)
    image_url: Optional[str] = ""
    is_active: int = Field(1, ge=0, le=1)

    @field_validator('sku')
    @classmethod
    def clean_sku(cls, v: str) -> str:
        return v.strip().upper()

class CartItemModel(BaseModel):
    product_id: int = Field(..., gt=0)
    quantity: int = Field(..., gt=0)

class CheckoutSubmitModel(BaseModel):
    customer_name: str = Field(..., min_length=2, max_length=100)
    customer_email: EmailStr
    customer_phone: str = Field(..., min_length=6, max_length=30)
    delivery_method: str = Field("delivery") # 'delivery' or 'pickup'
    delivery_address: Optional[str] = ""
    delivery_city: Optional[str] = ""
    delivery_state: Optional[str] = ""
    delivery_postal: Optional[str] = ""
    delivery_notes: Optional[str] = ""
    
    # Payment fields
    payment_method: str = Field("mock_card") # 'mock_card' or 'stripe_token'
    card_number: Optional[str] = ""
    card_expiry: Optional[str] = ""
    card_cvc: Optional[str] = ""
    stripe_payment_method_id: Optional[str] = ""

    @field_validator('delivery_method')
    @classmethod
    def validate_method(cls, v: str) -> str:
        if v not in ("delivery", "pickup"):
            raise ValueError("Delivery method must be 'delivery' or 'pickup'")
        return v

class RestockActionModel(BaseModel):
    product_id: int = Field(..., gt=0)
    additional_stock: int = Field(..., gt=0)
    reason: Optional[str] = "Shopkeeper manual restock"
