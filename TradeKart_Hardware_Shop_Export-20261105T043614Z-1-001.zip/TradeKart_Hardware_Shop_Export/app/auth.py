import hmac
import hashlib
import os
import json
import base64
import time
from typing import Optional, Dict, Any
from fastapi import Request, HTTPException, status
from fastapi.responses import RedirectResponse
from app.config import settings
from app.database import get_db

COOKIE_NAME = "hardware_shop_session"
SESSION_DURATION_SECONDS = 60 * 60 * 24 * 7  # 7 days

def hash_password(password: str) -> tuple[str, str]:
    """Generates a salt and hashes password with PBKDF2-HMAC-SHA256."""
    salt = os.urandom(16).hex()
    pwd_bytes = password.encode('utf-8')
    salt_bytes = salt.encode('utf-8')
    pwd_hash = hashlib.pbkdf2_hmac('sha256', pwd_bytes, salt_bytes, 100000).hex()
    return pwd_hash, salt

def verify_password(plain_password: str, salt: str, expected_hash: str) -> bool:
    """Verifies a plain password against stored salt and hash."""
    pwd_bytes = plain_password.encode('utf-8')
    salt_bytes = salt.encode('utf-8')
    calculated_hash = hashlib.pbkdf2_hmac('sha256', pwd_bytes, salt_bytes, 100000).hex()
    return hmac.compare_digest(calculated_hash, expected_hash)

def create_session_token(user_id: int, role: str, email: str) -> str:
    """Creates a base64-encoded, HMAC-SHA256 signed session token."""
    payload = {
        "user_id": user_id,
        "role": role,
        "email": email,
        "exp": int(time.time()) + SESSION_DURATION_SECONDS
    }
    payload_json = json.dumps(payload, separators=(',', ':'))
    payload_b64 = base64.urlsafe_b64encode(payload_json.encode('utf-8')).decode('utf-8').rstrip('=')
    
    signature = hmac.new(
        settings.SECRET_KEY.encode('utf-8'),
        payload_b64.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return f"{payload_b64}.{signature}"

def decode_session_token(token: str) -> Optional[Dict[str, Any]]:
    """Validates the signature and expiry of a session token."""
    if not token or '.' not in token:
        return None
    try:
        payload_b64, signature = token.split('.', 1)
        expected_sig = hmac.new(
            settings.SECRET_KEY.encode('utf-8'),
            payload_b64.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        if not hmac.compare_digest(signature, expected_sig):
            return None
        
        padding = 4 - (len(payload_b64) % 4)
        if padding != 4:
            payload_b64 += '=' * padding
            
        payload_str = base64.urlsafe_b64decode(payload_b64.encode('utf-8')).decode('utf-8')
        payload = json.loads(payload_str)
        
        if payload.get("exp", 0) < time.time():
            return None
            
        return payload
    except Exception:
        return None

def get_current_user(request: Request) -> Optional[Dict[str, Any]]:
    """Retrieves current user from session cookie and database."""
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
        
    payload = decode_session_token(token)
    if not payload:
        return None
        
    user_id = payload.get("user_id")
    with get_db() as conn:
        row = conn.execute(
            "SELECT id, email, full_name, phone, address, city, postal_code, role, created_at FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
        if row:
            return dict(row)
    return None

def require_customer_redirect(request: Request) -> Dict[str, Any]:
    """Dependency that ensures customer is logged in, or redirects to login."""
    user = get_current_user(request)
    if not user:
        # Save intended destination
        redirect_url = str(request.url.path)
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": f"/login?next={redirect_url}"}
        )
    return user

def require_admin_redirect(request: Request) -> Dict[str, Any]:
    """Dependency that ensures user is logged in as admin, or redirects to admin login."""
    user = get_current_user(request)
    if not user or user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": "/admin/login?error=Admin%20access%20required"}
        )
    return user
