import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
env_file = BASE_DIR / ".env"
if env_file.exists():
    load_dotenv(env_file)

class Settings:
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))
    SECRET_KEY: str = os.getenv("SECRET_KEY", "tradekart_production_secret_key_change_me_2026")
    DEBUG: bool = os.getenv("DEBUG", "False").lower() in ("true", "1", "yes")

    SHOP_NAME: str = os.getenv("SHOP_NAME", "TradeKart Hardware & Industrial Supply")
    SHOP_EMAIL: str = os.getenv("SHOP_EMAIL", "support@tradekart.in")
    SHOP_PHONE: str = os.getenv("SHOP_PHONE", "+91 80 2839 4567")
    SHOP_ADDRESS: str = os.getenv("SHOP_ADDRESS", "Shop #42, 8th Main Road, Industrial Suburb, Peenya 2nd Stage, Bangalore, Karnataka 560058")
    GSTIN: str = os.getenv("GSTIN", "29AABCU9603R1ZM")

    DATABASE_PATH: str = str(BASE_DIR / os.getenv("DATABASE_PATH", "hardware_shop.db"))

    CURRENCY_SYMBOL: str = os.getenv("CURRENCY_SYMBOL", "₹")
    CURRENCY_CODE: str = os.getenv("CURRENCY_CODE", "INR")
    TAX_RATE: float = float(os.getenv("TAX_RATE", "0.18"))
    DELIVERY_FLAT_FEE: float = float(os.getenv("DELIVERY_FLAT_FEE", "99.00"))
    FREE_DELIVERY_THRESHOLD: float = float(os.getenv("FREE_DELIVERY_THRESHOLD", "1500.00"))
    DEFAULT_SAFETY_STOCK: int = int(os.getenv("DEFAULT_SAFETY_STOCK", "5"))

    PAYMENT_PROVIDER: str = os.getenv("PAYMENT_PROVIDER", "mock")
    STRIPE_PUBLISHABLE_KEY: str = os.getenv("STRIPE_PUBLISHABLE_KEY", "pk_test_sample")
    STRIPE_SECRET_KEY: str = os.getenv("STRIPE_SECRET_KEY", "sk_test_sample")

    DELIVERY_PROVIDER: str = os.getenv("DELIVERY_PROVIDER", "local_courier")
    DELIVERY_API_ENDPOINT: str = os.getenv("DELIVERY_API_ENDPOINT", "https://api.expresscourier.example/v1/dispatch")
    DELIVERY_API_KEY: str = os.getenv("DELIVERY_API_KEY", "dev_courier_token_default")

settings = Settings()
