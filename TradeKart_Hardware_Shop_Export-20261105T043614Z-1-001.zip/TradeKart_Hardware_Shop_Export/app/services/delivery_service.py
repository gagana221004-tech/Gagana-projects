import abc
import uuid
import logging
from typing import Dict, Any, Optional
from pydantic import BaseModel
from app.config import settings

logger = logging.getLogger(__name__)

class DeliveryDispatchResult(BaseModel):
    success: bool
    carrier_name: str
    tracking_number: str
    estimated_delivery: str
    status: str
    message: str
    api_payload: Optional[Dict[str, Any]] = None

class BaseDeliveryAdapter(abc.ABC):
    @abc.abstractmethod
    def dispatch_order(self, order_data: Dict[str, Any]) -> DeliveryDispatchResult:
        """Dispatches an order to the delivery service."""
        pass

    @abc.abstractmethod
    def calculate_delivery_fee(self, subtotal: float, delivery_method: str) -> float:
        """Computes delivery fee based on method and cart value."""
        pass

class LocalCourierAdapter(BaseDeliveryAdapter):
    """
    Direct in-house / local express courier adapter.
    """
    def calculate_delivery_fee(self, subtotal: float, delivery_method: str) -> float:
        if delivery_method == "pickup":
            return 0.0
        if subtotal >= settings.FREE_DELIVERY_THRESHOLD:
            return 0.0
        return settings.DELIVERY_FLAT_FEE

    def dispatch_order(self, order_data: Dict[str, Any]) -> DeliveryDispatchResult:
        order_num = order_data.get("order_number", "ORD")
        tracking_num = f"BLR-{order_num[-6:]}-{uuid.uuid4().hex[:4].upper()}"
        
        return DeliveryDispatchResult(
            success=True,
            carrier_name="Bangalore Express Cargo Van (Tata Ace)",
            tracking_number=tracking_num,
            estimated_delivery="Same-day or next-day delivery across Bengaluru (BBMP Limits)",
            status="dispatched_to_courier",
            message=f"Order scheduled with local logistics van for delivery to {order_data.get('delivery_city', 'Bangalore')}.",
            api_payload={
                "courier_dispatch_id": str(uuid.uuid4()),
                "destination": order_data.get("delivery_address"),
                "recipient": order_data.get("customer_name"),
                "phone": order_data.get("customer_phone"),
                "notes": order_data.get("delivery_notes")
            }
        )

class ExternalApiDeliveryAdapter(BaseDeliveryAdapter):
    """
    External 3rd-party Delivery Platform Adapter (e.g. On-Demand Logistics API).
    Documented Endpoint: POST /v1/dispatch
    Headers: Authorization: Bearer <DELIVERY_API_KEY>, Content-Type: application/json
    Payload:
    {
       "order_id": str,
       "dropoff_address": { "street": str, "city": str, "zip": str },
       "recipient": { "name": str, "phone": str },
       "package_type": "hardware_heavy_goods"
    }
    """
    def __init__(self, endpoint: Optional[str] = None, api_key: Optional[str] = None):
        self.endpoint = endpoint or settings.DELIVERY_API_ENDPOINT
        self.api_key = api_key or settings.DELIVERY_API_KEY

    def calculate_delivery_fee(self, subtotal: float, delivery_method: str) -> float:
        if delivery_method == "pickup":
            return 0.0
        if subtotal >= settings.FREE_DELIVERY_THRESHOLD:
            return 0.0
        return settings.DELIVERY_FLAT_FEE + 50.00 # Heavy goods freight surcharge

    def dispatch_order(self, order_data: Dict[str, Any]) -> DeliveryDispatchResult:
        tracking_num = f"PRT-{uuid.uuid4().hex[:8].upper()}"
        logger.info(f"Dispatching order {order_data.get('order_number')} to external delivery endpoint: {self.endpoint}")
        
        payload = {
            "order_number": order_data.get("order_number"),
            "service_level": "standard_parcel_freight",
            "dropoff": {
                "recipient_name": order_data.get("customer_name"),
                "phone": order_data.get("customer_phone"),
                "street": order_data.get("delivery_address"),
                "city": order_data.get("delivery_city"),
                "postal_code": order_data.get("delivery_postal"),
                "notes": order_data.get("delivery_notes")
            },
            "weight_class": "medium_heavy",
            "items_count": len(order_data.get("items", []))
        }

        return DeliveryDispatchResult(
            success=True,
            carrier_name="Porter Freight Logistics (Bengaluru)",
            tracking_number=tracking_num,
            estimated_delivery="1 business day with live SMS tracking",
            status="manifest_created",
            message="Package manifest electronically submitted to carrier endpoint.",
            api_payload=payload
        )

def get_delivery_adapter() -> BaseDeliveryAdapter:
    """Factory to get the configured delivery adapter."""
    provider = settings.DELIVERY_PROVIDER.lower()
    if provider in ("api_dispatcher", "external", "swiftfreight"):
        return ExternalApiDeliveryAdapter()
    return LocalCourierAdapter()
