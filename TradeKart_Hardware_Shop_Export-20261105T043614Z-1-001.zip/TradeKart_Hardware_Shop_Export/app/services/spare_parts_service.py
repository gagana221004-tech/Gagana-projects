"""
Service layer for Spare Parts Dealer Portal (Automobile Wholesale & Retail).
Handles inventory surveillance, atomic order processing, reorder alerts,
invoice generation, analytics, and in-app notifications.
"""
import uuid
import datetime
from typing import Dict, Any, List, Optional
from app.database import get_db

class InsufficientSparePartStockException(Exception):
    """Raised when an order quantity exceeds available stock."""
    pass

class RetailerNotApprovedException(Exception):
    """Raised when an inactive or pending retailer attempts to place an order."""
    pass

class BelowMinimumOrderQtyException(Exception):
    """Raised when an item quantity is below the required MOQ."""
    pass

def create_portal_notification(
    recipient_type: str,
    retailer_id: Optional[int],
    event_type: str,
    title: str,
    message: str,
    link_url: str = ""
) -> int:
    """
    Creates an in-app notification for admin or retailer,
    and logs an audit event (simulating dispatch to external notification channels).
    """
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO portal_notifications (
                recipient_type, retailer_id, event_type, title, message, link_url, is_read
            ) VALUES (?, ?, ?, ?, ?, ?, 0)
        """, (recipient_type, retailer_id, event_type, title, message, link_url))
        notif_id = cursor.lastrowid
        
    try:
        # Safe log for Windows console (replaces non-ASCII if needed)
        safe_msg = message.encode("ascii", errors="replace").decode("ascii")
        safe_title = title.encode("ascii", errors="replace").decode("ascii")
        print(f"[PORTAL NOTIFICATION - {event_type.upper()}] To: {recipient_type} (Retailer #{retailer_id}) | {safe_title}: {safe_msg}")
    except Exception:
        pass
    return notif_id

def get_spare_parts_filtered(
    search_query: Optional[str] = None,
    vehicle_type: Optional[str] = None,
    brand: Optional[str] = None,
    category: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    in_stock_only: bool = False,
    sort_by: str = "default"
) -> List[Dict[str, Any]]:
    """
    Retrieves filtered catalogue of automobile spare parts.
    """
    query = """
        SELECT id, name, slug, sku, vehicle_type, brand, compatible_models,
               category, wholesale_price, suggested_retail_price, cost_price,
               stock_quantity, reorder_point, min_order_qty,
               image_url, description, specifications, is_active
        FROM spare_parts
        WHERE is_active = 1
    """
    params = []
    
    if search_query:
        sq = f"%{search_query.strip()}%"
        query += " AND (name LIKE ? OR sku LIKE ? OR compatible_models LIKE ? OR brand LIKE ?)"
        params.extend([sq, sq, sq, sq])
        
    if vehicle_type and vehicle_type not in ("all", ""):
        query += " AND vehicle_type = ?"
        params.append(vehicle_type)
        
    if brand and brand not in ("all", ""):
        query += " AND brand = ?"
        params.append(brand)
        
    if category and category not in ("all", ""):
        query += " AND category = ?"
        params.append(category)
        
    if min_price is not None:
        query += " AND wholesale_price >= ?"
        params.append(min_price)
        
    if max_price is not None:
        query += " AND wholesale_price <= ?"
        params.append(max_price)
        
    if in_stock_only:
        query += " AND stock_quantity > 0"
        
    if sort_by == "price_asc":
        query += " ORDER BY wholesale_price ASC"
    elif sort_by == "price_desc":
        query += " ORDER BY wholesale_price DESC"
    elif sort_by == "name_asc":
        query += " ORDER BY name ASC"
    elif sort_by == "stock_asc":
        query += " ORDER BY stock_quantity ASC"
    else:
        query += " ORDER BY id ASC"
        
    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

def get_spare_part_by_id(part_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM spare_parts WHERE id = ?", (part_id,)).fetchone()
        return dict(row) if row else None

def get_retailer_by_user_id(user_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM retailers WHERE user_id = ?", (user_id,)).fetchone()
        return dict(row) if row else None

def get_retailer_by_id(retailer_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM retailers WHERE id = ?", (retailer_id,)).fetchone()
        return dict(row) if row else None

def process_wholesale_order_atomic(
    retailer_id: int,
    cart_items: List[Dict[str, Any]],
    delivery_info: Dict[str, Any],
    payment_method: str = "credit"
) -> Dict[str, Any]:
    """
    Executes an atomic checkout for wholesale spare parts orders.
    1. Verifies retailer is active and approved.
    2. Validates MOQ and stock availability in a single transaction.
    3. Decrements stock atomically.
    4. Evaluates reorder point: if stock <= reorder_point, triggers admin alert!
    5. Calculates wholesale discount and 18% GST.
    6. Generates order, line items, and tax invoice.
    7. Dispatches in-app notifications.
    """
    if not cart_items:
        raise ValueError("Wholesale cart cannot be empty.")
        
    with get_db() as conn:
        cursor = conn.cursor()
        
        # 1. Retailer check
        cursor.execute("SELECT * FROM retailers WHERE id = ?", (retailer_id,))
        retailer = cursor.fetchone()
        if not retailer:
            raise ValueError(f"Retailer account #{retailer_id} not found.")
        if retailer["status"] != "approved":
            raise RetailerNotApprovedException(
                f"Retailer account is currently '{retailer['status']}'. Orders require an approved account."
            )
            
        discount_percent = float(retailer["discount_percent"] or 0.0)
        
        # 2. Lock & validate all parts stock and MOQ
        items_to_order = []
        raw_subtotal = 0.0
        reorder_alerts_to_trigger = []
        out_of_stock_to_trigger = []
        
        for item in cart_items:
            part_id = int(item["part_id"])
            qty = int(item["quantity"])
            
            cursor.execute("""
                SELECT id, name, sku, brand, vehicle_type, category,
                       wholesale_price, stock_quantity, reorder_point, min_order_qty
                FROM spare_parts
                WHERE id = ? AND is_active = 1
            """, (part_id,))
            part = cursor.fetchone()
            
            if not part:
                raise ValueError(f"Spare part #{part_id} does not exist or is inactive.")
                
            if qty < part["min_order_qty"]:
                raise BelowMinimumOrderQtyException(
                    f"'{part['name']}' requires a Minimum Order Quantity (MOQ) of {part['min_order_qty']} units (Ordered: {qty})."
                )
                
            if part["stock_quantity"] < qty:
                raise InsufficientSparePartStockException(
                    f"Insufficient inventory for '{part['name']}' (SKU: {part['sku']}). "
                    f"Available stock: {part['stock_quantity']} units, requested: {qty} units."
                )
                
            line_subtotal = round(float(part["wholesale_price"]) * qty, 2)
            raw_subtotal += line_subtotal
            
            new_stock = part["stock_quantity"] - qty
            items_to_order.append({
                "part": part,
                "quantity": qty,
                "unit_price": float(part["wholesale_price"]),
                "subtotal": line_subtotal,
                "new_stock": new_stock
            })
            
            # Check reorder threshold alert
            # User example: 250 oil filters with reorder point 50; buying 200 leaves 50 -> alert fires!
            if new_stock <= part["reorder_point"] and part["stock_quantity"] > part["reorder_point"]:
                reorder_alerts_to_trigger.append((part["name"], part["sku"], new_stock, part["reorder_point"]))
            elif new_stock == 0:
                out_of_stock_to_trigger.append((part["name"], part["sku"]))
                
        # 3. Calculate discounts and 18% GST (CGST 9% + SGST 9%)
        discount_amount = round(raw_subtotal * (discount_percent / 100.0), 2)
        taxable_amount = raw_subtotal - discount_amount
        gst_amount = round(taxable_amount * 0.18, 2)
        grand_total = round(taxable_amount + gst_amount, 2)
        
        # 4. Generate order number
        today_str = datetime.date.today().strftime("%Y%m%d")
        rand_suffix = uuid.uuid4().hex[:4].upper()
        order_number = f"SPO-{today_str}-{rand_suffix}"
        
        # 5. Insert order
        cursor.execute("""
            INSERT INTO spare_part_orders (
                order_number, retailer_id, order_status, payment_status,
                subtotal, discount_amount, gst_amount, grand_total,
                delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
                carrier_name
            ) VALUES (?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'TradeKart Express Logistics')
        """, (
            order_number, retailer_id,
            "paid" if payment_method == "online" else "pending",
            raw_subtotal, discount_amount, gst_amount, grand_total,
            delivery_info.get("address", retailer["address"]),
            delivery_info.get("city", retailer["city"]),
            delivery_info.get("state", retailer["state"]),
            delivery_info.get("postal_code", retailer["postal_code"]),
            delivery_info.get("notes", "")
        ))
        order_id = cursor.lastrowid
        
        # 6. Insert items & decrement stock
        for it in items_to_order:
            p = it["part"]
            cursor.execute("""
                INSERT INTO spare_part_order_items (
                    order_id, spare_part_id, part_name, part_sku, brand,
                    vehicle_type, category, wholesale_price, quantity, subtotal
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                order_id, p["id"], p["name"], p["sku"], p["brand"],
                p["vehicle_type"], p["category"], it["unit_price"], it["quantity"], it["subtotal"]
            ))
            
            # Decrement stock
            cursor.execute("""
                UPDATE spare_parts
                SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (it["new_stock"], p["id"]))
            
        # 7. Generate invoice
        invoice_num = f"INV-SP-{today_str}-{uuid.uuid4().hex[:4].upper()}"
        cursor.execute("""
            INSERT INTO spare_part_invoices (
                invoice_number, order_id, retailer_id, invoice_date,
                subtotal, discount_amount, gst_amount, grand_total, status
            ) VALUES (?, ?, ?, CURRENT_DATE, ?, ?, ?, ?, 'issued')
        """, (
            invoice_num, order_id, retailer_id,
            raw_subtotal, discount_amount, gst_amount, grand_total
        ))
        
    # 8. Fire Notifications outside transaction
    # A. New Order Received (Admin)
    create_portal_notification(
        recipient_type="admin",
        retailer_id=None,
        event_type="new_order",
        title="New Wholesale Spare Parts Order",
        message=f"Order #{order_number} submitted by {retailer['business_name']} ({retailer['city']}) for ₹{grand_total:,.2f}.",
        link_url=f"/spare-parts/admin/orders"
    )
    
    # B. Invoice Generated (Retailer & Admin)
    create_portal_notification(
        recipient_type="retailer",
        retailer_id=retailer_id,
        event_type="invoice_generated",
        title="Tax Invoice Generated",
        message=f"Invoice #{invoice_num} generated for Order #{order_number}. Total: ₹{grand_total:,.2f}.",
        link_url=f"/spare-parts/invoice/{invoice_num}"
    )
    
    # C. Reorder alerts (Admin)
    for part_name, sku, cur_stock, reorder_pt in reorder_alerts_to_trigger:
        create_portal_notification(
            recipient_type="admin",
            retailer_id=None,
            event_type="reorder_alert",
            title="⚠️ Automated Reorder Surveillance Alert",
            message=f"'{part_name}' (SKU: {sku}) has depleted to {cur_stock} units (Safety Reorder Point: {reorder_pt}). Place supplier replenishment PO immediately.",
            link_url=f"/spare-parts/admin/inventory"
        )
        
    # D. Out of stock alerts (Admin)
    for part_name, sku in out_of_stock_to_trigger:
        create_portal_notification(
            recipient_type="admin",
            retailer_id=None,
            event_type="out_of_stock",
            title="🚨 Stock Depleted Alert (Zero Inventory)",
            message=f"'{part_name}' (SKU: {sku}) is now completely OUT OF STOCK.",
            link_url=f"/spare-parts/admin/inventory"
        )

    return {
        "success": True,
        "order_id": order_id,
        "order_number": order_number,
        "invoice_number": invoice_num,
        "grand_total": grand_total
    }

def update_wholesale_order_status(
    order_id: int,
    new_status: str,
    tracking_number: Optional[str] = None,
    carrier_name: Optional[str] = None
) -> bool:
    """
    Updates wholesale order status and sends notifications.
    Status lifecycle: pending -> confirmed -> processing -> dispatched -> delivered -> cancelled
    """
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM spare_part_orders WHERE id = ?", (order_id,))
        order = cursor.fetchone()
        if not order:
            return False
            
        params = [new_status]
        set_clauses = ["order_status = ?", "updated_at = CURRENT_TIMESTAMP"]
        
        if tracking_number is not None:
            set_clauses.append("tracking_number = ?")
            params.append(tracking_number)
            
        if carrier_name is not None:
            set_clauses.append("carrier_name = ?")
            params.append(carrier_name)
            
        params.append(order_id)
        cursor.execute(f"UPDATE spare_part_orders SET {', '.join(set_clauses)} WHERE id = ?", params)
        
    # Notifications based on status transition
    retailer_id = order["retailer_id"]
    ord_num = order["order_number"]
    
    if new_status == "confirmed":
        create_portal_notification(
            recipient_type="retailer",
            retailer_id=retailer_id,
            event_type="order_confirmed",
            title="Wholesale Order Confirmed",
            message=f"Your wholesale order #{ord_num} has been confirmed by TradeKart and allocated in our warehouse.",
            link_url="/spare-parts/orders"
        )
    elif new_status == "dispatched":
        track_str = f" Tracking Code: {tracking_number}" if tracking_number else ""
        carrier_str = f" via {carrier_name}" if carrier_name else ""
        create_portal_notification(
            recipient_type="retailer",
            retailer_id=retailer_id,
            event_type="order_dispatched",
            title="Consignment Dispatched",
            message=f"Order #{ord_num} has been dispatched{carrier_str}.{track_str}",
            link_url="/spare-parts/orders"
        )
    elif new_status == "delivered":
        create_portal_notification(
            recipient_type="retailer",
            retailer_id=retailer_id,
            event_type="order_confirmed",
            title="Consignment Delivered",
            message=f"Order #{ord_num} has been safely delivered to your garage premises.",
            link_url="/spare-parts/orders"
        )
        
    return True

def get_admin_portal_overview() -> Dict[str, Any]:
    """
    Computes key metrics and alerts for the Admin control panel.
    """
    with get_db() as conn:
        # Total Retailers
        retailer_count = conn.execute("SELECT COUNT(*) FROM retailers").fetchone()[0]
        # Total Products
        prod_count = conn.execute("SELECT COUNT(*) FROM spare_parts WHERE is_active = 1").fetchone()[0]
        # Total Inventory Units
        total_units = conn.execute("SELECT SUM(stock_quantity) FROM spare_parts WHERE is_active = 1").fetchone()[0] or 0
        # Orders metrics
        orders_row = conn.execute("""
            SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN order_status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
                SUM(CASE WHEN order_status = 'delivered' THEN 1 ELSE 0 END) as completed_orders,
                SUM(CASE WHEN order_status != 'cancelled' THEN grand_total ELSE 0 END) as total_revenue
            FROM spare_part_orders
        """).fetchone()
        
        # Low stock count (stock <= reorder_point)
        low_stock_count = conn.execute("""
            SELECT COUNT(*) FROM spare_parts WHERE is_active = 1 AND stock_quantity <= reorder_point
        """).fetchone()[0]
        
        # Low stock products list
        low_stock_items = conn.execute("""
            SELECT id, name, sku, brand, vehicle_type, stock_quantity, reorder_point, min_order_qty, wholesale_price
            FROM spare_parts
            WHERE is_active = 1 AND stock_quantity <= reorder_point
            ORDER BY stock_quantity ASC
            LIMIT 10
        """).fetchall()
        
        # Recent orders
        recent_orders = conn.execute("""
            SELECT o.*, r.business_name, r.contact_person, r.city
            FROM spare_part_orders o
            JOIN retailers r ON r.id = o.retailer_id
            ORDER BY o.id DESC
            LIMIT 8
        """).fetchall()
        
        return {
            "total_retailers": retailer_count,
            "total_products": prod_count,
            "total_inventory_units": total_units,
            "total_orders": orders_row["total_orders"] or 0,
            "pending_orders": orders_row["pending_orders"] or 0,
            "completed_orders": orders_row["completed_orders"] or 0,
            "total_revenue": orders_row["total_revenue"] or 0.0,
            "low_stock_count": low_stock_count,
            "low_stock_items": [dict(r) for r in low_stock_items],
            "recent_orders": [dict(r) for r in recent_orders]
        }

def get_retailer_dashboard_metrics(retailer_id: int) -> Dict[str, Any]:
    """
    Computes dashboard metrics for an authenticated retailer partner.
    """
    with get_db() as conn:
        retailer = conn.execute("SELECT * FROM retailers WHERE id = ?", (retailer_id,)).fetchone()
        total_parts = conn.execute("SELECT COUNT(*) FROM spare_parts WHERE is_active = 1").fetchone()[0]
        
        orders_row = conn.execute("""
            SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN order_status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
                SUM(CASE WHEN order_status = 'delivered' THEN 1 ELSE 0 END) as completed_orders,
                SUM(CASE WHEN order_status != 'cancelled' THEN grand_total ELSE 0 END) as total_spent
            FROM spare_part_orders
            WHERE retailer_id = ?
        """, (retailer_id,)).fetchone()
        
        recent_orders = conn.execute("""
            SELECT * FROM spare_part_orders
            WHERE retailer_id = ?
            ORDER BY id DESC
            LIMIT 5
        """, (retailer_id,)).fetchall()
        
        invoices = conn.execute("""
            SELECT * FROM spare_part_invoices
            WHERE retailer_id = ?
            ORDER BY id DESC
            LIMIT 5
        """, (retailer_id,)).fetchall()
        
        return {
            "retailer": dict(retailer) if retailer else None,
            "total_products_available": total_parts,
            "total_orders": orders_row["total_orders"] or 0,
            "pending_orders": orders_row["pending_orders"] or 0,
            "completed_orders": orders_row["completed_orders"] or 0,
            "total_purchase_amount": orders_row["total_spent"] or 0.0,
            "discount_percent": retailer["discount_percent"] if retailer else 0.0,
            "recent_orders": [dict(r) for r in recent_orders],
            "recent_invoices": [dict(r) for r in invoices]
        }

def get_portal_analytics() -> Dict[str, Any]:
    """
    Calculates detailed wholesale analytics:
    - Monthly revenue and profit
    - Top selling parts
    - Highest-purchasing retailers
    - Brand-wise sales
    - 2-Wheeler vs 4-Wheeler volume and revenue split
    """
    with get_db() as conn:
        # 1. Total revenue and profit
        rev_profit = conn.execute("""
            SELECT 
                COALESCE(SUM(oi.subtotal), 0) as gross_revenue,
                COALESCE(SUM(oi.quantity * sp.cost_price), 0) as total_cost
            FROM spare_part_order_items oi
            JOIN spare_part_orders o ON o.id = oi.order_id
            JOIN spare_parts sp ON sp.id = oi.spare_part_id
            WHERE o.order_status != 'cancelled'
        """).fetchone()
        
        gross_rev = rev_profit["gross_revenue"]
        total_cost = rev_profit["total_cost"]
        gross_profit = gross_rev - total_cost
        
        # 2. Two-Wheeler vs Four-Wheeler Breakdown
        type_breakdown = conn.execute("""
            SELECT 
                oi.vehicle_type,
                COUNT(oi.id) as line_count,
                SUM(oi.quantity) as total_units,
                SUM(oi.subtotal) as total_revenue
            FROM spare_part_order_items oi
            JOIN spare_part_orders o ON o.id = oi.order_id
            WHERE o.order_status != 'cancelled'
            GROUP BY oi.vehicle_type
        """).fetchall()
        
        type_stats = {
            "four_wheeler": {"units": 0, "revenue": 0.0, "percent": 0.0},
            "two_wheeler": {"units": 0, "revenue": 0.0, "percent": 0.0}
        }
        total_type_rev = sum([r["total_revenue"] for r in type_breakdown]) or 1.0
        for r in type_breakdown:
            vt = r["vehicle_type"]
            if vt in type_stats:
                type_stats[vt]["units"] = r["total_units"]
                type_stats[vt]["revenue"] = r["total_revenue"]
                type_stats[vt]["percent"] = round((r["total_revenue"] / total_type_rev) * 100, 1)
                
        # 3. Brand-Wise Sales
        brand_sales = conn.execute("""
            SELECT 
                oi.brand,
                SUM(oi.quantity) as units_sold,
                SUM(oi.subtotal) as total_sales
            FROM spare_part_order_items oi
            JOIN spare_part_orders o ON o.id = oi.order_id
            WHERE o.order_status != 'cancelled'
            GROUP BY oi.brand
            ORDER BY total_sales DESC
            LIMIT 8
        """).fetchall()
        
        # 4. Most Purchased Parts
        top_parts = conn.execute("""
            SELECT 
                oi.part_name, oi.part_sku, oi.brand, oi.category,
                SUM(oi.quantity) as total_units,
                SUM(oi.subtotal) as total_volume
            FROM spare_part_order_items oi
            JOIN spare_part_orders o ON o.id = oi.order_id
            WHERE o.order_status != 'cancelled'
            GROUP BY oi.part_sku
            ORDER BY total_units DESC
            LIMIT 5
        """).fetchall()
        
        # 5. Highest Purchasing Retailers
        top_retailers = conn.execute("""
            SELECT 
                r.id, r.business_name, r.contact_person, r.city,
                COUNT(o.id) as orders_count,
                SUM(o.grand_total) as total_spend
            FROM retailers r
            JOIN spare_part_orders o ON o.retailer_id = r.id
            WHERE o.order_status != 'cancelled'
            GROUP BY r.id
            ORDER BY total_spend DESC
            LIMIT 5
        """).fetchall()
        
        return {
            "gross_revenue": gross_rev,
            "total_cost": total_cost,
            "gross_profit": gross_profit,
            "profit_margin_percent": round((gross_profit / gross_rev * 100), 1) if gross_rev > 0 else 0.0,
            "vehicle_type_split": type_stats,
            "brand_sales": [dict(r) for r in brand_sales],
            "top_parts": [dict(r) for r in top_parts],
            "top_retailers": [dict(r) for r in top_retailers]
        }
