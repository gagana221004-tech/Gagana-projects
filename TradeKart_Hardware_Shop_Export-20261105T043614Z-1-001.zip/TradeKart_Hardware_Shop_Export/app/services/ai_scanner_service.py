"""
AI Shopping Assistant & Hardware Part Identification Engine.
Provides catalog-grounded matching, confidence calibration, safety-critical tagging,
and diagnostic recommendations for broken or unknown replacement parts.
"""
from typing import Dict, Any, List, Optional
import re
import sqlite3
from pathlib import Path
from app.database import get_db

# Safety-critical classification keywords
SAFETY_CRITICAL_KEYWORDS = {
    "pressure": ["valve", "ball valve", "elbow", "socket", "pvc", "pipe", "plumbing", "ptfe"],
    "electrical": ["spark plug", "battery", "alternator", "wire", "voltage", "electrical tape", "cordless drill"],
    "load_bearing": ["bolt", "hex bolt", "screw", "anchor", "cement", "mortar", "hinge", "bearing", "strut", "suspension", "shock absorber", "bracket"],
    "automotive_safety": ["brake", "brake pad", "brake shoe", "helmet", "wiper", "bumper", "horn", "clutch"]
}

# Domain knowledge dictionary for hardware and automotive parts
HARDWARE_KNOWLEDGE_BASE = [
    {
        "keywords": ["valve", "ball valve", "shutoff", "brass valve", "plumbing valve", "leak", "water flow", "bsp", "npt", "pn25"],
        "part_type": "Forged Brass Ball Valve (Full Port)",
        "function": "High-pressure quarter-turn shutoff mechanism for potable water lines, plumbing risers, and drainage systems.",
        "specs_detected": "1\" (25mm) Female Thread, Lead-Free Forged Brass CW617N, PN25 Pressure Rating",
        "category": "Plumbing Supplies",
        "search_terms": ["brass ball valve", "valve", "plumbing"],
        "safety_class": "pressure",
        "safety_warning": "Pressurized Water Component: Shut off your main supply line before installation. Ensure thread type (BSP vs NPT) matches to prevent joint leakage.",
        "compatibility_caveat": "Engineered for standard BSP parallel pipe threads (common in India and Europe). Will require an adapter bushing if mating with American NPT taper threads."
    },
    {
        "keywords": ["knob", "door knob", "brass knob", "antique knob", "mortise knob", "vintage knob", "rosette"],
        "part_type": "Victorian Antique Brass Mortise Door Knob",
        "function": "Rotary interior/exterior door latch controller with aged patina finish and beaded rosette mounting plate.",
        "specs_detected": "Solid Forged Brass, 65mm Projection, 70mm Rosette, 8mm Square Spindle",
        "category": "Door Hardware",
        "search_terms": ["antique brass", "door knob", "knob"],
        "safety_class": "standard",
        "safety_warning": None,
        "compatibility_caveat": "Requires standard 8mm square spindle receiver. Suitable for door thicknesses between 35mm and 50mm."
    },
    {
        "keywords": ["mortise handle", "door handle", "chrome handle", "lock set", "lever handle", "door lock", "pull handle"],
        "part_type": "Designer Mirror Chrome Mortise Door Handle Set with Lock",
        "function": "Architectural entrance lever handle with reversible brass latch mechanism and Euro profile computer key cylinder.",
        "specs_detected": "Mirror Polish Chrome Plating, Solid Virgin Zinc Alloy Body, 60mm Backset, 200x45mm Plate",
        "category": "Chrome Hardware & Accessories",
        "search_terms": ["mortise door handle", "chrome handle", "lever handle"],
        "safety_class": "standard",
        "safety_warning": None,
        "compatibility_caveat": "Standard 60mm backset mortise lock body. Verify existing door stile cutout before ordering to avoid chisel work."
    },
    {
        "keywords": ["screw", "wood screw", "galvanized screw", "torx", "fastener", "countersunk", "yellow zinc"],
        "part_type": "Galvanized Multi-Purpose Wood Screws",
        "function": "Heavy-duty self-drilling countersunk wood fastener designed to prevent timber splitting without pre-drilling.",
        "specs_detected": "#8 x 65 mm (2.5 Inch), T-20 Torx Star Drive, Yellow Zinc Anti-Corrosion Dichromate",
        "category": "Fasteners & Fixings",
        "search_terms": ["wood screws", "galvanized screws", "fasteners"],
        "safety_class": "standard",
        "safety_warning": None,
        "compatibility_caveat": "Requires a T-20 Torx star bit for driving. Phillips or Pozidriv screwdrivers will strip the head."
    },
    {
        "keywords": ["bolt", "hex bolt", "nut", "washer", "m10", "grade 8", "high tensile", "structural bolt"],
        "part_type": "High-Tensile Grade 8.8 Hex Head Bolt & Nut Set",
        "function": "Structural alloy fastener with nylon-insert locking nut for automotive, machinery, and timber joist framing.",
        "specs_detected": "M10 x 75 mm, Grade 8.8 High-Tensile Steel, Pitch: 1.5mm Coarse Metric",
        "category": "Fasteners & Fixings",
        "search_terms": ["hex head bolt", "bolts", "nuts"],
        "safety_class": "load_bearing",
        "safety_warning": "Structural Load-Bearing Component: Verify shear and tensile grade (8.8 rating) against manufacturer specifications. Never replace with unrated mild steel bolts.",
        "compatibility_caveat": "Metric M10x1.5 standard thread. Will not thread into imperial 3/8-16 UNC threaded bores."
    },
    {
        "keywords": ["tape", "duct tape", "waterproof tape", "cloth tape", "repair tape", "adhesive tape"],
        "part_type": "Heavy-Duty All-Weather Waterproof Duct Tape",
        "function": "Reinforced triple-layer adhesive sealing tape with double-thick rubber adhesive for metal, wood, and masonry patches.",
        "specs_detected": "48 mm (2\") Width, 30 Meters, 17 mil Thickness, Temperature Range: -20°C to 80°C",
        "category": "Adhesives & Tapes",
        "search_terms": ["duct tape", "waterproof tape", "adhesive"],
        "safety_class": "standard",
        "safety_warning": None,
        "compatibility_caveat": "Designed for temporary repairs; not certified for permanent pressurized plumbing or fuel line repairs."
    },
    {
        "keywords": ["cement", "mortar", "concrete", "53 grade", "opc", "ppc", "plaster", "masonry"],
        "part_type": "Portland Cement Type I/II - 50 kg Heavy Sack",
        "function": "High-durability OPC 53 Grade hydraulic binder for RCC structural concrete, column casting, foundations, and exterior masonry.",
        "specs_detected": "50 kg Sack, IS 12269 Certified OPC 53 Grade, 28-day Compressive Strength > 53 MPa",
        "category": "Building Materials",
        "search_terms": ["portland cement", "cement", "concrete"],
        "safety_class": "load_bearing",
        "safety_warning": "Structural Construction Material: Ensure proper water-cement ratio and continuous 7-14 day water curing to attain structural load-bearing strength.",
        "compatibility_caveat": "Store on raised wooden pallets off the ground. Must be consumed within 90 days of manufacturing date."
    },
    {
        "keywords": ["hammer", "claw hammer", "nail puller", "steel hammer", "hand tool"],
        "part_type": "16-Ounce Drop-Forged Steel Claw Hammer",
        "function": "Drop-forged high-carbon steel striking tool with curved high-leverage nail puller and magnetic nail starter.",
        "specs_detected": "450g (16 oz) Head, Monobloc Solid Forged Carbon Steel, Shock-Reduction TPR Grip",
        "category": "Hand & Power Tools",
        "search_terms": ["claw hammer", "hammer", "tool"],
        "safety_class": "standard",
        "safety_warning": None,
        "compatibility_caveat": "General carpentry tool; not intended for driving cold steel chisels or masonry star drills (use a club hammer instead)."
    },
    {
        "keywords": ["drill", "cordless drill", "power drill", "driver", "20v", "lithium"],
        "part_type": "20V Max Lithium-Ion Cordless Drill Driver Kit",
        "function": "Variable 2-speed rotary drill and torque driver delivering 45 Nm of torque with 13mm keyless chuck.",
        "specs_detected": "20V Max, 2-Speed (0-450 / 0-1,500 RPM), 13mm All-Metal Ratcheting Chuck, 45 Nm Torque",
        "category": "Hand & Power Tools",
        "search_terms": ["cordless drill", "drill driver", "drill"],
        "safety_class": "standard",
        "safety_warning": None,
        "compatibility_caveat": "Uses 20V slide-on battery platform. Incompatible with 12V or 18V battery packs from different series."
    },
    {
        "keywords": ["oil filter", "spin-on", "filter canister", "engine oil", "lubrication filter"],
        "part_type": "Spin-On Engine Oil Filter",
        "function": "Full-flow synthetic pleated lubrication filter that captures carbon soot and metal particles down to 20 microns.",
        "specs_detected": "M20 x 1.5 Thread, Silicone Anti-Drainback Valve, 280 PSI Burst Strength, 99% Efficiency",
        "category": "Filters",
        "search_terms": ["oil filter", "spin-on filter"],
        "safety_class": "automotive_safety",
        "safety_warning": "Critical Engine Component: Ensure sealing gasket is lubricated with fresh oil before hand-tightening 3/4 turn. Verify engine oil capacity.",
        "compatibility_caveat": "Direct fit for Tata (Nexon, Harrier, Safari) and Hyundai (Creta, Venue, i20) 1.4L/1.5L engines. Check thread size on petrol turbo variants."
    },
    {
        "keywords": ["brake pad", "disc brake", "brake shoe", "ceramic brake", "stopping power"],
        "part_type": "Ceramic Front Brake Pad Set",
        "function": "Low-dust copper-free friction pads designed for smooth deceleration, noise damping, and high thermal fade resistance.",
        "specs_detected": "Copper-Free Ceramic Formula, 0°C - 650°C Operating Range, Shims & Caliper Hardware Included",
        "category": "Brake System",
        "search_terms": ["brake pad", "ceramic front brake"],
        "safety_class": "automotive_safety",
        "safety_warning": "Life-Safety Automotive Component: Replace in axle sets only (both left and right wheels). Perform gentle bed-in stops for the first 200 km.",
        "compatibility_caveat": "Fits front disc calipers on Toyota Innova Crysta, Fortuner, and Tata Harrier/Safari. Incompatible with rear drum brake setups."
    },
    {
        "keywords": ["spark plug", "iridium", "ignition", "electrode"],
        "part_type": "Iridium Power Spark Plug",
        "function": "0.6mm laser-welded iridium electrode spark generator providing high ignition flame propagation and 100,000 km lifespan.",
        "specs_detected": "14mm Thread, 19mm Reach, 16mm Hex, Heat Range 6, 0.6mm Iridium Tip",
        "category": "Electrical",
        "search_terms": ["spark plug", "iridium spark"],
        "safety_class": "automotive_safety",
        "safety_warning": "High-Voltage Ignition Component: Do not exceed recommended torque (20-25 Nm) during installation into aluminum cylinder heads.",
        "compatibility_caveat": "Pre-gapped to 1.1mm for Honda and Hyundai MPi/i-VTEC engines. Do not manually adjust the delicate iridium tip."
    },
    {
        "keywords": ["shock absorber", "strut", "suspension", "gas charged", "damper"],
        "part_type": "Gas-Charged Front Shock Absorber Strut",
        "function": "Nitrogen pressurized twin-tube hydraulic damper that controls suspension rebound and stabilizes tire-to-road contact.",
        "specs_detected": "Twin-Tube Gas-Charged, Hard-Chromed Piston Rod, 155mm Stroke Length",
        "category": "Suspension",
        "search_terms": ["shock absorber", "strut", "suspension"],
        "safety_class": "automotive_safety",
        "safety_warning": "Vehicle Dynamics & Stability Component: Always replace struts in pairs (front left + front right) to maintain balanced braking and cornering.",
        "compatibility_caveat": "Calibrated specifically for Maruti Suzuki Swift, Dzire, and Baleno front suspension geometry."
    },
    {
        "keywords": ["battery", "car battery", "lead acid", "65ah", "12v", "cranking"],
        "part_type": "Maintenance-Free 12V 65Ah Automotive Battery",
        "function": "Silver-calcium sealed automotive accumulator delivering high cold cranking amps (580 CCA) for modern electronics.",
        "specs_detected": "12V 65 Ah, 580 CCA, Magic-Eye Hydrometer, Left Terminal (+) Polarity",
        "category": "Electrical",
        "search_terms": ["car battery", "12v battery", "battery"],
        "safety_class": "electrical",
        "safety_warning": "High-Energy Electrical & Acid Component: Disconnect negative (-) terminal first and connect positive (+) first to prevent spark arcs.",
        "compatibility_caveat": "Left-hand positive terminal orientation (Type L). Ensure your vehicle's battery tray and cable length accommodate left polarity."
    },
    {
        "keywords": ["chain", "sprocket", "bike chain", "drive chain", "o-ring chain"],
        "part_type": "O-Ring Drive Chain & Sprocket Kit",
        "function": "Gold-plated sealed roller chain and hardened carbon steel sprockets for motorcycle final power transmission.",
        "specs_detected": "Pitch 428H - 122 Links, 14T Front / 42T Rear Sprockets, Sealed O-Ring Lubrication",
        "category": "Two-wheeler Parts",
        "search_terms": ["bike chain", "chain kit", "sprocket"],
        "safety_class": "automotive_safety",
        "safety_warning": "Motorcycle Drivetrain Component: Proper chain slack (25-30 mm) and master-link clip orientation are mandatory for rider safety.",
        "compatibility_caveat": "Tailored for Bajaj Pulsar (150/180/220) and Hero Xtreme. Check rear sprocket tooth count if you have modified your final drive ratio."
    }
]

def analyze_part_input(image_filename: Optional[str] = None, text_description: Optional[str] = None) -> Dict[str, Any]:
    """
    Multimodal analysis combining image visual heuristics/filename cues with text problem description.
    Maps to verified database catalog items with calibrated confidence and safety ratings.
    """
    combined_query = ""
    if image_filename:
        # Extract meaningful tokens from image filename (e.g. "broken_brass_ball_valve_1inch.jpg")
        clean_img_name = re.sub(r'[^a-zA-Z0-9]+', ' ', image_filename.lower())
        combined_query += f" {clean_img_name}"
    if text_description:
        combined_query += f" {text_description.lower().strip()}"

    combined_query = combined_query.strip()
    if not combined_query:
        return {
            "status": "empty_input",
            "message": "Please photograph your part or describe what you are looking to replace."
        }

    # Score each domain profile against query
    best_profile = None
    best_score = 0
    matched_keywords = []

    for profile in HARDWARE_KNOWLEDGE_BASE:
        score = 0
        current_matches = []
        for kw in profile["keywords"]:
            if kw in combined_query:
                # Weight longer multi-word phrases higher
                weight = 3 if " " in kw else 1
                score += weight
                current_matches.append(kw)
        
        if score > best_score:
            best_score = score
            best_profile = profile
            matched_keywords = current_matches

    # Confidence Calibration Rubric
    if best_score >= 5:
        confidence_level = "HIGH"
        confidence_pct = min(96, 85 + (best_score * 2))
        confidence_rationale = f"Exact match identified for part type and functional geometry based on {', '.join(matched_keywords[:3])}."
        diagnostic_prompt = None
    elif best_score >= 2:
        confidence_level = "MEDIUM"
        confidence_pct = 72
        confidence_rationale = f"Strong match for general component type ({matched_keywords[0] if matched_keywords else 'hardware'}), but critical sizing or mounting dimensions require confirmation."
        diagnostic_prompt = "To achieve 100% fit accuracy, please measure the outer diameter or photograph any stamped part numbers."
    else:
        confidence_level = "LOW"
        confidence_pct = 45
        confidence_rationale = "The photo or description provides generic features. Multiple hardware items share this shape."
        diagnostic_prompt = "Please place a ruler or coin next to the part for scale, or take a clear close-up of any manufacturer labels or thread ends."

    # If nothing matched in domain knowledge base, fallback to searching database directly using tokens
    if not best_profile:
        return search_database_fallback(combined_query)

    # Grounded Catalog Search: Fetch matching in-stock products from DB
    recommended_product, alternatives = fetch_grounded_catalog_matches(best_profile["search_terms"], best_profile["category"])

    return {
        "status": "success",
        "identified_part": {
            "name": best_profile["part_type"],
            "category": best_profile["category"],
            "likely_function": best_profile["function"],
            "visible_specifications": best_profile["specs_detected"]
        },
        "confidence": {
            "level": confidence_level,
            "percentage": confidence_pct,
            "rationale": confidence_rationale,
            "diagnostic_prompt": diagnostic_prompt
        },
        "safety_advisory": {
            "is_safety_critical": best_profile["safety_class"] != "standard",
            "hazard_type": best_profile["safety_class"],
            "warning_message": best_profile["safety_warning"]
        },
        "recommended_product": recommended_product,
        "alternatives": alternatives,
        "compatibility_caveat": best_profile["compatibility_caveat"],
        "why_recommended": (
            f"Matches your identified {best_profile['part_type']} specifications. "
            f"Fully verified in-stock in our Bengaluru central warehouse with certified quality standards."
            if recommended_product else "No exact in-stock match currently in catalog. Closest alternatives listed below."
        )
    }

def fetch_grounded_catalog_matches(search_terms: List[str], target_category: str):
    """
    Queries SQLite database as the single source of truth.
    Ensures ZERO hallucinated SKUs or out-of-stock items.
    Searches both 'products' (hardware store) and 'spare_parts' (automobile portal).
    """
    candidates = []
    
    with get_db() as conn:
        # 1. Search products table
        for term in search_terms:
            like_pat = f"%{term}%"
            rows = conn.execute("""
                SELECT p.id, p.name, p.slug, p.sku, p.price, p.stock_quantity, p.image_url,
                       p.specifications, p.description, c.name as category_name, 'hardware' as product_type
                FROM products p
                JOIN categories c ON c.id = p.category_id
                WHERE p.is_active = 1 AND p.stock_quantity > 0
                  AND (p.name LIKE ? OR p.description LIKE ? OR p.specifications LIKE ? OR c.name LIKE ?)
                ORDER BY p.stock_quantity DESC
                LIMIT 6
            """, (like_pat, like_pat, like_pat, like_pat)).fetchall()
            
            for r in rows:
                item = dict(r)
                if not any(c["id"] == item["id"] and c["product_type"] == item["product_type"] for c in candidates):
                    candidates.append(item)

        # 2. Search spare_parts table
        for term in search_terms:
            like_pat = f"%{term}%"
            sp_rows = conn.execute("""
                SELECT sp.id, sp.name, sp.slug, sp.sku, sp.wholesale_price as price, sp.stock_quantity, sp.image_url,
                       sp.specifications, sp.description, sp.category as category_name, 'automotive' as product_type,
                       sp.brand, sp.compatible_models
                FROM spare_parts sp
                WHERE sp.is_active = 1 AND sp.stock_quantity > 0
                  AND (sp.name LIKE ? OR sp.description LIKE ? OR sp.compatible_models LIKE ? OR sp.category LIKE ?)
                ORDER BY sp.stock_quantity DESC
                LIMIT 6
            """, (like_pat, like_pat, like_pat, like_pat)).fetchall()
            
            for r in sp_rows:
                item = dict(r)
                if not any(c["id"] == item["id"] and c["product_type"] == item["product_type"] for c in candidates):
                    candidates.append(item)

    if not candidates:
        return None, []

    # Rank: Top match is item with highest relevance / stock depth
    primary_match = candidates[0]
    alternatives = candidates[1:3]

    # Format output contracts
    def format_item(it):
        product_url = f"/product/{it['slug']}" if it["product_type"] == "hardware" else f"/spare-parts"
        return {
            "id": it["id"],
            "name": it["name"],
            "sku": it["sku"],
            "price": round(it["price"], 2),
            "stock_quantity": it["stock_quantity"],
            "image_url": it["image_url"],
            "category": it["category_name"],
            "product_url": product_url,
            "product_type": it["product_type"],
            "summary_specs": it.get("specifications", "").split("\n")[0] if it.get("specifications") else "Standard OEM Fit"
        }

    return format_item(primary_match), [format_item(a) for a in alternatives]

def search_database_fallback(query_str: str) -> Dict[str, Any]:
    """Fallback when query doesn't trigger specific domain rules."""
    terms = [t for t in query_str.split() if len(t) > 2]
    if not terms:
        terms = [query_str]

    primary, alts = fetch_grounded_catalog_matches(terms[:3], "General")

    if not primary:
        return {
            "status": "not_found",
            "confidence": {
                "level": "LOW",
                "percentage": 25,
                "rationale": "No direct matches found in our current catalog for this specific part.",
                "diagnostic_prompt": "Please double-check the part number or photograph the whole assembly. You can also reach our Bengaluru technical desk at +91 80 2839 4567."
            },
            "identified_part": {
                "name": "Unidentified Hardware Component",
                "category": "Unclassified",
                "likely_function": "Mechanical or structural mounting component",
                "visible_specifications": "Standard dimensions"
            },
            "safety_advisory": {
                "is_safety_critical": True,
                "hazard_type": "unknown",
                "warning_message": "Always confirm load capacity and electrical/pressure specifications before replacing unverified hardware components."
            },
            "recommended_product": None,
            "alternatives": [],
            "compatibility_caveat": "Please verify mounting points before installation.",
            "why_recommended": None
        }

    return {
        "status": "success",
        "confidence": {
            "level": "MEDIUM",
            "percentage": 68,
            "rationale": "Found closely matched components based on your descriptive terms.",
            "diagnostic_prompt": "Verify the diameter or thread pitch before ordering."
        },
        "identified_part": {
            "name": primary["name"],
            "category": primary["category"],
            "likely_function": "Replacement hardware part matching query terms",
            "visible_specifications": primary["summary_specs"]
        },
        "safety_advisory": {
            "is_safety_critical": any(kw in primary["name"].lower() for kw in ["valve", "bolt", "brake", "battery", "plug"]),
            "hazard_type": "hardware_fitment",
            "warning_message": "Verify model and physical specifications with the manufacturer service manual."
        },
        "recommended_product": primary,
        "alternatives": alts,
        "compatibility_caveat": "Review dimensional specs to confirm clearance.",
        "why_recommended": "Best available match currently in stock in our Bengaluru warehouse."
    }
