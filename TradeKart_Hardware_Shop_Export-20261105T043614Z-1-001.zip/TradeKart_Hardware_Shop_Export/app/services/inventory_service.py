import sqlite3
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Tuple
from app.database import get_db, get_connection
from app.config import settings

class InsufficientStockException(Exception):
    def __init__(self, message: str, product_id: int, available_stock: int, requested: int):
        super().__init__(message)
        self.message = message
        self.product_id = product_id
        self.available_stock = available_stock
        self.requested = requested

def get_items_needing_restock() -> List[Dict[str, Any]]:
    """Returns items where stock is less than or equal to their reorder_point threshold."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT p.*, c.name as category_name,
                   (p.reorder_point - p.stock_quantity) as units_under_threshold
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.is_active = 1 AND p.stock_quantity <= p.reorder_point
            ORDER BY p.stock_quantity ASC, p.name ASC
        """).fetchall()
        return [dict(r) for r in rows]

def get_critical_low_stock_items(threshold: int = 3) -> List[Dict[str, Any]]:
    """Returns items critically close to depletion (stock <= threshold)."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT p.*, c.name as category_name
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.is_active = 1 AND p.stock_quantity <= ?
            ORDER BY p.stock_quantity ASC, p.name ASC
        """, (threshold,)).fetchall()
        return [dict(r) for r in rows]

def restock_product(product_id: int, additional_stock: int, reason: str = "Manual restock", reference_id: str = "") -> Dict[str, Any]:
    """Increments stock and records an audit log entry."""
    with get_db() as conn:
        # Check existing product
        prod = conn.execute("SELECT id, name, stock_quantity FROM products WHERE id = ?", (product_id,)).fetchone()
        if not prod:
            raise ValueError("Product not found")
            
        prev_stock = prod["stock_quantity"]
        new_stock = prev_stock + additional_stock
        
        conn.execute(
            "UPDATE products SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (new_stock, product_id)
        )
        
        conn.execute("""
            INSERT INTO stock_logs (product_id, change_amount, previous_stock, new_stock, reason, reference_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (product_id, additional_stock, prev_stock, new_stock, reason, reference_id or f"restock_{int(datetime.now(timezone.utc).timestamp())}"))
        
        return {
            "product_id": product_id,
            "product_name": prod["name"],
            "previous_stock": prev_stock,
            "new_stock": new_stock,
            "added": additional_stock
        }

def process_order_checkout_atomic(
    customer_info: Dict[str, Any],
    cart_items: List[Dict[str, Any]], # [{"product_id": int, "quantity": int}]
    delivery_info: Dict[str, Any],
    payment_result: Dict[str, Any],
    user_id: int = None
) -> Dict[str, Any]:
    """
    Executes stock check, stock decrement, order creation and item insertion
    in a SINGLE atomic database transaction with BEGIN IMMEDIATE to guarantee zero overselling.
    """
    if not cart_items:
        raise ValueError("Shopping cart is empty.")

    conn = get_connection()
    try:
        # Acquire immediate lock to prevent race conditions across concurrent checkouts
        conn.execute("BEGIN IMMEDIATE")
        
        total_subtotal = 0.0
        validated_items = []
        
        # 1. Validate all stock atomically first
        for item in cart_items:
            pid = int(item["product_id"])
            qty = int(item["quantity"])
            if qty <= 0:
                continue
                
            row = conn.execute(
                "SELECT id, name, sku, price, stock_quantity, is_active FROM products WHERE id = ?",
                (pid,)
            ).fetchone()
            
            if not row:
                raise ValueError(f"Product ID {pid} was not found in catalog.")
            if not row["is_active"]:
                raise ValueError(f"Product '{row['name']}' is no longer active.")
            if row["stock_quantity"] < qty:
                raise InsufficientStockException(
                    message=f"Insufficient stock for '{row['name']}'. Requested {qty}, but only {row['stock_quantity']} are available.",
                    product_id=pid,
                    available_stock=row["stock_quantity"],
                    requested=qty
                )
                
            line_subtotal = round(row["price"] * qty, 2)
            total_subtotal += line_subtotal
            
            validated_items.append({
                "product_id": row["id"],
                "product_name": row["name"],
                "product_sku": row["sku"],
                "unit_price": row["price"],
                "quantity": qty,
                "subtotal": line_subtotal,
                "current_stock": row["stock_quantity"]
            })
            
        if not validated_items:
            raise ValueError("No valid items in cart to checkout.")

        # 2. Compute taxes and totals
        subtotal = round(total_subtotal, 2)
        delivery_method = delivery_info.get("delivery_method", "delivery")
        
        # Compute delivery fee
        if delivery_method == "pickup":
            delivery_fee = 0.0
        elif subtotal >= settings.FREE_DELIVERY_THRESHOLD:
            delivery_fee = 0.0
        else:
            delivery_fee = round(settings.DELIVERY_FLAT_FEE, 2)
            
        tax_amount = round((subtotal + delivery_fee) * settings.TAX_RATE, 2)
        grand_total = round(subtotal + delivery_fee + tax_amount, 2)

        # 3. Generate unique order number
        order_number = f"ORD-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"

        # 4. Insert Order Record
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO orders (
                order_number, user_id, customer_name, customer_email, customer_phone,
                delivery_method, delivery_address, delivery_city, delivery_state, delivery_postal, delivery_notes,
                subtotal, delivery_fee, tax_amount, total_amount,
                payment_status, payment_provider, payment_transaction_id,
                order_status, tracking_number, carrier_name
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            order_number,
            user_id,
            customer_info["customer_name"],
            customer_info["customer_email"],
            customer_info["customer_phone"],
            delivery_method,
            delivery_info.get("delivery_address", ""),
            delivery_info.get("delivery_city", ""),
            delivery_info.get("delivery_state", ""),
            delivery_info.get("delivery_postal", ""),
            delivery_info.get("delivery_notes", ""),
            subtotal,
            delivery_fee,
            tax_amount,
            grand_total,
            payment_result.get("payment_status", "paid"),
            payment_result.get("provider", "mock"),
            payment_result.get("transaction_id", ""),
            "processing",
            delivery_info.get("tracking_number", ""),
            delivery_info.get("carrier_name", "In-Store Pickup" if delivery_method == "pickup" else "Local Express")
        ))
        order_id = cursor.lastrowid

        # 5. Insert Order Items and Decrement Stock
        for v in validated_items:
            # Insert item
            cursor.execute("""
                INSERT INTO order_items (
                    order_id, product_id, product_name, product_sku, unit_price, quantity, subtotal
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                order_id,
                v["product_id"],
                v["product_name"],
                v["product_sku"],
                v["unit_price"],
                v["quantity"],
                v["subtotal"]
            ))
            
            # Decrement stock
            new_stock = v["current_stock"] - v["quantity"]
            cursor.execute(
                "UPDATE products SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (new_stock, v["product_id"])
            )
            
            # Log audit
            cursor.execute("""
                INSERT INTO stock_logs (
                    product_id, change_amount, previous_stock, new_stock, reason, reference_id
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                v["product_id"],
                -v["quantity"],
                v["current_stock"],
                new_stock,
                "customer_order",
                order_number
            ))

        # Commit everything atomically
        conn.commit()
        
        return {
            "order_id": order_id,
            "order_number": order_number,
            "subtotal": subtotal,
            "delivery_fee": delivery_fee,
            "tax_amount": tax_amount,
            "total_amount": grand_total,
            "items_count": len(validated_items)
        }
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
