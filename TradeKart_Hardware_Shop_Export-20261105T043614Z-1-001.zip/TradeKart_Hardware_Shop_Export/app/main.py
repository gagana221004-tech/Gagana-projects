from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from contextlib import asynccontextmanager

from app.config import settings
from app.database import init_db
from app.routes import storefront, auth, checkout, account, admin, spare_parts, ai_assistant

BASE_DIR = Path(__file__).resolve().parent

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize SQLite database and tables on startup
    init_db()
    yield

app = FastAPI(
    title=settings.SHOP_NAME,
    description="Production-ready Hardware Shop e-commerce system with Storefront and Shopkeeper Admin.",
    version="1.0.0",
    lifespan=lifespan
)

# Mount static assets
static_path = BASE_DIR / "static"
if static_path.exists():
    app.mount("/static", StaticFiles(directory=str(static_path)), name="static")

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# Register route modules
app.include_router(storefront.router)
app.include_router(auth.router)
app.include_router(checkout.router)
app.include_router(account.router)
app.include_router(admin.router)
app.include_router(spare_parts.router)
app.include_router(ai_assistant.router)

# Global 404 Handler
@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "request": request,
            "shop_name": settings.SHOP_NAME,
            "all_categories": [],
            "products": [],
            "search_query": None,
            "selected_category": None,
            "current_user": None,
            "error_banner": "The requested hardware page was not found."
        },
        status_code=404
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT, reload=settings.DEBUG)
