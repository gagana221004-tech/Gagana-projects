from fastapi import APIRouter, Request, HTTPException, status
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Dict, Any
from app.config import settings
from app.database import get_db
from app.auth import get_current_user
from app.services.payment_service import get_payment_adapter
from app.services.delivery_service import get_delivery_adapter
from app.services.inventory_service import process_order_checkout_atomic, InsufficientStockException

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))

def get_base_ctx(request: Request):
    return {
        "request": request,
        "shop_name": settings.SHOP_NAME,
        "shop_email": settings.SHOP_EMAIL,
        "shop_phone": settings.SHOP_PHONE,
        "shop_address": settings.SHOP_ADDRESS,
        "shop_gstin": settings.GSTIN,
        "currency_symbol": settings.CURRENCY_SYMBOL,
        "tax_rate": settings.TAX_RATE,
        "delivery_flat_fee": settings.DELIVERY_FLAT_FEE,
        "free_delivery_threshold": settings.FREE_DELIVERY_THRESHOLD,
        "current_user": get_current_user(request),
        "payment_provider": settings.PAYMENT_PROVIDER
    }

@router.get("/checkout", response_class=HTMLResponse)
async def checkout_page(request: Request):
    ctx = get_base_ctx(request)
    return templates.TemplateResponse(request=request, name="checkout.html", context=ctx)

@router.post("/api/checkout")
async def checkout_api_submit(request: Request):
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload.")

    customer_name = (data.get("customer_name") or "").strip()
    customer_email = (data.get("customer_email") or "").strip().lower()
    customer_phone = (data.get("customer_phone") or "").strip()
    delivery_method = data.get("delivery_method", "delivery")
    cart_items = data.get("cart_items", [])

    # Input validations
    if not customer_name:
        return JSONResponse(status_code=400, content={"success": False, "message": "Customer name is required."})
    if not customer_email or "@" not in customer_email:
        return JSONResponse(status_code=400, content={"success": False, "message": "Valid email address is required."})
    if not customer_phone:
        return JSONResponse(status_code=400, content={"success": False, "message": "Phone number is required."})
    if not cart_items or not isinstance(cart_items, list):
        return JSONResponse(status_code=400, content={"success": False, "message": "Your shopping cart is empty."})

    if delivery_method not in ("delivery", "pickup"):
        delivery_method = "delivery"

    delivery_address = (data.get("delivery_address") or "").strip()
    delivery_city = (data.get("delivery_city") or "").strip()
    delivery_state = (data.get("delivery_state") or "").strip()
    delivery_postal = (data.get("delivery_postal") or "").strip()
    delivery_notes = (data.get("delivery_notes") or "").strip()

    if delivery_method == "delivery" and (not delivery_address or not delivery_city or not delivery_postal):
        return JSONResponse(status_code=400, content={"success": False, "message": "Full delivery address (street, city, zip) is required for Home Delivery."})

    # Optional authenticated user
    current_user = get_current_user(request)
    user_id = current_user["id"] if current_user else None

    # Step 1: Pre-calculate estimated subtotal from database to determine delivery fee
    subtotal_est = 0.0
    with get_db() as conn:
        for item in cart_items:
            pid = int(item.get("product_id", 0))
            qty = int(item.get("quantity", 0))
            if qty <= 0:
                continue
            row = conn.execute("SELECT price, stock_quantity, name FROM products WHERE id = ?", (pid,)).fetchone()
            if not row:
                return JSONResponse(status_code=400, content={"success": False, "message": f"Hardware item ID {pid} was not found."})
            if row["stock_quantity"] < qty:
                return JSONResponse(status_code=400, content={
                    "success": False,
                    "message": f"Insufficient stock for '{row['name']}'. Only {row['stock_quantity']} left (requested {qty})."
                })
            subtotal_est += row["price"] * qty

    # Step 2: Delivery Service Integration
    delivery_adapter = get_delivery_adapter()
    delivery_fee = delivery_adapter.calculate_delivery_fee(subtotal_est, delivery_method)
    
    order_data_preview = {
        "order_number": "PREVIEW",
        "customer_name": customer_name,
        "customer_phone": customer_phone,
        "delivery_address": delivery_address,
        "delivery_city": delivery_city,
        "delivery_postal": delivery_postal,
        "delivery_notes": delivery_notes,
        "items": cart_items
    }
    dispatch_result = delivery_adapter.dispatch_order(order_data_preview)

    delivery_info = {
        "delivery_method": delivery_method,
        "delivery_address": delivery_address,
        "delivery_city": delivery_city,
        "delivery_state": delivery_state,
        "delivery_postal": delivery_postal,
        "delivery_notes": delivery_notes,
        "delivery_fee": delivery_fee,
        "tracking_number": dispatch_result.tracking_number if delivery_method == "delivery" else "",
        "carrier_name": dispatch_result.carrier_name if delivery_method == "delivery" else "In-Store Pickup"
    }

    # Step 3: Compute grand total for payment processing
    tax_amount = round((subtotal_est + delivery_fee) * settings.TAX_RATE, 2)
    grand_total = round(subtotal_est + delivery_fee + tax_amount, 2)

    # Step 4: Payment Provider Integration
    payment_adapter = get_payment_adapter()
    payment_details = {
        "card_number": data.get("card_number", ""),
        "card_expiry": data.get("card_expiry", ""),
        "card_cvc": data.get("card_cvc", ""),
        "stripe_payment_method_id": data.get("stripe_payment_method_id", "pm_card_visa")
    }
    payment_result = payment_adapter.process_payment(
        amount=grand_total,
        currency=settings.CURRENCY_CODE,
        payment_details=payment_details,
        metadata={"customer_email": customer_email, "customer_name": customer_name}
    )

    if not payment_result.success:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "message": f"Payment Failed: {payment_result.message}"
            }
        )

    # Step 5: Atomic Database Transaction (checks and decrements stock atomically)
    customer_info = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "customer_phone": customer_phone
    }

    payment_record = {
        "payment_status": "paid",
        "provider": payment_result.provider,
        "transaction_id": payment_result.transaction_id
    }

    try:
        checkout_res = process_order_checkout_atomic(
            customer_info=customer_info,
            cart_items=cart_items,
            delivery_info=delivery_info,
            payment_result=payment_record,
            user_id=user_id
        )

        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "order_number": checkout_res["order_number"],
                "order_id": checkout_res["order_id"],
                "total_amount": checkout_res["total_amount"],
                "message": "Order placed successfully!"
            }
        )
    except InsufficientStockException as ise:
        return JSONResponse(
            status_code=400,
            content={"success": False, "message": ise.message}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"success": False, "message": f"Order processing error: {str(e)}"}
        )

@router.get("/order-success/{order_number}", response_class=HTMLResponse)
async def order_success_page(request: Request, order_number: str):
    ctx = get_base_ctx(request)
    with get_db() as conn:
        order = conn.execute("SELECT * FROM orders WHERE order_number = ?", (order_number,)).fetchone()
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        items = conn.execute("SELECT * FROM order_items WHERE order_id = ?", (order["id"],)).fetchall()

    ctx["order"] = dict(order)
    ctx["items"] = [dict(it) for it in items]
    return templates.TemplateResponse(request=request, name="order_success.html", context=ctx)
