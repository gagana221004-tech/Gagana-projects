from fastapi import APIRouter, Request, Form, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Optional
from app.config import settings
from app.database import get_db
from app.auth import (
    hash_password, verify_password, create_session_token,
    COOKIE_NAME, SESSION_DURATION_SECONDS, get_current_user
)

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))

def get_base_ctx(request: Request):
    return {
        "request": request,
        "shop_name": settings.SHOP_NAME,
        "shop_email": settings.SHOP_EMAIL,
        "shop_phone": settings.SHOP_PHONE,
        "shop_address": settings.SHOP_ADDRESS,
        "current_user": get_current_user(request)
    }

# ----------------- Customer Authentication -----------------

@router.get("/login", response_class=HTMLResponse)
async def customer_login_page(request: Request, next: Optional[str] = None, error: Optional[str] = None):
    user = get_current_user(request)
    if user:
        return RedirectResponse(url=next or "/", status_code=303)
        
    ctx = get_base_ctx(request)
    ctx.update({
        "next_url": next,
        "error": error,
        "sample_email": "customer@example.com"
    })
    return templates.TemplateResponse(request=request, name="login.html", context=ctx)

@router.post("/login")
async def customer_login_submit(
    request: Request,
    response: Response,
    email: str = Form(...),
    password: str = Form(...),
    next: Optional[str] = Form(None)
):
    email_clean = email.strip().lower()
    
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email_clean,)).fetchone()
        
    if not user or not verify_password(password, user["salt"], user["password_hash"]):
        ctx = get_base_ctx(request)
        ctx.update({
            "error": "Invalid email or password. Please try again.",
            "sample_email": email_clean,
            "next_url": next
        })
        return templates.TemplateResponse(request=request, name="login.html", context=ctx, status_code=400)

    token = create_session_token(user["id"], user["role"], user["email"])
    
    redirect_target = next if next and next.startswith("/") else ("/" if user["role"] == "customer" else "/admin/dashboard")
    resp = RedirectResponse(url=redirect_target, status_code=303)
    resp.set_cookie(
        key=COOKIE_NAME,
        value=token,
        max_age=SESSION_DURATION_SECONDS,
        httponly=True,
        samesite="lax"
    )
    return resp

@router.get("/register", response_class=HTMLResponse)
async def customer_register_page(request: Request):
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse(request=request, name="register.html", context=get_base_ctx(request))

@router.post("/register")
async def customer_register_submit(
    request: Request,
    full_name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    phone: str = Form(""),
    address: str = Form(""),
    city: str = Form(""),
    postal_code: str = Form("")
):
    ctx = get_base_ctx(request)
    form_data = {
        "full_name": full_name,
        "email": email,
        "phone": phone,
        "address": address,
        "city": city,
        "postal_code": postal_code
    }
    ctx["form_data"] = form_data

    # Validation
    if len(password) < 6:
        ctx["error"] = "Password must be at least 6 characters."
        return templates.TemplateResponse(request=request, name="register.html", context=ctx, status_code=400)
        
    if password != confirm_password:
        ctx["error"] = "Passwords do not match."
        return templates.TemplateResponse(request=request, name="register.html", context=ctx, status_code=400)

    email_clean = email.strip().lower()
    
    try:
        with get_db() as conn:
            existing = conn.execute("SELECT id FROM users WHERE email = ?", (email_clean,)).fetchone()
            if existing:
                ctx["error"] = "An account with this email address already exists. Please sign in."
                return templates.TemplateResponse(request=request, name="register.html", context=ctx, status_code=400)

            pwd_hash, salt = hash_password(password)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO users (email, password_hash, salt, full_name, phone, address, city, postal_code, role)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'customer')
            """, (email_clean, pwd_hash, salt, full_name.strip(), phone.strip(), address.strip(), city.strip(), postal_code.strip()))
            user_id = cursor.lastrowid

        token = create_session_token(user_id, "customer", email_clean)
        resp = RedirectResponse(url="/", status_code=303)
        resp.set_cookie(
            key=COOKIE_NAME,
            value=token,
            max_age=SESSION_DURATION_SECONDS,
            httponly=True,
            samesite="lax"
        )
        return resp
    except Exception as e:
        ctx["error"] = f"Registration error: {str(e)}"
        return templates.TemplateResponse(request=request, name="register.html", context=ctx, status_code=500)

# ----------------- Admin / Shopkeeper Authentication -----------------

@router.get("/admin/login", response_class=HTMLResponse)
async def admin_login_page(request: Request, error: Optional[str] = None):
    user = get_current_user(request)
    if user and user.get("role") == "admin":
        return RedirectResponse(url="/admin/dashboard", status_code=303)
        
    ctx = get_base_ctx(request)
    ctx.update({
        "error": error,
        "sample_admin_email": "admin@hardwareshop.com"
    })
    return templates.TemplateResponse(request=request, name="admin/login.html", context=ctx)

@router.post("/admin/login")
async def admin_login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...)
):
    email_clean = email.strip().lower()
    
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email_clean,)).fetchone()

    if not user or user["role"] != "admin" or not verify_password(password, user["salt"], user["password_hash"]):
        ctx = get_base_ctx(request)
        ctx.update({
            "error": "Invalid admin credentials or unauthorized account.",
            "sample_admin_email": email_clean
        })
        return templates.TemplateResponse(request=request, name="admin/login.html", context=ctx, status_code=401)

    token = create_session_token(user["id"], "admin", user["email"])
    resp = RedirectResponse(url="/admin/dashboard", status_code=303)
    resp.set_cookie(
        key=COOKIE_NAME,
        value=token,
        max_age=SESSION_DURATION_SECONDS,
        httponly=True,
        samesite="lax"
    )
    return resp

# ----------------- Sign Out -----------------

@router.get("/logout")
async def logout():
    resp = RedirectResponse(url="/", status_code=303)
    resp.delete_cookie(key=COOKIE_NAME)
    return resp
