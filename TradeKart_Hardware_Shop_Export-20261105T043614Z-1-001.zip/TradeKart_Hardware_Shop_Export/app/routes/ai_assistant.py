"""
FastAPI Router for TradeKart AI Part Scanner & Replacement Assistant.
Enables camera scanning, photo upload, and natural language diagnosis
with catalog-grounded matching and safety guardrails.
"""
from fastapi import APIRouter, Request, Form, File, UploadFile, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Optional
import re
import time

from app.config import settings
from app.auth import get_current_user
from app.services.ai_scanner_service import analyze_part_input

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

router = APIRouter(prefix="", tags=["AI Shopping Assistant"])

def get_base_context(request: Request):
    user = get_current_user(request)
    return {
        "request": request,
        "shop_name": settings.SHOP_NAME,
        "shop_email": settings.SHOP_EMAIL,
        "shop_phone": settings.SHOP_PHONE,
        "shop_address": settings.SHOP_ADDRESS,
        "currency_symbol": settings.CURRENCY_SYMBOL,
        "current_user": user,
    }

@router.get("/ai-assistant", response_class=HTMLResponse)
async def ai_assistant_page(request: Request):
    """Renders the AI Shopping Assistant & Camera Scanner Suite."""
    ctx = get_base_context(request)
    ctx.update({
        "page_title": "AI Hardware Part Scanner & Identification - TradeKart",
        "active_tab": "ai_assistant"
    })
    return templates.TemplateResponse(request=request, name="ai_assistant.html", context=ctx)

@router.post("/api/ai-assistant/identify")
async def api_identify_part(
    image_file: Optional[UploadFile] = File(None),
    text_query: Optional[str] = Form(None)
):
    """
    Identifies a hardware or automotive part from a camera photo snapshot or text description.
    Returns catalog-grounded recommendations with confidence scoring and safety advisories.
    """
    saved_filename = None
    if image_file and image_file.filename:
        # Save snapshot into static temp folder for visual reference
        upload_dir = BASE_DIR / "static" / "images" / "scans"
        upload_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r'[^a-zA-Z0-9_.-]', '_', image_file.filename.lower())
        timestamped_name = f"scan_{int(time.time())}_{safe_name}"
        target_path = upload_dir / timestamped_name
        
        content = await image_file.read()
        with open(target_path, "wb") as f:
            f.write(content)
        saved_filename = timestamped_name

    # Perform multimodal analysis
    analysis_result = analyze_part_input(
        image_filename=saved_filename or (image_file.filename if image_file else None),
        text_description=text_query
    )

    if saved_filename:
        analysis_result["captured_image_url"] = f"/static/images/scans/{saved_filename}"

    return JSONResponse(content=analysis_result)
