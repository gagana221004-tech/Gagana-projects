from fastapi import APIRouter, Request, HTTPException, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Optional
from app.config import settings
from app.database import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))

CATEGORY_METADATA = {
    "chrome-hardware-accessories": {
        "emoji": "✨",
        "image": "/static/images/products/designer_mortise_handle.png",
        "tagline": "Pulls, Hinges & Chrome Fittings"
    },
    "door-hardware": {
        "emoji": "🚪",
        "image": "/static/images/products/antique_brass_knob.svg",
        "tagline": "Knobs, Pulls & Latches"
    },
    "fasteners-fixings": {
        "emoji": "🔩",
        "image": "/static/images/products/wood_screws_pack.svg",
        "tagline": "Screws, Bolts & Anchors"
    },
    "plumbing-supplies": {
        "emoji": "🚰",
        "image": "/static/images/products/brass_ball_valve.svg",
        "tagline": "Valves, Pipes & Sealants"
    },
    "adhesives-tapes": {
        "emoji": "🩹",
        "image": "/static/images/products/heavy_duty_duct_tape.svg",
        "tagline": "Duct, Vinyl & Sealants"
    },
    "building-materials": {
        "emoji": "🧱",
        "image": "/static/images/products/portland_cement_sack.svg",
        "tagline": "Portland Cement & Mortar"
    },
    "paints-finishes": {
        "emoji": "🎨",
        "image": "/static/images/products/interior_eggshell_paint.svg",
        "tagline": "Interior & Exterior Paints"
    },
    "paint-brushes-rollers": {
        "emoji": "🖌️",
        "image": "/static/images/products/angled_paint_brush.svg",
        "tagline": "Sash Brushes & Rollers"
    },
    "hand-power-tools": {
        "emoji": "🛠️",
        "image": "/static/images/products/cordless_power_drill.svg",
        "tagline": "Drills, Hammers & Tapes"
    }
}

def get_common_context(request: Request):
    user = get_current_user(request)
    with get_db() as conn:
        cats = conn.execute("""
            SELECT c.id, c.name, c.slug, c.description, c.icon,
                   COUNT(p.id) as item_count
            FROM categories c
            LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1
            GROUP BY c.id
            ORDER BY c.id ASC
        """).fetchall()

    enhanced_cats = []
    for c in cats:
        cat_dict = dict(c)
        meta = CATEGORY_METADATA.get(cat_dict["slug"], {
            "emoji": "📦",
            "image": "/static/images/products/antique_brass_knob.svg",
            "tagline": cat_dict.get("description", "")
        })
        cat_dict["emoji"] = meta["emoji"]
        cat_dict["image"] = meta["image"]
        cat_dict["tagline"] = meta["tagline"]
        enhanced_cats.append(cat_dict)

    return {
        "request": request,
        "shop_name": settings.SHOP_NAME,
        "shop_email": settings.SHOP_EMAIL,
        "shop_phone": settings.SHOP_PHONE,
        "shop_address": settings.SHOP_ADDRESS,
        "shop_gstin": settings.GSTIN,
        "currency_symbol": settings.CURRENCY_SYMBOL,
        "tax_rate": settings.TAX_RATE,
        "delivery_flat_fee": settings.DELIVERY_FLAT_FEE,
        "free_delivery_threshold": settings.FREE_DELIVERY_THRESHOLD,
        "current_user": user,
        "all_categories": enhanced_cats
    }

@router.get("/", response_class=HTMLResponse)
async def storefront_home(
    request: Request,
    q: Optional[str] = None,
    category: Optional[str] = None,
    sort: Optional[str] = "default",
    in_stock: Optional[str] = None
):
    ctx = get_common_context(request)
    
    query = """
        SELECT p.*, c.name as category_name, c.slug as category_slug
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1
    """
    params = []

    if category:
        query += " AND c.slug = ?"
        params.append(category)

    if q and q.strip():
        search_term = f"%{q.strip()}%"
        query += " AND (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ? OR p.specifications LIKE ?)"
        params.extend([search_term, search_term, search_term, search_term])

    if in_stock == "1":
        query += " AND p.stock_quantity > 0"

    # Sorting
    if sort == "price_asc":
        query += " ORDER BY p.price ASC"
    elif sort == "price_desc":
        query += " ORDER BY p.price DESC"
    elif sort == "name_asc":
        query += " ORDER BY p.name ASC"
    elif sort == "stock_desc":
        query += " ORDER BY p.stock_quantity DESC"
    else:
        query += " ORDER BY p.created_at DESC"

    with get_db() as conn:
        products_rows = conn.execute(query, params).fetchall()
        
        current_cat_obj = None
        if category:
            cat_row = conn.execute("SELECT * FROM categories WHERE slug = ?", (category,)).fetchone()
            if cat_row:
                current_cat_obj = dict(cat_row)

    ctx.update({
        "products": [dict(p) for p in products_rows],
        "search_query": q,
        "selected_category": category,
        "current_category_obj": current_cat_obj,
        "current_sort": sort,
        "in_stock_only": in_stock == "1"
    })
    return templates.TemplateResponse(request=request, name="index.html", context=ctx)

@router.get("/product/{slug}", response_class=HTMLResponse)
async def product_detail(request: Request, slug: str):
    ctx = get_common_context(request)
    with get_db() as conn:
        row = conn.execute("""
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.slug = ? AND p.is_active = 1
        """, (slug,)).fetchone()
        
        if not row:
            raise HTTPException(status_code=404, detail="Product not found")

    ctx["product"] = dict(row)
    return templates.TemplateResponse(request=request, name="product_detail.html", context=ctx)

@router.get("/cart", response_class=HTMLResponse)
async def view_cart(request: Request):
    ctx = get_common_context(request)
    return templates.TemplateResponse(request=request, name="cart.html", context=ctx)

@router.get("/invoice/{order_number}", response_class=HTMLResponse)
async def view_invoice(request: Request, order_number: str):
    ctx = get_common_context(request)
    with get_db() as conn:
        order_row = conn.execute("SELECT * FROM orders WHERE order_number = ?", (order_number,)).fetchone()
        if not order_row:
            raise HTTPException(status_code=404, detail="Invoice / Order not found")
            
        items_rows = conn.execute("SELECT * FROM order_items WHERE order_id = ?", (order_row["id"],)).fetchall()

    ctx["order"] = dict(order_row)
    ctx["items"] = [dict(it) for it in items_rows]
    return templates.TemplateResponse(request=request, name="invoice.html", context=ctx)
