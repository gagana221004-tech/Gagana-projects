"""
Routes for Spare Parts Dealer Portal (Automobile Wholesale & Retail).
Includes Retailer Marketplace, Cart, Dashboard, Invoices, and Admin Control Panel.
"""
from fastapi import APIRouter, Request, Form, HTTPException, status, Depends, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Optional, List, Dict, Any
import json
import re
import time

from app.database import get_db
from app.auth import (
    get_current_user,
    hash_password,
    verify_password,
    create_session_token,
    COOKIE_NAME
)
from app.services.spare_parts_service import (
    get_spare_parts_filtered,
    get_spare_part_by_id,
    get_retailer_by_user_id,
    get_retailer_by_id,
    process_wholesale_order_atomic,
    update_wholesale_order_status,
    get_admin_portal_overview,
    get_retailer_dashboard_metrics,
    get_portal_analytics,
    create_portal_notification,
    InsufficientSparePartStockException,
    RetailerNotApprovedException,
    BelowMinimumOrderQtyException
)

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

router = APIRouter(prefix="/spare-parts", tags=["Spare Parts Dealer Portal"])

FOUR_WHEELER_BRANDS = [
    "Tata Motors", "Maruti Suzuki", "Hyundai", "Toyota", "Mahindra",
    "Kia", "Honda", "Volkswagen", "Skoda", "Renault",
    "Nissan", "BMW", "Mercedes-Benz", "Audi"
]

TWO_WHEELER_BRANDS = [
    "Hero", "Honda", "TVS", "Bajaj", "Royal Enfield",
    "Yamaha", "Suzuki", "KTM", "Ather", "Ola Electric"
]

CATEGORIES = [
    "Engine Parts", "Brake System", "Electrical", "Filters",
    "Suspension", "Transmission", "Exterior", "Two-wheeler Parts", "Accessories"
]

AVAILABLE_SPARE_PART_IMAGES = [
    {"name": "Oil Filter Canister", "path": "/static/images/spare_parts/oil_filter.jpg"},
    {"name": "Air Filter Assembly", "path": "/static/images/spare_parts/air_filter.jpg"},
    {"name": "Brake Pad Set", "path": "/static/images/spare_parts/brake_pad_set.jpg"},
    {"name": "Spark Plug", "path": "/static/images/spare_parts/spark_plug.jpg"},
    {"name": "Clutch Plate", "path": "/static/images/spare_parts/clutch_plate.jpg"},
    {"name": "Shock Absorber Strut", "path": "/static/images/spare_parts/shock_absorber.jpg"},
    {"name": "Headlight Assembly", "path": "/static/images/spare_parts/headlight_assembly.jpg"},
    {"name": "Heavy Duty Car Battery", "path": "/static/images/spare_parts/car_battery.jpg"},
    {"name": "Bike Chain & Sprocket", "path": "/static/images/spare_parts/bike_chain_kit.jpg"},
    {"name": "Bike Drum Brake Shoe", "path": "/static/images/spare_parts/bike_brake_shoe.jpg"},
    {"name": "Bike Clutch Plate Set", "path": "/static/images/spare_parts/bike_clutch_plate.jpg"},
    {"name": "Bike High-Flow Air Filter", "path": "/static/images/spare_parts/bike_air_filter.jpg"},
    {"name": "Alternator & Generator", "path": "/static/images/spare_parts/alternator.jpg"},
    {"name": "Engine Piston & Rings", "path": "/static/images/spare_parts/piston_assembly.jpg"},
    {"name": "Dual Electric Horn Set", "path": "/static/images/spare_parts/electric_horn.jpg"},
    {"name": "Aerodynamic Front Bumper", "path": "/static/images/spare_parts/car_bumper.jpg"},
    {"name": "Silicone Wiper Blades", "path": "/static/images/spare_parts/wiper_blade.jpg"},
    {"name": "DOT Certified Rider Helmet", "path": "/static/images/spare_parts/bike_helmet.jpg"}
]

def save_uploaded_spare_part_image(image_file: Optional[UploadFile], sku: str = "") -> Optional[str]:
    """Helper to save an uploaded image file to static directory and return its relative URL."""
    if not image_file or not image_file.filename:
        return None
    filename_clean = image_file.filename.strip()
    if not filename_clean:
        return None
    safe_name = re.sub(r'[^a-zA-Z0-9_.-]', '_', filename_clean.lower())
    if not safe_name.endswith(('.png', '.jpg', '.jpeg', '.webp', '.svg', '.gif')):
        safe_name += '.png'
    prefix = re.sub(r'[^a-zA-Z0-9]', '', sku.lower()) if sku else str(int(time.time()))
    unique_filename = f"{prefix}_{int(time.time())}_{safe_name}"
    
    upload_dir = BASE_DIR / "static" / "images" / "spare_parts"
    upload_dir.mkdir(parents=True, exist_ok=True)
    target_path = upload_dir / unique_filename
    
    with open(target_path, "wb") as buffer:
        content = image_file.file.read()
        buffer.write(content)
        
    return f"/static/images/spare_parts/{unique_filename}"

def get_portal_context(request: Request) -> Dict[str, Any]:
    """Helper to retrieve common portal context: current user, retailer profile, unread notification count."""
    user = get_current_user(request)
    retailer = None
    unread_notifs = 0
    
    with get_db() as conn:
        if user:
            retailer = get_retailer_by_user_id(user["id"])
            if user["role"] == "admin":
                unread_notifs = conn.execute(
                    "SELECT COUNT(*) FROM portal_notifications WHERE recipient_type = 'admin' AND is_read = 0"
                ).fetchone()[0]
            elif retailer:
                unread_notifs = conn.execute(
                    "SELECT COUNT(*) FROM portal_notifications WHERE recipient_type = 'retailer' AND retailer_id = ? AND is_read = 0",
                    (retailer["id"],)
                ).fetchone()[0]
                
    return {
        "request": request,
        "current_user": user,
        "current_retailer": retailer,
        "unread_notif_count": unread_notifs,
        "four_wheeler_brands": FOUR_WHEELER_BRANDS,
        "two_wheeler_brands": TWO_WHEELER_BRANDS,
        "all_categories": CATEGORIES,
        "available_images": AVAILABLE_SPARE_PART_IMAGES
    }

def require_retailer_auth(request: Request) -> Dict[str, Any]:
    """Ensures user is logged in as a retailer or admin."""
    user = get_current_user(request)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": f"/spare-parts/login?next={request.url.path}"}
        )
    return user

def require_admin_auth(request: Request) -> Dict[str, Any]:
    """Ensures user is logged in with admin privileges."""
    user = get_current_user(request)
    if not user or user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": "/admin/login?error=Admin%20access%20required%20for%20spare%20parts%20control%20panel"}
        )
    return user

# =====================================================================
# 1. RETAILER INTERFACE: MARKETPLACE / CATALOGUE
# =====================================================================

@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
async def spare_parts_marketplace(
    request: Request,
    q: Optional[str] = None,
    vehicle_type: Optional[str] = None,
    brand: Optional[str] = None,
    category: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    in_stock: Optional[int] = None,
    sort: Optional[str] = "default"
):
    ctx = get_portal_context(request)
    in_stock_bool = (in_stock == 1)
    
    parts = get_spare_parts_filtered(
        search_query=q,
        vehicle_type=vehicle_type,
        brand=brand,
        category=category,
        min_price=min_price,
        max_price=max_price,
        in_stock_only=in_stock_bool,
        sort_by=sort or "default"
    )
    
    ctx.update({
        "parts": parts,
        "search_query": q,
        "selected_type": vehicle_type or "all",
        "selected_brand": brand,
        "selected_category": category,
        "in_stock_only": in_stock_bool,
        "current_sort": sort or "default",
        "active_sp_tab": "marketplace"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/marketplace.html", context=ctx)

# =====================================================================
# 2. RETAILER AUTHENTICATION: REGISTER & LOGIN
# =====================================================================

@router.get("/register", response_class=HTMLResponse)
async def retailer_register_page(request: Request):
    ctx = get_portal_context(request)
    if ctx["current_retailer"]:
        return RedirectResponse(url="/spare-parts/dashboard", status_code=status.HTTP_303_SEE_OTHER)
    return templates.TemplateResponse(request=request, name="spare_parts/register.html", context=ctx)

@router.post("/register", response_class=HTMLResponse)
async def retailer_register_submit(
    request: Request,
    business_name: str = Form(...),
    contact_person: str = Form(...),
    email: str = Form(...),
    phone: str = Form(...),
    password: str = Form(...),
    gstin: Optional[str] = Form(""),
    city: str = Form("Bangalore"),
    address: str = Form(...)
):
    ctx = get_portal_context(request)
    email_clean = email.strip().lower()
    
    with get_db() as conn:
        cursor = conn.cursor()
        # Check duplicate email
        existing = cursor.execute("SELECT id FROM users WHERE email = ?", (email_clean,)).fetchone()
        if existing:
            ctx.update({
                "error": f"An account with email '{email_clean}' is already registered. Please sign in.",
                "form_data": {"business_name": business_name, "contact_person": contact_person, "email": email_clean, "phone": phone, "gstin": gstin, "address": address}
            })
            return templates.TemplateResponse(request=request, name="spare_parts/register.html", context=ctx, status_code=400)
            
        pwd_hash, salt = hash_password(password)
        cursor.execute("""
            INSERT INTO users (email, password_hash, salt, full_name, phone, address, city, role)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'retailer')
        """, (email_clean, pwd_hash, salt, contact_person, phone, address, city))
        user_id = cursor.lastrowid
        
        # Insert retailer record
        cursor.execute("""
            INSERT INTO retailers (
                user_id, business_name, contact_person, email, phone, gstin,
                address, city, state, status, discount_percent
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Karnataka', 'approved', 5.0)
        """, (user_id, business_name, contact_person, email_clean, phone, gstin.strip().upper(), address, city))
        retailer_id = cursor.lastrowid
        
    # Notify Admin of new registration
    create_portal_notification(
        recipient_type="admin",
        retailer_id=None,
        event_type="new_retailer",
        title="New Retailer Garage Registration",
        message=f"{business_name} ({contact_person}, {city}) registered. Initial Tier: 5% discount.",
        link_url="/spare-parts/admin/retailers"
    )
    
    token = create_session_token(user_id, "retailer", email_clean)
    response = RedirectResponse(url="/spare-parts/dashboard", status_code=status.HTTP_303_SEE_OTHER)
    response.set_cookie(COOKIE_NAME, token, httponly=True, samesite="lax", max_age=60*60*24*7)
    return response

@router.get("/login", response_class=HTMLResponse)
async def retailer_login_page(request: Request, next: Optional[str] = None):
    ctx = get_portal_context(request)
    if ctx["current_retailer"]:
        return RedirectResponse(url="/spare-parts/dashboard", status_code=status.HTTP_303_SEE_OTHER)
    ctx["next_url"] = next
    return templates.TemplateResponse(request=request, name="spare_parts/login.html", context=ctx)

@router.post("/login", response_class=HTMLResponse)
async def retailer_login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    next: Optional[str] = Form("")
):
    ctx = get_portal_context(request)
    email_clean = email.strip().lower()
    
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email_clean,)).fetchone()
        
    if not user or not verify_password(password, user["salt"], user["password_hash"]):
        ctx.update({
            "error": "Invalid email or password. Please verify your credentials.",
            "sample_email": email_clean
        })
        return templates.TemplateResponse(request=request, name="spare_parts/login.html", context=ctx, status_code=400)
        
    token = create_session_token(user["id"], user["role"], email_clean)
    dest = next if next and next.startswith("/spare-parts") else "/spare-parts/dashboard"
    if user["role"] == "admin" and not next:
        dest = "/spare-parts/admin"
        
    response = RedirectResponse(url=dest, status_code=status.HTTP_303_SEE_OTHER)
    response.set_cookie(COOKIE_NAME, token, httponly=True, samesite="lax", max_age=60*60*24*7)
    return response

# =====================================================================
# 3. RETAILER DASHBOARD & ORDERS
# =====================================================================

@router.get("/dashboard", response_class=HTMLResponse)
async def retailer_dashboard(request: Request, user: Dict[str, Any] = Depends(require_retailer_auth)):
    ctx = get_portal_context(request)
    retailer = ctx["current_retailer"]
    
    if not retailer:
        if user["role"] == "admin":
            return RedirectResponse(url="/spare-parts/admin", status_code=status.HTTP_303_SEE_OTHER)
        return RedirectResponse(url="/spare-parts/register", status_code=status.HTTP_303_SEE_OTHER)
        
    metrics = get_retailer_dashboard_metrics(retailer["id"])
    ctx.update({
        "retailer": retailer,
        "metrics": metrics,
        "active_sp_tab": "dashboard"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/dashboard.html", context=ctx)

@router.get("/cart", response_class=HTMLResponse)
async def wholesale_cart_page(request: Request):
    ctx = get_portal_context(request)
    ctx["active_sp_tab"] = "cart"
    return templates.TemplateResponse(request=request, name="spare_parts/cart.html", context=ctx)

@router.post("/api/checkout")
async def api_wholesale_checkout(request: Request):
    """API endpoint to process bulk wholesale checkout with atomic stock decrement."""
    user = get_current_user(request)
    if not user:
        return JSONResponse(status_code=401, content={"success": False, "error": "Please sign in to your retailer account."})
        
    retailer = get_retailer_by_user_id(user["id"])
    if not retailer:
        return JSONResponse(status_code=403, content={"success": False, "error": "A verified retailer profile is required to place wholesale orders."})
        
    try:
        body = await request.json()
        items = body.get("items", [])
        if not items:
            return JSONResponse(status_code=400, content={"success": False, "error": "Cart cannot be empty."})
            
        delivery_info = {
            "address": body.get("delivery_address", retailer["address"]),
            "city": body.get("delivery_city", retailer["city"]),
            "postal_code": body.get("delivery_postal", retailer["postal_code"]),
            "state": "Karnataka",
            "notes": body.get("delivery_notes", "")
        }
        payment_method = body.get("payment_method", "credit")
        
        result = process_wholesale_order_atomic(
            retailer_id=retailer["id"],
            cart_items=items,
            delivery_info=delivery_info,
            payment_method=payment_method
        )
        return JSONResponse(status_code=200, content=result)
        
    except InsufficientSparePartStockException as e:
        return JSONResponse(status_code=400, content={"success": False, "error": str(e)})
    except BelowMinimumOrderQtyException as e:
        return JSONResponse(status_code=400, content={"success": False, "error": str(e)})
    except RetailerNotApprovedException as e:
        return JSONResponse(status_code=403, content={"success": False, "error": str(e)})
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": f"Checkout processing error: {str(e)}"})

@router.get("/orders", response_class=HTMLResponse)
async def retailer_orders_page(
    request: Request,
    success: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_retailer_auth)
):
    ctx = get_portal_context(request)
    retailer = ctx["current_retailer"]
    if not retailer:
        return RedirectResponse(url="/spare-parts", status_code=status.HTTP_303_SEE_OTHER)
        
    with get_db() as conn:
        orders_rows = conn.execute("""
            SELECT * FROM spare_part_orders
            WHERE retailer_id = ?
            ORDER BY id DESC
        """, (retailer["id"],)).fetchall()
        
        orders = []
        for ord_row in orders_rows:
            ord_dict = dict(ord_row)
            items = conn.execute("""
                SELECT * FROM spare_part_order_items WHERE order_id = ?
            """, (ord_dict["id"],)).fetchall()
            ord_dict["items"] = [dict(it) for it in items]
            ord_dict["order_items"] = [dict(it) for it in items]
            
            inv = conn.execute("""
                SELECT invoice_number FROM spare_part_invoices WHERE order_id = ?
            """, (ord_dict["id"],)).fetchone()
            ord_dict["invoice_number"] = inv[0] if inv else None
            orders.append(ord_dict)
            
    ctx.update({
        "orders": orders,
        "success_order": success,
        "active_sp_tab": "orders"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/orders.html", context=ctx)

@router.get("/invoice/{invoice_number}", response_class=HTMLResponse)
async def view_spare_parts_invoice(request: Request, invoice_number: str):
    with get_db() as conn:
        inv = conn.execute("SELECT * FROM spare_part_invoices WHERE invoice_number = ?", (invoice_number,)).fetchone()
        if not inv:
            raise HTTPException(status_code=404, detail="Invoice not found.")
            
        order = conn.execute("SELECT * FROM spare_part_orders WHERE id = ?", (inv["order_id"],)).fetchone()
        retailer = conn.execute("SELECT * FROM retailers WHERE id = ?", (inv["retailer_id"],)).fetchone()
        items = conn.execute("SELECT * FROM spare_part_order_items WHERE order_id = ?", (inv["order_id"],)).fetchall()
        
    return templates.TemplateResponse(
        request=request,
        name="spare_parts/invoice.html",
        context={
            "request": request,
            "invoice": dict(inv),
            "order": dict(order),
            "retailer": dict(retailer),
            "items": [dict(it) for it in items]
        }
    )

@router.get("/notifications", response_class=HTMLResponse)
async def portal_notifications_page(request: Request, user: Dict[str, Any] = Depends(require_retailer_auth)):
    ctx = get_portal_context(request)
    retailer = ctx["current_retailer"]
    
    with get_db() as conn:
        if user["role"] == "admin":
            notifs = conn.execute(
                "SELECT * FROM portal_notifications WHERE recipient_type = 'admin' ORDER BY id DESC LIMIT 50"
            ).fetchall()
        elif retailer:
            notifs = conn.execute(
                "SELECT * FROM portal_notifications WHERE recipient_type = 'retailer' AND retailer_id = ? ORDER BY id DESC LIMIT 50",
                (retailer["id"],)
            ).fetchall()
        else:
            notifs = []
            
    ctx["notifications"] = [dict(n) for n in notifs]
    return templates.TemplateResponse(request=request, name="spare_parts/notifications.html", context=ctx)

@router.post("/api/notifications/mark-all-read")
async def mark_all_notifications_read(request: Request, user: Dict[str, Any] = Depends(require_retailer_auth)):
    retailer = get_retailer_by_user_id(user["id"])
    with get_db() as conn:
        if user["role"] == "admin":
            conn.execute("UPDATE portal_notifications SET is_read = 1 WHERE recipient_type = 'admin'")
        elif retailer:
            conn.execute("UPDATE portal_notifications SET is_read = 1 WHERE recipient_type = 'retailer' AND retailer_id = ?", (retailer["id"],))
            
    dest = "/spare-parts/admin/notifications" if user["role"] == "admin" else "/spare-parts/notifications"
    return RedirectResponse(url=dest, status_code=status.HTTP_303_SEE_OTHER)

# =====================================================================
# 4. ADMIN CONTROL PANEL: OVERVIEW, INVENTORY, RETAILERS, ORDERS, ANALYTICS
# =====================================================================

@router.get("/admin", response_class=HTMLResponse)
async def admin_portal_overview(request: Request, user: Dict[str, Any] = Depends(require_admin_auth)):
    ctx = get_portal_context(request)
    overview = get_admin_portal_overview()
    ctx.update({
        "overview": overview,
        "active_sp_tab": "admin_overview"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/admin/overview.html", context=ctx)

@router.get("/admin/inventory", response_class=HTMLResponse)
async def admin_inventory_page(
    request: Request,
    success: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    ctx = get_portal_context(request)
    with get_db() as conn:
        parts = conn.execute("SELECT * FROM spare_parts WHERE is_active = 1 ORDER BY stock_quantity ASC").fetchall()
        
    ctx.update({
        "parts": [dict(p) for p in parts],
        "success_msg": success,
        "active_sp_tab": "admin_inventory"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/admin/inventory.html", context=ctx)

@router.get("/admin/inventory/new", response_class=HTMLResponse)
async def admin_new_spare_part_page(
    request: Request,
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    ctx = get_portal_context(request)
    ctx.update({
        "four_wheeler_brands": FOUR_WHEELER_BRANDS,
        "two_wheeler_brands": TWO_WHEELER_BRANDS,
        "categories": CATEGORIES,
        "available_images": AVAILABLE_SPARE_PART_IMAGES,
        "active_sp_tab": "admin_inventory"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/admin/part_form.html", context=ctx)

@router.post("/admin/inventory/add")
async def admin_add_spare_part(
    request: Request,
    name: str = Form(...),
    sku: str = Form(...),
    vehicle_type: str = Form(...),
    brand: str = Form(...),
    category: str = Form(...),
    compatible_models: str = Form(...),
    wholesale_price: float = Form(...),
    suggested_retail_price: float = Form(...),
    stock_quantity: int = Form(50),
    reorder_point: int = Form(10),
    min_order_qty: int = Form(5),
    image_url: Optional[str] = Form(None),
    image_file: Optional[UploadFile] = File(None),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    import re
    slug = re.sub(r'[^a-zA-Z0-9]+', '-', name.lower()).strip('-') + f"-{sku.lower()}"
    cost_price = round(wholesale_price * 0.70, 2)

    # Determine image URL: prioritize uploaded file, then image_url input, then default JPG
    final_image_url = "/static/images/spare_parts/oil_filter.jpg"
    if image_file and image_file.filename:
        saved_path = save_uploaded_spare_part_image(image_file, sku)
        if saved_path:
            final_image_url = saved_path
    elif image_url and image_url.strip():
        final_image_url = image_url.strip()
    
    with get_db() as conn:
        conn.execute("""
            INSERT INTO spare_parts (
                name, slug, sku, vehicle_type, brand, compatible_models, category,
                wholesale_price, suggested_retail_price, cost_price,
                stock_quantity, reorder_point, min_order_qty, image_url, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (
            name.strip(), slug, sku.strip().upper(), vehicle_type.strip(), brand.strip(), compatible_models.strip(), category.strip(),
            wholesale_price, suggested_retail_price, cost_price,
            stock_quantity, reorder_point, min_order_qty, final_image_url
        ))
        
    return RedirectResponse(
        url=f"/spare-parts/admin/inventory?success=Added%20new%20part%20{sku.strip().upper()}",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.post("/admin/inventory/edit/{part_id}")
async def admin_edit_spare_part(
    part_id: int,
    wholesale_price: float = Form(...),
    suggested_retail_price: float = Form(...),
    stock_quantity: int = Form(...),
    reorder_point: int = Form(...),
    min_order_qty: int = Form(...),
    name: Optional[str] = Form(None),
    brand: Optional[str] = Form(None),
    category: Optional[str] = Form(None),
    compatible_models: Optional[str] = Form(None),
    vehicle_type: Optional[str] = Form(None),
    image_url: Optional[str] = Form(None),
    image_file: Optional[UploadFile] = File(None),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    with get_db() as conn:
        part = conn.execute("SELECT * FROM spare_parts WHERE id = ?", (part_id,)).fetchone()
        if not part:
            raise HTTPException(status_code=404, detail="Spare part not found")
        
        current_image = part["image_url"]
        final_image_url = current_image
        
        # Check if new image file uploaded
        if image_file and image_file.filename:
            saved_path = save_uploaded_spare_part_image(image_file, part["sku"])
            if saved_path:
                final_image_url = saved_path
        elif image_url and image_url.strip():
            final_image_url = image_url.strip()

        # Update core pricing, stock, MOQ, and image
        conn.execute("""
            UPDATE spare_parts
            SET wholesale_price = ?, suggested_retail_price = ?, stock_quantity = ?,
                reorder_point = ?, min_order_qty = ?, image_url = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (wholesale_price, suggested_retail_price, stock_quantity, reorder_point, min_order_qty, final_image_url, part_id))

        # Update optional descriptive fields if submitted
        if name and name.strip():
            conn.execute("UPDATE spare_parts SET name = ? WHERE id = ?", (name.strip(), part_id))
        if brand and brand.strip():
            conn.execute("UPDATE spare_parts SET brand = ? WHERE id = ?", (brand.strip(), part_id))
        if category and category.strip():
            conn.execute("UPDATE spare_parts SET category = ? WHERE id = ?", (category.strip(), part_id))
        if compatible_models and compatible_models.strip():
            conn.execute("UPDATE spare_parts SET compatible_models = ? WHERE id = ?", (compatible_models.strip(), part_id))
        if vehicle_type and vehicle_type.strip():
            conn.execute("UPDATE spare_parts SET vehicle_type = ? WHERE id = ?", (vehicle_type.strip(), part_id))
        
    return RedirectResponse(
        url="/spare-parts/admin/inventory?success=Updated%20part%20details%20and%20image%20successfully",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.post("/admin/inventory/restock/{part_id}")
async def admin_restock_part(
    part_id: int,
    add_units: int = Form(50),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    with get_db() as conn:
        conn.execute("""
            UPDATE spare_parts
            SET stock_quantity = stock_quantity + ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (add_units, part_id))
        
    return RedirectResponse(
        url=f"/spare-parts/admin/inventory?success=Replenished%20{add_units}%20units",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.get("/admin/retailers", response_class=HTMLResponse)
async def admin_retailers_page(
    request: Request,
    success: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    ctx = get_portal_context(request)
    with get_db() as conn:
        retailers = conn.execute("""
            SELECT r.*, COUNT(o.id) as order_count
            FROM retailers r
            LEFT JOIN spare_part_orders o ON o.retailer_id = r.id
            GROUP BY r.id
            ORDER BY r.id DESC
        """).fetchall()
        
    ctx.update({
        "retailers": [dict(r) for r in retailers],
        "success_msg": success,
        "active_sp_tab": "admin_retailers"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/admin/retailers.html", context=ctx)

@router.post("/admin/retailers/add")
async def admin_add_retailer(
    business_name: str = Form(...),
    contact_person: str = Form(...),
    email: str = Form(...),
    phone: str = Form(...),
    password: str = Form("Retailer@123"),
    city: str = Form("Bangalore"),
    address: str = Form(...),
    gstin: Optional[str] = Form(""),
    discount_percent: float = Form(8.0),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    email_clean = email.strip().lower()
    pwd_hash, salt = hash_password(password)
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (email, password_hash, salt, full_name, phone, address, city, role)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'retailer')
        """, (email_clean, pwd_hash, salt, contact_person, phone, address, city))
        u_id = cursor.lastrowid
        
        cursor.execute("""
            INSERT INTO retailers (
                user_id, business_name, contact_person, email, phone, gstin,
                address, city, state, status, discount_percent
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Karnataka', 'approved', ?)
        """, (u_id, business_name, contact_person, email_clean, phone, gstin.strip().upper(), address, city, discount_percent))
        
    return RedirectResponse(
        url=f"/spare-parts/admin/retailers?success=Created%20partner%20account%20for%20{business_name}",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.post("/admin/retailers/{retailer_id}/status")
async def admin_update_retailer_status(
    retailer_id: int,
    new_status: str = Form(..., alias="status"),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    with get_db() as conn:
        conn.execute("UPDATE retailers SET status = ? WHERE id = ?", (new_status, retailer_id))
        
    return RedirectResponse(
        url=f"/spare-parts/admin/retailers?success=Updated%20retailer%20status%20to%20{new_status}",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.post("/admin/retailers/{retailer_id}/discount")
async def admin_update_retailer_discount(
    retailer_id: int,
    discount_percent: float = Form(...),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    with get_db() as conn:
        conn.execute("UPDATE retailers SET discount_percent = ? WHERE id = ?", (discount_percent, retailer_id))
        
    return RedirectResponse(
        url=f"/spare-parts/admin/retailers?success=Updated%20discount%20tier%20to%20{discount_percent}%25",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.get("/admin/orders", response_class=HTMLResponse)
async def admin_orders_page(
    request: Request,
    success: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    ctx = get_portal_context(request)
    with get_db() as conn:
        orders_rows = conn.execute("""
            SELECT o.*, r.business_name, r.contact_person, r.city, r.phone,
                   COUNT(oi.id) as item_count,
                   SUM(oi.quantity) as total_quantity,
                   inv.invoice_number
            FROM spare_part_orders o
            JOIN retailers r ON r.id = o.retailer_id
            LEFT JOIN spare_part_order_items oi ON oi.order_id = o.id
            LEFT JOIN spare_part_invoices inv ON inv.order_id = o.id
            GROUP BY o.id
            ORDER BY o.id DESC
        """).fetchall()
        
    ctx.update({
        "orders": [dict(o) for o in orders_rows],
        "success_msg": success,
        "active_sp_tab": "admin_orders"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/admin/orders.html", context=ctx)

@router.post("/admin/orders/{order_id}/status")
async def admin_update_order_status(
    order_id: int,
    order_status: str = Form(...),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    update_wholesale_order_status(order_id, order_status)
    return RedirectResponse(
        url=f"/spare-parts/admin/orders?success=Order%20status%20updated%20to%20{order_status}",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.post("/admin/orders/{order_id}/tracking")
async def admin_update_order_tracking(
    order_id: int,
    carrier_name: str = Form(...),
    tracking_number: str = Form(...),
    user: Dict[str, Any] = Depends(require_admin_auth)
):
    update_wholesale_order_status(
        order_id=order_id,
        new_status="dispatched",
        tracking_number=tracking_number.strip(),
        carrier_name=carrier_name.strip()
    )
    return RedirectResponse(
        url=f"/spare-parts/admin/orders?success=Assigned%20tracking%20{tracking_number}",
        status_code=status.HTTP_303_SEE_OTHER
    )

@router.get("/admin/analytics", response_class=HTMLResponse)
async def admin_analytics_page(request: Request, user: Dict[str, Any] = Depends(require_admin_auth)):
    ctx = get_portal_context(request)
    analytics = get_portal_analytics()
    ctx.update({
        "analytics": analytics,
        "active_sp_tab": "admin_analytics"
    })
    return templates.TemplateResponse(request=request, name="spare_parts/admin/analytics.html", context=ctx)

@router.get("/admin/notifications", response_class=HTMLResponse)
async def admin_notifications_page(request: Request, user: Dict[str, Any] = Depends(require_admin_auth)):
    ctx = get_portal_context(request)
    with get_db() as conn:
        notifs = conn.execute(
            "SELECT * FROM portal_notifications WHERE recipient_type = 'admin' ORDER BY id DESC LIMIT 50"
        ).fetchall()
    ctx["notifications"] = [dict(n) for n in notifs]
    return templates.TemplateResponse(request=request, name="spare_parts/notifications.html", context=ctx)
