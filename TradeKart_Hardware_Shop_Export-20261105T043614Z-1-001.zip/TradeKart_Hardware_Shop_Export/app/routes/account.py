from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from app.config import settings
from app.database import get_db
from app.auth import require_customer_redirect

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))

@router.get("/account/orders", response_class=HTMLResponse)
async def my_orders_page(request: Request, current_user: dict = Depends(require_customer_redirect)):
    with get_db() as conn:
        # Fetch orders either associated with user_id or with customer's email
        orders_rows = conn.execute("""
            SELECT * FROM orders 
            WHERE user_id = ? OR customer_email = ?
            ORDER BY created_at DESC
        """, (current_user["id"], current_user["email"])).fetchall()

        orders_list = []
        for o in orders_rows:
            ord_dict = dict(o)
            items_rows = conn.execute(
                "SELECT * FROM order_items WHERE order_id = ?",
                (ord_dict["id"],)
            ).fetchall()
            ord_dict["items"] = [dict(it) for it in items_rows]
            orders_list.append(ord_dict)

    ctx = {
        "request": request,
        "shop_name": settings.SHOP_NAME,
        "shop_email": settings.SHOP_EMAIL,
        "shop_phone": settings.SHOP_PHONE,
        "shop_address": settings.SHOP_ADDRESS,
        "shop_gstin": settings.GSTIN,
        "currency_symbol": settings.CURRENCY_SYMBOL,
        "current_user": current_user,
        "orders": orders_list
    }
    return templates.TemplateResponse(request=request, name="account_orders.html", context=ctx)
