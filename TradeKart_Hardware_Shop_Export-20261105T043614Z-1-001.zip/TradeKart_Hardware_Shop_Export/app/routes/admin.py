import re
import datetime
from fastapi import APIRouter, Request, Form, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Optional
from app.config import settings
from app.database import get_db
from app.auth import require_admin_redirect
from app.services.inventory_service import (
    get_items_needing_restock,
    get_critical_low_stock_items,
    restock_product
)

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))

def make_slug(name: str) -> str:
    s = re.sub(r'[^a-zA-Z0-9\s-]', '', name).strip().lower()
    return re.sub(r'[\s-]+', '-', s)

def get_admin_common_ctx(request: Request, current_user: dict, active_tab: str):
    low_stock = get_items_needing_restock()
    return {
        "request": request,
        "shop_name": settings.SHOP_NAME,
        "shop_email": settings.SHOP_EMAIL,
        "shop_phone": settings.SHOP_PHONE,
        "shop_address": settings.SHOP_ADDRESS,
        "shop_gstin": settings.GSTIN,
        "currency_symbol": settings.CURRENCY_SYMBOL,
        "current_user": current_user,
        "active_tab": active_tab,
        "low_stock_count": len(low_stock)
    }

# ----------------- Dashboard -----------------

@router.get("/admin", response_class=HTMLResponse)
@router.get("/admin/dashboard", response_class=HTMLResponse)
async def admin_dashboard(request: Request, current_user: dict = Depends(require_admin_redirect)):
    ctx = get_admin_common_ctx(request, current_user, "dashboard")

    with get_db() as conn:
        rev_row = conn.execute("SELECT COALESCE(SUM(total_amount), 0.0) as rev, COUNT(id) as total_orders FROM orders WHERE payment_status = 'paid'").fetchone()
        prod_count = conn.execute("SELECT COUNT(id) as cnt FROM products WHERE is_active = 1").fetchone()["cnt"]
        
        recent_orders_rows = conn.execute("""
            SELECT * FROM orders ORDER BY created_at DESC LIMIT 8
        """).fetchall()

    low_items = get_items_needing_restock()
    
    ctx.update({
        "metrics": {
            "total_revenue": rev_row["rev"],
            "total_orders": rev_row["total_orders"],
            "total_products": prod_count,
            "low_stock_count": len(low_items)
        },
        "low_stock_items": low_items,
        "recent_orders": [dict(o) for o in recent_orders_rows]
    })
    return templates.TemplateResponse(request=request, name="admin/dashboard.html", context=ctx)

# ----------------- Inventory / Products -----------------

@router.get("/admin/products", response_class=HTMLResponse)
async def admin_products_list(
    request: Request,
    q: Optional[str] = None,
    msg: Optional[str] = None,
    current_user: dict = Depends(require_admin_redirect)
):
    ctx = get_admin_common_ctx(request, current_user, "products")
    ctx["message"] = msg
    ctx["search_query"] = q

    query = """
        SELECT p.*, c.name as category_name
        FROM products p
        JOIN categories c ON p.category_id = c.id
    """
    params = []
    if q and q.strip():
        search_term = f"%{q.strip()}%"
        query += " WHERE p.name LIKE ? OR p.sku LIKE ? OR c.name LIKE ?"
        params.extend([search_term, search_term, search_term])
        
    query += " ORDER BY p.is_active DESC, p.stock_quantity ASC, p.name ASC"

    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()

    ctx["products"] = [dict(r) for r in rows]
    return templates.TemplateResponse(request=request, name="admin/products.html", context=ctx)

@router.get("/admin/products/new", response_class=HTMLResponse)
async def admin_product_new_page(request: Request, current_user: dict = Depends(require_admin_redirect)):
    ctx = get_admin_common_ctx(request, current_user, "products")
    with get_db() as conn:
        cats = conn.execute("SELECT * FROM categories ORDER BY name ASC").fetchall()
    ctx.update({
        "categories": [dict(c) for c in cats],
        "is_edit": False,
        "product": None
    })
    return templates.TemplateResponse(request=request, name="admin/product_form.html", context=ctx)

@router.post("/admin/products/new")
async def admin_product_create(
    request: Request,
    name: str = Form(...),
    category_id: int = Form(...),
    sku: str = Form(...),
    price: float = Form(...),
    stock_quantity: int = Form(...),
    reorder_point: int = Form(5),
    image_url: str = Form("/static/images/products/antique_brass_knob.svg"),
    description: str = Form(""),
    specifications: str = Form(""),
    is_active: Optional[str] = Form(None),
    current_user: dict = Depends(require_admin_redirect)
):
    sku_clean = sku.strip().upper()
    slug_base = make_slug(name)
    active_flag = 1 if is_active else 0

    try:
        with get_db() as conn:
            # Check SKU unique
            exists = conn.execute("SELECT id FROM products WHERE sku = ?", (sku_clean,)).fetchone()
            if exists:
                ctx = get_admin_common_ctx(request, current_user, "products")
                cats = conn.execute("SELECT * FROM categories ORDER BY name ASC").fetchall()
                ctx.update({
                    "categories": [dict(c) for c in cats],
                    "is_edit": False,
                    "error": f"SKU '{sku_clean}' is already assigned to another product.",
                    "product": {"name": name, "sku": sku, "price": price, "stock_quantity": stock_quantity, "reorder_point": reorder_point, "description": description, "specifications": specifications, "category_id": category_id, "image_url": image_url}
                })
                return templates.TemplateResponse(request=request, name="admin/product_form.html", context=ctx, status_code=400)

            # Check slug uniqueness
            slug = slug_base
            idx = 1
            while conn.execute("SELECT id FROM products WHERE slug = ?", (slug,)).fetchone():
                slug = f"{slug_base}-{idx}"
                idx += 1

            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO products (
                    name, slug, category_id, sku, description, specifications,
                    price, stock_quantity, reorder_point, image_url, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (name.strip(), slug, category_id, sku_clean, description.strip(), specifications.strip(), price, stock_quantity, reorder_point, image_url.strip(), active_flag))
            new_id = cursor.lastrowid

            cursor.execute("""
                INSERT INTO stock_logs (product_id, change_amount, previous_stock, new_stock, reason, reference_id)
                VALUES (?, ?, ?, ?, 'initial_stock_creation', 'admin_create')
            """, (new_id, stock_quantity, 0, stock_quantity))

        return RedirectResponse(url="/admin/products?msg=Product%20created%20successfully", status_code=303)
    except Exception as e:
        ctx = get_admin_common_ctx(request, current_user, "products")
        with get_db() as conn:
            cats = conn.execute("SELECT * FROM categories ORDER BY name ASC").fetchall()
        ctx.update({
            "categories": [dict(c) for c in cats],
            "is_edit": False,
            "error": f"Failed to save product: {str(e)}",
            "product": {"name": name, "sku": sku, "price": price, "stock_quantity": stock_quantity, "reorder_point": reorder_point, "description": description, "specifications": specifications, "category_id": category_id, "image_url": image_url}
        })
        return templates.TemplateResponse(request=request, name="admin/product_form.html", context=ctx, status_code=500)

@router.get("/admin/products/{product_id}/edit", response_class=HTMLResponse)
async def admin_product_edit_page(request: Request, product_id: int, current_user: dict = Depends(require_admin_redirect)):
    ctx = get_admin_common_ctx(request, current_user, "products")
    with get_db() as conn:
        prod = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
        if not prod:
            raise HTTPException(status_code=404, detail="Product not found")
        cats = conn.execute("SELECT * FROM categories ORDER BY name ASC").fetchall()

    ctx.update({
        "categories": [dict(c) for c in cats],
        "is_edit": True,
        "product": dict(prod)
    })
    return templates.TemplateResponse(request=request, name="admin/product_form.html", context=ctx)

@router.post("/admin/products/{product_id}/edit")
async def admin_product_update(
    request: Request,
    product_id: int,
    name: str = Form(...),
    category_id: int = Form(...),
    sku: str = Form(...),
    price: float = Form(...),
    stock_quantity: int = Form(...),
    reorder_point: int = Form(5),
    image_url: str = Form(...),
    description: str = Form(""),
    specifications: str = Form(""),
    is_active: Optional[str] = Form(None),
    current_user: dict = Depends(require_admin_redirect)
):
    sku_clean = sku.strip().upper()
    active_flag = 1 if is_active else 0

    with get_db() as conn:
        existing = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Product not found")

        # Check duplicate SKU on other products
        other_sku = conn.execute("SELECT id FROM products WHERE sku = ? AND id != ?", (sku_clean, product_id)).fetchone()
        if other_sku:
            ctx = get_admin_common_ctx(request, current_user, "products")
            cats = conn.execute("SELECT * FROM categories ORDER BY name ASC").fetchall()
            ctx.update({
                "categories": [dict(c) for c in cats],
                "is_edit": True,
                "error": f"SKU '{sku_clean}' is already in use by another item.",
                "product": {"id": product_id, "name": name, "sku": sku, "price": price, "stock_quantity": stock_quantity, "reorder_point": reorder_point, "description": description, "specifications": specifications, "category_id": category_id, "image_url": image_url, "is_active": active_flag}
            })
            return templates.TemplateResponse(request=request, name="admin/product_form.html", context=ctx, status_code=400)

        prev_stock = existing["stock_quantity"]
        stock_diff = stock_quantity - prev_stock

        conn.execute("""
            UPDATE products SET
                name = ?, category_id = ?, sku = ?, price = ?,
                stock_quantity = ?, reorder_point = ?, image_url = ?,
                description = ?, specifications = ?, is_active = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (name.strip(), category_id, sku_clean, price, stock_quantity, reorder_point, image_url.strip(), description.strip(), specifications.strip(), active_flag, product_id))

        if stock_diff != 0:
            conn.execute("""
                INSERT INTO stock_logs (product_id, change_amount, previous_stock, new_stock, reason, reference_id)
                VALUES (?, ?, ?, ?, 'manual_admin_adjustment', 'product_edit_screen')
            """, (product_id, stock_diff, prev_stock, stock_quantity))

    return RedirectResponse(url="/admin/products?msg=Product%20updated%20successfully", status_code=303)

@router.post("/admin/products/{product_id}/delete")
async def admin_product_delete(request: Request, product_id: int, current_user: dict = Depends(require_admin_redirect)):
    with get_db() as conn:
        prod = conn.execute("SELECT name FROM products WHERE id = ?", (product_id,)).fetchone()
        if not prod:
            raise HTTPException(status_code=404, detail="Product not found")

        # Check if product is in existing orders
        has_orders = conn.execute("SELECT id FROM order_items WHERE product_id = ? LIMIT 1", (product_id,)).fetchone()
        if has_orders:
            # Soft delete / archive to protect relational integrity
            conn.execute("UPDATE products SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (product_id,))
            msg = f"Product '{prod['name']}' has historical orders, so it was archived and hidden from storefront."
        else:
            conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
            msg = f"Product '{prod['name']}' was completely removed from catalog."

    return RedirectResponse(url=f"/admin/products?msg={msg}", status_code=303)

# ----------------- Restocking Intelligence -----------------

@router.get("/admin/restocking", response_class=HTMLResponse)
async def admin_restocking_page(
    request: Request,
    msg: Optional[str] = None,
    current_user: dict = Depends(require_admin_redirect)
):
    ctx = get_admin_common_ctx(request, current_user, "restocking")
    ctx["success_message"] = msg

    # List 1: Items needing restock (stock <= reorder_point)
    low_items = get_items_needing_restock()

    # List 2: Critical items about to run out (stock <= 3)
    critical_items = get_critical_low_stock_items(threshold=3)

    with get_db() as conn:
        logs_rows = conn.execute("""
            SELECT l.*, p.name as product_name
            FROM stock_logs l
            JOIN products p ON l.product_id = p.id
            ORDER BY l.created_at DESC LIMIT 15
        """).fetchall()

    ctx.update({
        "low_items": low_items,
        "critical_items": critical_items,
        "stock_logs": [dict(lg) for lg in logs_rows]
    })
    return templates.TemplateResponse(request=request, name="admin/restocking.html", context=ctx)

@router.post("/admin/restock")
async def admin_perform_restock(
    request: Request,
    product_id: int = Form(...),
    additional_stock: int = Form(...),
    reason: str = Form("Manual restock order"),
    current_user: dict = Depends(require_admin_redirect)
):
    if additional_stock <= 0:
        raise HTTPException(status_code=400, detail="Restock quantity must be positive")

    res = restock_product(
        product_id=product_id,
        additional_stock=additional_stock,
        reason=reason,
        reference_id=f"admin_{current_user.get('email', 'staff')}"
    )

    msg = f"Replenished {additional_stock} units for '{res['product_name']}'. Live stock is now {res['new_stock']} units."
    return RedirectResponse(url=f"/admin/restocking?msg={msg}", status_code=303)

# ----------------- Orders & Invoices -----------------

@router.get("/admin/orders", response_class=HTMLResponse)
async def admin_orders_list(
    request: Request,
    status: Optional[str] = None,
    current_user: dict = Depends(require_admin_redirect)
):
    ctx = get_admin_common_ctx(request, current_user, "orders")
    ctx["current_status"] = status

    query = """
        SELECT o.*, COUNT(oi.id) as item_count
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
    """
    params = []
    if status:
        query += " WHERE o.order_status = ?"
        params.append(status)

    query += " GROUP BY o.id ORDER BY o.created_at DESC"

    with get_db() as conn:
        total_count = conn.execute("SELECT COUNT(id) as cnt FROM orders").fetchone()["cnt"]
        orders_rows = conn.execute(query, params).fetchall()

    ctx.update({
        "orders": [dict(o) for o in orders_rows],
        "total_count": total_count
    })
    return templates.TemplateResponse(request=request, name="admin/orders.html", context=ctx)

@router.get("/admin/orders/{order_id}", response_class=HTMLResponse)
async def admin_order_detail(request: Request, order_id: int, current_user: dict = Depends(require_admin_redirect)):
    ctx = get_admin_common_ctx(request, current_user, "orders")
    with get_db() as conn:
        order = conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        items = conn.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,)).fetchall()

    ctx.update({
        "order": dict(order),
        "items": [dict(i) for i in items]
    })
    return templates.TemplateResponse(request=request, name="admin/order_detail.html", context=ctx)

@router.post("/admin/orders/{order_id}/status")
async def admin_update_order_status(
    request: Request,
    order_id: int,
    order_status: str = Form(...),
    tracking_number: Optional[str] = Form(None),
    current_user: dict = Depends(require_admin_redirect)
):
    with get_db() as conn:
        order = conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")

        tracking = tracking_number.strip() if tracking_number else order["tracking_number"]
        conn.execute("""
            UPDATE orders SET order_status = ?, tracking_number = ? WHERE id = ?
        """, (order_status, tracking, order_id))

    return RedirectResponse(url=f"/admin/orders/{order_id}", status_code=303)
