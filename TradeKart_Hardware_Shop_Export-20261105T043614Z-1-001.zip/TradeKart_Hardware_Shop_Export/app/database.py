import sqlite3
from contextlib import contextmanager
from app.config import settings

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(settings.DATABASE_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn

@contextmanager
def get_db():
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with get_db() as conn:
        cursor = conn.cursor()
        
        # 1. Users Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            full_name TEXT NOT NULL,
            phone TEXT DEFAULT '',
            address TEXT DEFAULT '',
            city TEXT DEFAULT '',
            postal_code TEXT DEFAULT '',
            role TEXT NOT NULL DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 2. Categories Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            slug TEXT NOT NULL UNIQUE,
            description TEXT DEFAULT '',
            icon TEXT DEFAULT 'box'
        );
        """)

        # 3. Products Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
            sku TEXT NOT NULL UNIQUE,
            description TEXT DEFAULT '',
            specifications TEXT DEFAULT '',
            price REAL NOT NULL,
            stock_quantity INTEGER NOT NULL DEFAULT 0,
            reorder_point INTEGER NOT NULL DEFAULT 5,
            image_url TEXT DEFAULT '',
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 4. Orders Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_number TEXT NOT NULL UNIQUE,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            customer_name TEXT NOT NULL,
            customer_email TEXT NOT NULL,
            customer_phone TEXT NOT NULL,
            delivery_method TEXT NOT NULL,
            delivery_address TEXT DEFAULT '',
            delivery_city TEXT DEFAULT '',
            delivery_state TEXT DEFAULT '',
            delivery_postal TEXT DEFAULT '',
            delivery_notes TEXT DEFAULT '',
            subtotal REAL NOT NULL,
            delivery_fee REAL NOT NULL DEFAULT 0.0,
            tax_amount REAL NOT NULL DEFAULT 0.0,
            total_amount REAL NOT NULL,
            payment_status TEXT NOT NULL DEFAULT 'paid',
            payment_provider TEXT NOT NULL DEFAULT 'mock',
            payment_transaction_id TEXT DEFAULT '',
            order_status TEXT NOT NULL DEFAULT 'processing',
            tracking_number TEXT DEFAULT '',
            carrier_name TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 5. Order Items Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
            product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
            product_name TEXT NOT NULL,
            product_sku TEXT NOT NULL,
            unit_price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            subtotal REAL NOT NULL
        );
        """)

        # 6. Stock Logs Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS stock_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
            change_amount INTEGER NOT NULL,
            previous_stock INTEGER NOT NULL,
            new_stock INTEGER NOT NULL,
            reason TEXT NOT NULL,
            reference_id TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # -------------------------------------------------------------
        # SPARE PARTS DEALER PORTAL TABLES (Automobile Wholesale)
        # -------------------------------------------------------------

        # 7. Spare Parts Catalogue Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS spare_parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            sku TEXT NOT NULL UNIQUE,
            vehicle_type TEXT NOT NULL, -- 'four_wheeler' or 'two_wheeler'
            brand TEXT NOT NULL,
            compatible_models TEXT NOT NULL,
            category TEXT NOT NULL,
            wholesale_price REAL NOT NULL,
            suggested_retail_price REAL NOT NULL,
            cost_price REAL NOT NULL DEFAULT 0.0,
            stock_quantity INTEGER NOT NULL DEFAULT 0,
            reorder_point INTEGER NOT NULL DEFAULT 10,
            min_order_qty INTEGER NOT NULL DEFAULT 1,
            image_url TEXT DEFAULT '',
            description TEXT DEFAULT '',
            specifications TEXT DEFAULT '',
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 8. Retailer Accounts & Garages Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS retailers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
            business_name TEXT NOT NULL,
            contact_person TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT NOT NULL,
            gstin TEXT DEFAULT '',
            address TEXT DEFAULT '',
            city TEXT NOT NULL,
            state TEXT DEFAULT 'Karnataka',
            postal_code TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'approved', -- 'pending', 'approved', 'blocked'
            discount_percent REAL NOT NULL DEFAULT 5.0,
            outstanding_balance REAL NOT NULL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 9. Wholesale Spare Part Orders Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS spare_part_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_number TEXT NOT NULL UNIQUE,
            retailer_id INTEGER NOT NULL REFERENCES retailers(id) ON DELETE RESTRICT,
            order_status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'confirmed', 'processing', 'dispatched', 'delivered', 'cancelled'
            payment_status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'paid', 'credit'
            subtotal REAL NOT NULL,
            discount_amount REAL NOT NULL DEFAULT 0.0,
            gst_amount REAL NOT NULL DEFAULT 0.0,
            grand_total REAL NOT NULL,
            delivery_address TEXT DEFAULT '',
            delivery_city TEXT DEFAULT '',
            delivery_state TEXT DEFAULT '',
            delivery_postal TEXT DEFAULT '',
            delivery_notes TEXT DEFAULT '',
            tracking_number TEXT DEFAULT '',
            carrier_name TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 10. Wholesale Spare Part Order Items Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS spare_part_order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL REFERENCES spare_part_orders(id) ON DELETE CASCADE,
            spare_part_id INTEGER REFERENCES spare_parts(id) ON DELETE SET NULL,
            part_name TEXT NOT NULL,
            part_sku TEXT NOT NULL,
            brand TEXT NOT NULL,
            vehicle_type TEXT NOT NULL,
            category TEXT NOT NULL,
            wholesale_price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            subtotal REAL NOT NULL
        );
        """)

        # 11. Spare Part Invoices Table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS spare_part_invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_number TEXT NOT NULL UNIQUE,
            order_id INTEGER NOT NULL UNIQUE REFERENCES spare_part_orders(id) ON DELETE CASCADE,
            retailer_id INTEGER NOT NULL REFERENCES retailers(id) ON DELETE RESTRICT,
            invoice_date DATE DEFAULT CURRENT_DATE,
            subtotal REAL NOT NULL,
            discount_amount REAL NOT NULL DEFAULT 0.0,
            gst_amount REAL NOT NULL DEFAULT 0.0,
            grand_total REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'issued', -- 'issued', 'paid', 'cancelled'
            pdf_path TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 12. In-App Notifications Table (Admin & Retailer)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS portal_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipient_type TEXT NOT NULL, -- 'admin' or 'retailer'
            retailer_id INTEGER REFERENCES retailers(id) ON DELETE CASCADE,
            event_type TEXT NOT NULL, -- 'new_retailer', 'new_order', 'order_confirmed', 'order_dispatched', 'reorder_alert', 'out_of_stock', 'invoice_generated', 'payment_received'
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            link_url TEXT DEFAULT '',
            is_read INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # Indexes for fast querying
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_products_stock ON products(stock_quantity);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_products_reorder ON products(stock_quantity, reorder_point);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_stock_logs_prod ON stock_logs(product_id);")

        # Spare Parts Specific Indexes
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sp_type ON spare_parts(vehicle_type);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sp_brand ON spare_parts(brand);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sp_category ON spare_parts(category);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sp_stock ON spare_parts(stock_quantity, reorder_point);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_spo_retailer ON spare_part_orders(retailer_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_spo_status ON spare_part_orders(order_status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notif_recip ON portal_notifications(recipient_type, retailer_id, is_read);")
