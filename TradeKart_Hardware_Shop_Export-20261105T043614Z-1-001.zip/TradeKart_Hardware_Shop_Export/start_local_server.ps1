# =====================================================================
# TradeKart Hardware & Industrial E-Commerce - Local PowerShell Launcher
# =====================================================================
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host "=====================================================================" -ForegroundColor Green
Write-Host " TradeKart Hardware & Industrial E-Commerce Platform" -ForegroundColor White
Write-Host " Storefront + Spare Parts Dealer Portal + AI Camera Part Scanner" -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host ""

Write-Host "[1/3] Verifying Python..." -ForegroundColor Yellow
python --version

Write-Host "[2/3] Installing/Verifying Python dependencies..." -ForegroundColor Yellow
python -m pip install -q -r requirements.txt

Write-Host "[3/3] Checking SQLite database..." -ForegroundColor Yellow
if (-not (Test-Path "hardware_shop.db")) {
    Write-Host "Database not found. Seeding initial data and generating catalog images..." -ForegroundColor Yellow
    python seed_data.py
    python setup_jpeg_images.py
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host " Local Desktop Server Active!" -ForegroundColor Green
Write-Host " Access your website at:" -ForegroundColor White
Write-Host "   - Main Storefront       : http://127.0.0.1:8000/" -ForegroundColor Cyan
Write-Host "   - Spare Parts Portal    : http://127.0.0.1:8000/spare-parts" -ForegroundColor Cyan
Write-Host "   - AI Part Scanner       : http://127.0.0.1:8000/ai-assistant" -ForegroundColor Cyan
Write-Host "   - Admin Dashboard       : http://127.0.0.1:8000/admin/login" -ForegroundColor Cyan
Write-Host ""
Write-Host " Press Ctrl+C in this terminal to stop the server." -ForegroundColor Yellow
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host ""

python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
